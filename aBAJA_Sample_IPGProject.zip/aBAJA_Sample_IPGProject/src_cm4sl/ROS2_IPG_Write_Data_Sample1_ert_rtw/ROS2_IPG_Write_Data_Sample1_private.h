//
// File: ROS2_IPG_Write_Data_Sample1_private.h
//
// Code generated for Simulink model 'ROS2_IPG_Write_Data_Sample1'.
//
// Model version                  : 1.0
// Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
// C/C++ source code generated on : Sat Apr 19 03:00:56 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef ROS2_IPG_Write_Data_Sample1_private_h_
#define ROS2_IPG_Write_Data_Sample1_private_h_
#include "rtwtypes.h"
#include "ROS2_IPG_Write_Data_Sample1_types.h"
#include "ROS2_IPG_Write_Data_Sample1.h"

extern void mul_wide_u32(uint32_T in0, uint32_T in1, uint32_T *ptrOutBitsHi,
  uint32_T *ptrOutBitsLo);
extern uint32_T mul_u32_sat(uint32_T a, uint32_T b);

#endif                                // ROS2_IPG_Write_Data_Sample1_private_h_

//
// File trailer for generated code.
//
// [EOF]
//
