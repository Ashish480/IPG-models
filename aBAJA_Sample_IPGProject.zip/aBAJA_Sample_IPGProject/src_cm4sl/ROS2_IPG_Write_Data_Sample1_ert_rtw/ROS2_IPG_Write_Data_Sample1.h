//
// File: ROS2_IPG_Write_Data_Sample1.h
//
// Code generated for Simulink model 'ROS2_IPG_Write_Data_Sample1'.
//
// Model version                  : 1.0
// Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
// C/C++ source code generated on : Sat Apr 19 03:00:56 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef ROS2_IPG_Write_Data_Sample1_h_
#define ROS2_IPG_Write_Data_Sample1_h_
#include "rtwtypes.h"
#include "slros2_initialize.h"
#include "ROS2_IPG_Write_Data_Sample1_types.h"
#include <stddef.h>

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

// Block signals (default storage)
struct B_ROS2_IPG_Write_Data_Sample1_T {
  uint32_T b_index_data[921600];
  uint32_T indexBase_data[307200];
  uint32_T y_data[307200];
  SL_Bus_sensor_msgs_Image In1;        // '<S7>/In1'
  SL_Bus_sensor_msgs_Image expl_temp;
  uint8_T uv[921600];
  uint8_T rawImage_data[921600];
  uint8_T busstruct_data_data[921600];
  uint8_T data_data[921600];
  uint8_T data_data_m[921600];
  char_T tmp_data[128];
  uint8_T busstruct_encoding_data[128];
  SL_Bus_geometry_msgs_Vector3 BusAssignment;// '<Root>/Bus Assignment'
  SL_Bus_geometry_msgs_Vector3 BusAssignment1;// '<Root>/Bus Assignment1'
  char_T b_zeroDelimTopic[19];
  char_T b_zeroDelimTopic_c[16];
  sJ4ih70VmKcvCeguWN0mNVF deadline;
  int32_T rawImage_size[3];
  int32_T width[3];
  int32_T tmp_size[3];
  real_T d;
  int32_T busstruct_encoding_size[2];
  int32_T tmp_size_k[2];
  int16_T g[3];
  int32_T g_c;
  int32_T h;
  int32_T loop_ub;
};

// Block states (default storage) for system '<Root>'
struct DW_ROS2_IPG_Write_Data_Sample_T {
  ros_slros2_internal_block_Rea_T obj; // '<Root>/Read Image'
  ros_slros2_internal_block_Pub_T obj_j;// '<S4>/SinkBlock'
  ros_slros2_internal_block_Pub_T obj_l;// '<S3>/SinkBlock'
  ros_slros2_internal_block_Sub_T obj_n;// '<S5>/SourceBlock'
};

// Parameters (default storage)
struct P_ROS2_IPG_Write_Data_Sample1_T_ {
  SL_Bus_sensor_msgs_Image Out1_Y0;    // Computed Parameter: Out1_Y0
                                          //  Referenced by: '<S7>/Out1'

  SL_Bus_sensor_msgs_Image Constant_Value;// Computed Parameter: Constant_Value
                                             //  Referenced by: '<S5>/Constant'

  SL_Bus_geometry_msgs_Vector3 Constant_Value_b;// Computed Parameter: Constant_Value_b
                                                   //  Referenced by: '<S1>/Constant'

  SL_Bus_geometry_msgs_Vector3 Constant_Value_f;// Computed Parameter: Constant_Value_f
                                                   //  Referenced by: '<S2>/Constant'

  real_T Steering_Value;               // Expression: 1
                                          //  Referenced by: '<Root>/Steering'

  real_T Throttle_Value;               // Expression: 1
                                          //  Referenced by: '<Root>/Throttle'

  real_T Brake_Value;                  // Expression: 1
                                          //  Referenced by: '<Root>/Brake'

  real_T Steering_Angle_Vel_Value;     // Expression: 1
                                          //  Referenced by: '<Root>/Steering_Angle_Vel'

  real_T Steering_Angle_Acc_Value;     // Expression: 1
                                          //  Referenced by: '<Root>/Steering_Angle_Acc'

  real_T Selector_Ctrl_Value;          // Expression: 1
                                          //  Referenced by: '<Root>/Selector_Ctrl'

};

// Real-time Model Data Structure
struct tag_RTM_ROS2_IPG_Write_Data_S_T {
  const char_T * volatile errorStatus;
};

// Class declaration for model ROS2_IPG_Write_Data_Sample1
class ROS2_IPG_Write_Data_Sample1
{
  // public data and function members
 public:
  // Real-Time Model get method
  RT_MODEL_ROS2_IPG_Write_Data__T * getRTM();

  // model initialize function
  void initialize();

  // model step function
  void step();

  // model terminate function
  void terminate();

  // Constructor
  ROS2_IPG_Write_Data_Sample1();

  // Destructor
  ~ROS2_IPG_Write_Data_Sample1();

  // private data and function members
 private:
  // Block signals
  B_ROS2_IPG_Write_Data_Sample1_T ROS2_IPG_Write_Data_Sample1_B;

  // Block states
  DW_ROS2_IPG_Write_Data_Sample_T ROS2_IPG_Write_Data_Sample1_DW;

  // Tunable parameters
  static P_ROS2_IPG_Write_Data_Sample1_T ROS2_IPG_Write_Data_Sample1_P;

  // private member function(s) for subsystem '<Root>'
  void ROS2_IPG_Writ_SystemCore_step_g(boolean_T *varargout_1,
    SL_Bus_sensor_msgs_Image *varargout_2);
  void ROS2_IPG_Write_Data_Sample_char(const uint8_T varargin_1_data[], const
    int32_T varargin_1_size[2], char_T y_data[], int32_T y_size[2]);
  boolean_T ROS2_IPG_Write_Data_Samp_strcmp(const char_T a_data[], const int32_T
    a_size[2]);
  void ROS2_IPG_Write_Data_Sam_permute(const uint8_T a_data[], const int32_T
    a_size[3], uint8_T b_data[], int32_T b_size[3]);
  void ROS2_IPG__ImageReader_readImage(const uint8_T data_data[], const int32_T *
    data_size, uint32_T width, uint32_T height, uint8_T img_data[], int32_T
    img_size[3]);
  uint8_T ROS_ReadImage_updateBusAndState(ros_slros2_internal_block_Rea_T *obj,
    uint32_T busstruct_height, uint32_T busstruct_width, const uint8_T
    busstruct_encoding[128], uint32_T busstruct_encoding_SL_Info_Curr, const
    uint8_T busstruct_data[921600], uint32_T busstruct_data_SL_Info_CurrentL,
    uint32_T busstruct_data_SL_Info_Received);
  void ROS2_IPG_Wri_ReadImage_stepImpl(ros_slros2_internal_block_Rea_T *obj,
    uint32_T busstruct_height, uint32_T busstruct_width, const uint8_T
    busstruct_encoding[128], uint32_T busstruct_encoding_SL_Info_Curr, const
    uint8_T busstruct_data[921600], uint32_T busstruct_data_SL_Info_CurrentL,
    uint32_T busstruct_data_SL_Info_Received, uint8_T varargout_1[921600],
    uint8_T *varargout_2);
  void ROS2_IPG_Write__SystemCore_step(ros_slros2_internal_block_Rea_T *obj,
    uint32_T varargin_1_height, uint32_T varargin_1_width, const uint8_T
    varargin_1_encoding[128], uint32_T varargin_1_encoding_SL_Info_Cur, const
    uint8_T varargin_1_data[921600], uint32_T varargin_1_data_SL_Info_Current,
    uint32_T varargin_1_data_SL_Info_Receive, uint8_T varargout_1[921600],
    uint8_T *varargout_2);
  void ROS2_IPG_Write_SystemCore_setup(ros_slros2_internal_block_Sub_T *obj);
  void ROS2_IPG_Wr_Publisher_setupImpl(const ros_slros2_internal_block_Pub_T
    *obj);
  void ROS2_IPG__Publisher_setupImpl_g(const ros_slros2_internal_block_Pub_T
    *obj);

  // Real-Time Model
  RT_MODEL_ROS2_IPG_Write_Data__T ROS2_IPG_Write_Data_Sample1_M;
};

extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<Root>/Display' : Unused code path elimination


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'ROS2_IPG_Write_Data_Sample1'
//  '<S1>'   : 'ROS2_IPG_Write_Data_Sample1/Blank Message'
//  '<S2>'   : 'ROS2_IPG_Write_Data_Sample1/Blank Message1'
//  '<S3>'   : 'ROS2_IPG_Write_Data_Sample1/Publish'
//  '<S4>'   : 'ROS2_IPG_Write_Data_Sample1/Publish1'
//  '<S5>'   : 'ROS2_IPG_Write_Data_Sample1/Subscribe'
//  '<S6>'   : 'ROS2_IPG_Write_Data_Sample1/Subsystem'
//  '<S7>'   : 'ROS2_IPG_Write_Data_Sample1/Subscribe/Enabled Subsystem'
//  '<S8>'   : 'ROS2_IPG_Write_Data_Sample1/Subsystem/Image Processing'

#endif                                 // ROS2_IPG_Write_Data_Sample1_h_

//
// File trailer for generated code.
//
// [EOF]
//
