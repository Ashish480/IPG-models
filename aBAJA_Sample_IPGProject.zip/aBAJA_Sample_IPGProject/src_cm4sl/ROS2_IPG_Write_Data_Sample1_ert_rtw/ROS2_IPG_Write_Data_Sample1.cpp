//
// File: ROS2_IPG_Write_Data_Sample1.cpp
//
// Code generated for Simulink model 'ROS2_IPG_Write_Data_Sample1'.
//
// Model version                  : 1.0
// Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
// C/C++ source code generated on : Sat Apr 19 03:00:56 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "ROS2_IPG_Write_Data_Sample1.h"
#include "ROS2_IPG_Write_Data_Sample1_types.h"
#include "rtwtypes.h"
#include <string.h>
#include "rmw/qos_profiles.h"
#include <stddef.h>
#include "ROS2_IPG_Write_Data_Sample1_private.h"

void mul_wide_u32(uint32_T in0, uint32_T in1, uint32_T *ptrOutBitsHi, uint32_T
                  *ptrOutBitsLo)
{
  uint32_T in0Hi;
  uint32_T in0Lo;
  uint32_T in1Hi;
  uint32_T in1Lo;
  uint32_T outBitsLo;
  uint32_T productHiLo;
  uint32_T productLoHi;
  in0Hi = in0 >> 16U;
  in0Lo = in0 & 65535U;
  in1Hi = in1 >> 16U;
  in1Lo = in1 & 65535U;
  productHiLo = in0Hi * in1Lo;
  productLoHi = in0Lo * in1Hi;
  in0Lo *= in1Lo;
  in1Lo = 0U;
  outBitsLo = (productLoHi << /*MW:OvBitwiseOk*/ 16U) + /*MW:OvCarryOk*/ in0Lo;
  if (outBitsLo < in0Lo) {
    in1Lo = 1U;
  }

  in0Lo = outBitsLo;
  outBitsLo += /*MW:OvCarryOk*/ productHiLo << /*MW:OvBitwiseOk*/ 16U;
  if (outBitsLo < in0Lo) {
    in1Lo++;
  }

  *ptrOutBitsHi = (((productLoHi >> 16U) + (productHiLo >> 16U)) + in0Hi * in1Hi)
    + in1Lo;
  *ptrOutBitsLo = outBitsLo;
}

uint32_T mul_u32_sat(uint32_T a, uint32_T b)
{
  uint32_T result;
  uint32_T u32_chi;
  mul_wide_u32(a, b, &u32_chi, &result);
  if (u32_chi) {
    result = MAX_uint32_T;
  }

  return result;
}

void ROS2_IPG_Write_Data_Sample1::ROS2_IPG_Writ_SystemCore_step_g(boolean_T
  *varargout_1, SL_Bus_sensor_msgs_Image *varargout_2)
{
  *varargout_1 = Sub_ROS2_IPG_Write_Data_Sample1_1.getLatestMessage(varargout_2);
}

void ROS2_IPG_Write_Data_Sample1::ROS2_IPG_Write_Data_Sample_char(const uint8_T
  varargin_1_data[], const int32_T varargin_1_size[2], char_T y_data[], int32_T
  y_size[2])
{
  int32_T loop_ub;
  y_size[0] = 1;

  // Start for MATLABSystem: '<Root>/Read Image'
  // Start for MATLABSystem: '<Root>/Read Image'
  loop_ub = varargin_1_size[1];
  y_size[1] = varargin_1_size[1];
  for (int32_T y_data_tmp = 0; y_data_tmp < loop_ub; y_data_tmp++) {
    // Start for MATLABSystem: '<Root>/Read Image'
    y_data[y_data_tmp] = static_cast<int8_T>(varargin_1_data[y_data_tmp]);
  }
}

boolean_T ROS2_IPG_Write_Data_Sample1::ROS2_IPG_Write_Data_Samp_strcmp(const
  char_T a_data[], const int32_T a_size[2])
{
  boolean_T b_bool;
  static const char_T tmp[128] = { '\x00', '\x01', '\x02', '\x03', '\x04',
    '\x05', '\x06', '\a', '\b', '\t', '\n', '\v', '\f', '\r', '\x0e', '\x0f',
    '\x10', '\x11', '\x12', '\x13', '\x14', '\x15', '\x16', '\x17', '\x18',
    '\x19', '\x1a', '\x1b', '\x1c', '\x1d', '\x1e', '\x1f', ' ', '!', '\"', '#',
    '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2',
    '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'a',
    'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
    'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '[', '\\', ']', '^', '_',
    '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
    'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}',
    '~', '\x7f' };

  static const char_T tmp_0[4] = { 'r', 'g', 'b', '8' };

  b_bool = false;

  // Start for MATLABSystem: '<Root>/Read Image'
  if (a_size[1] == 4) {
    int32_T b_kstr;
    b_kstr = 1;
    int32_T exitg1;
    do {
      exitg1 = 0;
      if (b_kstr - 1 < 4) {
        if (tmp[static_cast<uint8_T>(a_data[b_kstr - 1]) & 127] != tmp[
            static_cast<int32_T>(tmp_0[b_kstr - 1])]) {
          exitg1 = 1;
        } else {
          b_kstr++;
        }
      } else {
        b_bool = true;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }

  // End of Start for MATLABSystem: '<Root>/Read Image'
  return b_bool;
}

void ROS2_IPG_Write_Data_Sample1::ROS2_IPG_Write_Data_Sam_permute(const uint8_T
  a_data[], const int32_T a_size[3], uint8_T b_data[], int32_T b_size[3])
{
  int32_T b_k_0;
  int32_T d;
  int32_T plast;
  boolean_T b;
  static const int8_T tmp[3] = { 2, 1, 3 };

  b = true;

  // Start for MATLABSystem: '<Root>/Read Image'
  if ((a_size[0] != 0) && (a_size[1] != 0)) {
    boolean_T exitg1;
    plast = 0;
    b_k_0 = 1;
    exitg1 = false;
    while ((!exitg1) && (b_k_0 - 1 < 3)) {
      d = tmp[b_k_0 - 1];
      if (a_size[d - 1] != 1) {
        if (plast > d) {
          b = false;
          exitg1 = true;
        } else {
          plast = d;
          b_k_0++;
        }
      } else {
        b_k_0++;
      }
    }
  }

  if (b) {
    int32_T d_0;

    // Start for MATLABSystem: '<Root>/Read Image'
    b_size[0] = a_size[1];
    b_size[1] = a_size[0];
    b_size[2] = 3;

    // Start for MATLABSystem: '<Root>/Read Image'
    d_0 = a_size[0] * a_size[1] * 3;
    if (d_0 - 1 >= 0) {
      memcpy(&b_data[0], &a_data[0], static_cast<uint32_T>(d_0) * sizeof(uint8_T));
    }
  } else {
    // Start for MATLABSystem: '<Root>/Read Image'
    b_size[0] = a_size[1];
    b_size[1] = a_size[0];
    b_size[2] = 3;
    d = a_size[1] - 1;
    for (b_k_0 = 0; b_k_0 < 3; b_k_0++) {
      for (plast = 0; plast <= d; plast++) {
        int32_T d_0;

        // Start for MATLABSystem: '<Root>/Read Image'
        d_0 = a_size[0] - 1;
        for (int32_T b_k = 0; b_k <= d_0; b_k++) {
          // Start for MATLABSystem: '<Root>/Read Image'
          b_data[(plast + b_size[0] * b_k) + b_size[0] * b_size[1] * b_k_0] =
            a_data[(a_size[0] * plast + b_k) + a_size[0] * a_size[1] * b_k_0];
        }
      }
    }
  }
}

void ROS2_IPG_Write_Data_Sample1::ROS2_IPG__ImageReader_readImage(const uint8_T
  data_data[], const int32_T *data_size, uint32_T width, uint32_T height,
  uint8_T img_data[], int32_T img_size[3])
{
  int32_T b_i;
  int32_T b_index_data_tmp;
  int32_T b_k;
  int32_T loop_ub_tmp;
  int32_T n;
  uint32_T y;
  if (*data_size == 0) {
    // Start for MATLABSystem: '<Root>/Read Image'
    memcpy((void *)&ROS2_IPG_Write_Data_Sample1_B.data_data[0], (void *)
           &data_data[0], (uint32_T)((size_t)0 * sizeof(uint8_T)));
    img_size[0] = 0;
    img_size[1] = 1;
    img_size[2] = 1;
  } else {
    // Start for MATLABSystem: '<Root>/Read Image'
    memcpy((void *)&ROS2_IPG_Write_Data_Sample1_B.data_data[0], (void *)
           &data_data[0], (uint32_T)((size_t)*data_size * sizeof(uint8_T)));
    y = mul_u32_sat(mul_u32_sat(width, height), 3U);
    if (y < 1U) {
      n = 0;
    } else {
      n = static_cast<int32_T>((y - 1U) / 3U) + 1;
    }

    for (b_k = 0; b_k < n; b_k++) {
      // Start for MATLABSystem: '<Root>/Read Image'
      ROS2_IPG_Write_Data_Sample1_B.y_data[b_k] = static_cast<uint32_T>(b_k) *
        3U + 1U;
    }

    if (n - 1 >= 0) {
      memcpy(&ROS2_IPG_Write_Data_Sample1_B.indexBase_data[0],
             &ROS2_IPG_Write_Data_Sample1_B.y_data[0], static_cast<uint32_T>(n) *
             sizeof(uint32_T));
    }

    // Start for MATLABSystem: '<Root>/Read Image'
    loop_ub_tmp = n * 3;
    if (loop_ub_tmp - 1 >= 0) {
      memset(&ROS2_IPG_Write_Data_Sample1_B.b_index_data[0], 0,
             static_cast<uint32_T>(loop_ub_tmp) * sizeof(uint32_T));
    }

    for (b_i = 0; b_i < 3; b_i++) {
      for (b_k = 0; b_k < n; b_k++) {
        // Start for MATLABSystem: '<Root>/Read Image'
        ROS2_IPG_Write_Data_Sample1_B.d = (static_cast<real_T>(b_i) + 1.0) +
          static_cast<real_T>(ROS2_IPG_Write_Data_Sample1_B.indexBase_data[b_k]);
        if (ROS2_IPG_Write_Data_Sample1_B.d < 4.294967296E+9) {
          y = static_cast<uint32_T>(ROS2_IPG_Write_Data_Sample1_B.d);
        } else {
          y = MAX_uint32_T;
        }

        b_index_data_tmp = n * b_i + b_k;

        // MW:begin MISRA2012:D4.1 CERT-C:INT30-C 'Justifying MISRA CPP rule violation' 
        ROS2_IPG_Write_Data_Sample1_B.b_index_data[b_index_data_tmp] = y -
          /*MW:OvSatOk*/ 1U;

        // MW:end MISRA2012:D4.1 CERT-C:INT30-C
        if (y - 1U > y) {
          ROS2_IPG_Write_Data_Sample1_B.b_index_data[b_index_data_tmp] = 0U;
        }
      }
    }

    // Start for MATLABSystem: '<Root>/Read Image'
    for (b_k = 0; b_k < loop_ub_tmp; b_k++) {
      ROS2_IPG_Write_Data_Sample1_B.data_data_m[b_k] =
        ROS2_IPG_Write_Data_Sample1_B.data_data[static_cast<int32_T>
        (ROS2_IPG_Write_Data_Sample1_B.b_index_data[b_k]) - 1];
    }

    ROS2_IPG_Write_Data_Sample1_B.width[0] = static_cast<int32_T>(width);
    ROS2_IPG_Write_Data_Sample1_B.width[1] = static_cast<int32_T>(height);
    ROS2_IPG_Write_Data_Sample1_B.width[2] = 3;
    ROS2_IPG_Write_Data_Sam_permute(ROS2_IPG_Write_Data_Sample1_B.data_data_m,
      ROS2_IPG_Write_Data_Sample1_B.width,
      ROS2_IPG_Write_Data_Sample1_B.data_data,
      ROS2_IPG_Write_Data_Sample1_B.tmp_size);
    img_size[0] = ROS2_IPG_Write_Data_Sample1_B.tmp_size[0];
    img_size[1] = ROS2_IPG_Write_Data_Sample1_B.tmp_size[1];
    img_size[2] = 3;
    n = ROS2_IPG_Write_Data_Sample1_B.tmp_size[0] *
      ROS2_IPG_Write_Data_Sample1_B.tmp_size[1] * 3;
    if (n - 1 >= 0) {
      memcpy(&img_data[0], &ROS2_IPG_Write_Data_Sample1_B.data_data[0],
             static_cast<uint32_T>(n) * sizeof(uint8_T));
    }
  }
}

uint8_T ROS2_IPG_Write_Data_Sample1::ROS_ReadImage_updateBusAndState
  (ros_slros2_internal_block_Rea_T *obj, uint32_T busstruct_height, uint32_T
   busstruct_width, const uint8_T busstruct_encoding[128], uint32_T
   busstruct_encoding_SL_Info_Curr, const uint8_T busstruct_data[921600],
   uint32_T busstruct_data_SL_Info_CurrentL, uint32_T
   busstruct_data_SL_Info_Received)
{
  int32_T busstruct_data_size;
  int32_T i;
  int32_T i_0;
  uint8_T errorCode;
  if (busstruct_data_SL_Info_CurrentL < busstruct_data_SL_Info_Received) {
    errorCode = 3U;
  } else {
    if (busstruct_encoding_SL_Info_Curr < 1U) {
      // Start for MATLABSystem: '<Root>/Read Image'
      ROS2_IPG_Write_Data_Sample1_B.loop_ub = 0;
    } else {
      // Start for MATLABSystem: '<Root>/Read Image'
      ROS2_IPG_Write_Data_Sample1_B.loop_ub = static_cast<int32_T>
        (busstruct_encoding_SL_Info_Curr);
    }

    // Start for MATLABSystem: '<Root>/Read Image'
    // Start for MATLABSystem: '<Root>/Read Image'
    ROS2_IPG_Write_Data_Sample1_B.busstruct_encoding_size[0] = 1;
    ROS2_IPG_Write_Data_Sample1_B.busstruct_encoding_size[1] =
      ROS2_IPG_Write_Data_Sample1_B.loop_ub;
    if (ROS2_IPG_Write_Data_Sample1_B.loop_ub - 1 >= 0) {
      memcpy(&ROS2_IPG_Write_Data_Sample1_B.busstruct_encoding_data[0],
             &busstruct_encoding[0], static_cast<uint32_T>
             (ROS2_IPG_Write_Data_Sample1_B.loop_ub) * sizeof(uint8_T));
    }

    ROS2_IPG_Write_Data_Sample_char
      (ROS2_IPG_Write_Data_Sample1_B.busstruct_encoding_data,
       ROS2_IPG_Write_Data_Sample1_B.busstruct_encoding_size,
       ROS2_IPG_Write_Data_Sample1_B.tmp_data,
       ROS2_IPG_Write_Data_Sample1_B.tmp_size_k);
    if (!ROS2_IPG_Write_Data_Samp_strcmp(ROS2_IPG_Write_Data_Sample1_B.tmp_data,
         ROS2_IPG_Write_Data_Sample1_B.tmp_size_k)) {
      errorCode = 1U;
    } else {
      if ((busstruct_height > 480U) || (busstruct_width > 640U)) {
        errorCode = 2U;
        ROS2_IPG_Write_Data_Sample1_B.rawImage_size[0] = 480;
        ROS2_IPG_Write_Data_Sample1_B.rawImage_size[1] = 640;
        ROS2_IPG_Write_Data_Sample1_B.rawImage_size[2] = 3;

        // Start for MATLABSystem: '<Root>/Read Image'
        memcpy(&ROS2_IPG_Write_Data_Sample1_B.rawImage_data[0], &obj->Image[0],
               921600U * sizeof(uint8_T));
      } else {
        if (busstruct_data_SL_Info_CurrentL < 1U) {
          // Start for MATLABSystem: '<Root>/Read Image'
          ROS2_IPG_Write_Data_Sample1_B.loop_ub = 0;
        } else {
          // Start for MATLABSystem: '<Root>/Read Image'
          ROS2_IPG_Write_Data_Sample1_B.loop_ub = static_cast<int32_T>
            (busstruct_data_SL_Info_CurrentL);
        }

        // Start for MATLABSystem: '<Root>/Read Image'
        busstruct_data_size = ROS2_IPG_Write_Data_Sample1_B.loop_ub;
        if (ROS2_IPG_Write_Data_Sample1_B.loop_ub - 1 >= 0) {
          memcpy(&ROS2_IPG_Write_Data_Sample1_B.busstruct_data_data[0],
                 &busstruct_data[0], static_cast<uint32_T>
                 (ROS2_IPG_Write_Data_Sample1_B.loop_ub) * sizeof(uint8_T));
        }

        ROS2_IPG__ImageReader_readImage
          (ROS2_IPG_Write_Data_Sample1_B.busstruct_data_data,
           &busstruct_data_size, busstruct_width, busstruct_height,
           ROS2_IPG_Write_Data_Sample1_B.rawImage_data,
           ROS2_IPG_Write_Data_Sample1_B.rawImage_size);
        errorCode = 0U;
      }

      if (errorCode == 0) {
        memset(&obj->Image[0], 0, 921600U * sizeof(uint8_T));
        if (ROS2_IPG_Write_Data_Sample1_B.rawImage_size[0] < 1) {
          ROS2_IPG_Write_Data_Sample1_B.g_c = 0;
        } else {
          ROS2_IPG_Write_Data_Sample1_B.g_c =
            ROS2_IPG_Write_Data_Sample1_B.rawImage_size[0];
        }

        if (ROS2_IPG_Write_Data_Sample1_B.rawImage_size[1] < 1) {
          ROS2_IPG_Write_Data_Sample1_B.h = 0;
        } else {
          ROS2_IPG_Write_Data_Sample1_B.h =
            ROS2_IPG_Write_Data_Sample1_B.rawImage_size[1];
        }

        if (ROS2_IPG_Write_Data_Sample1_B.rawImage_size[0] < 1) {
          ROS2_IPG_Write_Data_Sample1_B.g[0] = 0;
        } else {
          ROS2_IPG_Write_Data_Sample1_B.g[0] = static_cast<int16_T>
            (ROS2_IPG_Write_Data_Sample1_B.rawImage_size[0]);
        }

        if (ROS2_IPG_Write_Data_Sample1_B.rawImage_size[1] < 1) {
          ROS2_IPG_Write_Data_Sample1_B.g[1] = 0;
        } else {
          ROS2_IPG_Write_Data_Sample1_B.g[1] = static_cast<int16_T>
            (ROS2_IPG_Write_Data_Sample1_B.rawImage_size[1]);
        }

        ROS2_IPG_Write_Data_Sample1_B.loop_ub =
          ROS2_IPG_Write_Data_Sample1_B.rawImage_size[2];
        for (busstruct_data_size = 0; busstruct_data_size <
             ROS2_IPG_Write_Data_Sample1_B.loop_ub; busstruct_data_size++) {
          for (i_0 = 0; i_0 < ROS2_IPG_Write_Data_Sample1_B.h; i_0++) {
            for (i = 0; i < ROS2_IPG_Write_Data_Sample1_B.g_c; i++) {
              obj->Image[(i + 480 * i_0) + 307200 * busstruct_data_size] =
                ROS2_IPG_Write_Data_Sample1_B.rawImage_data
                [(ROS2_IPG_Write_Data_Sample1_B.g[0] * i_0 + i) +
                ROS2_IPG_Write_Data_Sample1_B.g[0] *
                ROS2_IPG_Write_Data_Sample1_B.g[1] * busstruct_data_size];
            }
          }
        }

        obj->ImageSize[0] = static_cast<uint32_T>
          (ROS2_IPG_Write_Data_Sample1_B.rawImage_size[0]);
        obj->ImageSize[1] = static_cast<uint32_T>
          (ROS2_IPG_Write_Data_Sample1_B.rawImage_size[1]);
        errorCode = 0U;
      }
    }
  }

  return errorCode;
}

void ROS2_IPG_Write_Data_Sample1::ROS2_IPG_Wri_ReadImage_stepImpl
  (ros_slros2_internal_block_Rea_T *obj, uint32_T busstruct_height, uint32_T
   busstruct_width, const uint8_T busstruct_encoding[128], uint32_T
   busstruct_encoding_SL_Info_Curr, const uint8_T busstruct_data[921600],
   uint32_T busstruct_data_SL_Info_CurrentL, uint32_T
   busstruct_data_SL_Info_Received, uint8_T varargout_1[921600], uint8_T
   *varargout_2)
{
  *varargout_2 = ROS_ReadImage_updateBusAndState(obj, busstruct_height,
    busstruct_width, busstruct_encoding, busstruct_encoding_SL_Info_Curr,
    busstruct_data, busstruct_data_SL_Info_CurrentL,
    busstruct_data_SL_Info_Received);

  // Start for MATLABSystem: '<Root>/Read Image'
  memcpy(&varargout_1[0], &obj->Image[0], 921600U * sizeof(uint8_T));
}

void ROS2_IPG_Write_Data_Sample1::ROS2_IPG_Write__SystemCore_step
  (ros_slros2_internal_block_Rea_T *obj, uint32_T varargin_1_height, uint32_T
   varargin_1_width, const uint8_T varargin_1_encoding[128], uint32_T
   varargin_1_encoding_SL_Info_Cur, const uint8_T varargin_1_data[921600],
   uint32_T varargin_1_data_SL_Info_Current, uint32_T
   varargin_1_data_SL_Info_Receive, uint8_T varargout_1[921600], uint8_T
   *varargout_2)
{
  ROS2_IPG_Wri_ReadImage_stepImpl(obj, varargin_1_height, varargin_1_width,
    varargin_1_encoding, varargin_1_encoding_SL_Info_Cur, varargin_1_data,
    varargin_1_data_SL_Info_Current, varargin_1_data_SL_Info_Receive,
    varargout_1, varargout_2);
}

void ROS2_IPG_Write_Data_Sample1::ROS2_IPG_Write_SystemCore_setup
  (ros_slros2_internal_block_Sub_T *obj)
{
  rmw_qos_profile_t qos_profile;
  sJ4ih70VmKcvCeguWN0mNVF lifespan;
  sJ4ih70VmKcvCeguWN0mNVF liveliness_lease_duration;
  char_T b_zeroDelimTopic[14];
  static const char_T b_zeroDelimTopic_0[14] = "/cameraImages";

  // Start for MATLABSystem: '<S5>/SourceBlock'
  obj->isInitialized = 1;
  qos_profile = rmw_qos_profile_default;

  // Start for MATLABSystem: '<S5>/SourceBlock'
  ROS2_IPG_Write_Data_Sample1_B.deadline.sec = 0.0;
  ROS2_IPG_Write_Data_Sample1_B.deadline.nsec = 0.0;
  lifespan.sec = 0.0;
  lifespan.nsec = 0.0;
  liveliness_lease_duration.sec = 0.0;
  liveliness_lease_duration.nsec = 0.0;
  SET_QOS_VALUES(qos_profile, RMW_QOS_POLICY_HISTORY_KEEP_LAST, (size_t)1.0,
                 RMW_QOS_POLICY_DURABILITY_VOLATILE,
                 RMW_QOS_POLICY_RELIABILITY_RELIABLE,
                 ROS2_IPG_Write_Data_Sample1_B.deadline, lifespan,
                 RMW_QOS_POLICY_LIVELINESS_AUTOMATIC, liveliness_lease_duration,
                 (bool)obj->QOSAvoidROSNamespaceConventions);
  for (int32_T i = 0; i < 14; i++) {
    // Start for MATLABSystem: '<S5>/SourceBlock'
    b_zeroDelimTopic[i] = b_zeroDelimTopic_0[i];
  }

  Sub_ROS2_IPG_Write_Data_Sample1_1.createSubscriber(&b_zeroDelimTopic[0],
    qos_profile);
  obj->isSetupComplete = true;
}

void ROS2_IPG_Write_Data_Sample1::ROS2_IPG_Wr_Publisher_setupImpl(const
  ros_slros2_internal_block_Pub_T *obj)
{
  rmw_qos_profile_t qos_profile;
  sJ4ih70VmKcvCeguWN0mNVF deadline;
  sJ4ih70VmKcvCeguWN0mNVF lifespan;
  sJ4ih70VmKcvCeguWN0mNVF liveliness_lease_duration;
  static const char_T b_zeroDelimTopic[16] = "/vehicleControl";
  qos_profile = rmw_qos_profile_default;

  // Start for MATLABSystem: '<S3>/SinkBlock'
  deadline.sec = 0.0;
  deadline.nsec = 0.0;
  lifespan.sec = 0.0;
  lifespan.nsec = 0.0;
  liveliness_lease_duration.sec = 0.0;
  liveliness_lease_duration.nsec = 0.0;
  SET_QOS_VALUES(qos_profile, RMW_QOS_POLICY_HISTORY_KEEP_LAST, (size_t)1.0,
                 RMW_QOS_POLICY_DURABILITY_VOLATILE,
                 RMW_QOS_POLICY_RELIABILITY_RELIABLE, deadline, lifespan,
                 RMW_QOS_POLICY_LIVELINESS_AUTOMATIC, liveliness_lease_duration,
                 (bool)obj->QOSAvoidROSNamespaceConventions);
  for (int32_T i = 0; i < 16; i++) {
    // Start for MATLABSystem: '<S3>/SinkBlock'
    ROS2_IPG_Write_Data_Sample1_B.b_zeroDelimTopic_c[i] = b_zeroDelimTopic[i];
  }

  Pub_ROS2_IPG_Write_Data_Sample1_18.createPublisher
    (&ROS2_IPG_Write_Data_Sample1_B.b_zeroDelimTopic_c[0], qos_profile);
}

void ROS2_IPG_Write_Data_Sample1::ROS2_IPG__Publisher_setupImpl_g(const
  ros_slros2_internal_block_Pub_T *obj)
{
  rmw_qos_profile_t qos_profile;
  sJ4ih70VmKcvCeguWN0mNVF deadline;
  sJ4ih70VmKcvCeguWN0mNVF lifespan;
  sJ4ih70VmKcvCeguWN0mNVF liveliness_lease_duration;
  static const char_T b_zeroDelimTopic[19] = "/vehicleControlAdd";
  qos_profile = rmw_qos_profile_default;

  // Start for MATLABSystem: '<S4>/SinkBlock'
  deadline.sec = 0.0;
  deadline.nsec = 0.0;
  lifespan.sec = 0.0;
  lifespan.nsec = 0.0;
  liveliness_lease_duration.sec = 0.0;
  liveliness_lease_duration.nsec = 0.0;
  SET_QOS_VALUES(qos_profile, RMW_QOS_POLICY_HISTORY_KEEP_LAST, (size_t)1.0,
                 RMW_QOS_POLICY_DURABILITY_VOLATILE,
                 RMW_QOS_POLICY_RELIABILITY_RELIABLE, deadline, lifespan,
                 RMW_QOS_POLICY_LIVELINESS_AUTOMATIC, liveliness_lease_duration,
                 (bool)obj->QOSAvoidROSNamespaceConventions);
  for (int32_T i = 0; i < 19; i++) {
    // Start for MATLABSystem: '<S4>/SinkBlock'
    ROS2_IPG_Write_Data_Sample1_B.b_zeroDelimTopic[i] = b_zeroDelimTopic[i];
  }

  Pub_ROS2_IPG_Write_Data_Sample1_29.createPublisher
    (&ROS2_IPG_Write_Data_Sample1_B.b_zeroDelimTopic[0], qos_profile);
}

// Model step function
void ROS2_IPG_Write_Data_Sample1::step()
{
  uint8_T b_varargout_2;
  boolean_T b_varargout_1;

  // MATLABSystem: '<S5>/SourceBlock'
  ROS2_IPG_Writ_SystemCore_step_g(&b_varargout_1,
    &ROS2_IPG_Write_Data_Sample1_B.expl_temp);

  // Outputs for Enabled SubSystem: '<S5>/Enabled Subsystem' incorporates:
  //   EnablePort: '<S7>/Enable'

  // Start for MATLABSystem: '<S5>/SourceBlock'
  if (b_varargout_1) {
    // SignalConversion generated from: '<S7>/In1'
    ROS2_IPG_Write_Data_Sample1_B.In1 = ROS2_IPG_Write_Data_Sample1_B.expl_temp;
  }

  // End of Start for MATLABSystem: '<S5>/SourceBlock'
  // End of Outputs for SubSystem: '<S5>/Enabled Subsystem'

  // MATLABSystem: '<Root>/Read Image'
  ROS2_IPG_Write__SystemCore_step(&ROS2_IPG_Write_Data_Sample1_DW.obj,
    ROS2_IPG_Write_Data_Sample1_B.In1.height,
    ROS2_IPG_Write_Data_Sample1_B.In1.width,
    ROS2_IPG_Write_Data_Sample1_B.In1.encoding,
    ROS2_IPG_Write_Data_Sample1_B.In1.encoding_SL_Info.CurrentLength,
    ROS2_IPG_Write_Data_Sample1_B.In1.data,
    ROS2_IPG_Write_Data_Sample1_B.In1.data_SL_Info.CurrentLength,
    ROS2_IPG_Write_Data_Sample1_B.In1.data_SL_Info.ReceivedLength,
    ROS2_IPG_Write_Data_Sample1_B.uv, &b_varargout_2);

  // BusAssignment: '<Root>/Bus Assignment' incorporates:
  //   Constant: '<Root>/Brake'
  //   Constant: '<Root>/Steering'
  //   Constant: '<Root>/Throttle'

  ROS2_IPG_Write_Data_Sample1_B.BusAssignment.x =
    ROS2_IPG_Write_Data_Sample1_P.Steering_Value;
  ROS2_IPG_Write_Data_Sample1_B.BusAssignment.y =
    ROS2_IPG_Write_Data_Sample1_P.Throttle_Value;
  ROS2_IPG_Write_Data_Sample1_B.BusAssignment.z =
    ROS2_IPG_Write_Data_Sample1_P.Brake_Value;

  // MATLABSystem: '<S3>/SinkBlock'
  Pub_ROS2_IPG_Write_Data_Sample1_18.publish
    (&ROS2_IPG_Write_Data_Sample1_B.BusAssignment);

  // BusAssignment: '<Root>/Bus Assignment1' incorporates:
  //   Constant: '<Root>/Selector_Ctrl'
  //   Constant: '<Root>/Steering_Angle_Acc'
  //   Constant: '<Root>/Steering_Angle_Vel'

  ROS2_IPG_Write_Data_Sample1_B.BusAssignment1.x =
    ROS2_IPG_Write_Data_Sample1_P.Steering_Angle_Vel_Value;
  ROS2_IPG_Write_Data_Sample1_B.BusAssignment1.y =
    ROS2_IPG_Write_Data_Sample1_P.Steering_Angle_Acc_Value;
  ROS2_IPG_Write_Data_Sample1_B.BusAssignment1.z =
    ROS2_IPG_Write_Data_Sample1_P.Selector_Ctrl_Value;

  // MATLABSystem: '<S4>/SinkBlock'
  Pub_ROS2_IPG_Write_Data_Sample1_29.publish
    (&ROS2_IPG_Write_Data_Sample1_B.BusAssignment1);
}

// Model initialize function
void ROS2_IPG_Write_Data_Sample1::initialize()
{
  // SystemInitialize for Enabled SubSystem: '<S5>/Enabled Subsystem'
  // SystemInitialize for SignalConversion generated from: '<S7>/In1' incorporates:
  //   Outport: '<S7>/Out1'

  ROS2_IPG_Write_Data_Sample1_B.In1 = ROS2_IPG_Write_Data_Sample1_P.Out1_Y0;

  // End of SystemInitialize for SubSystem: '<S5>/Enabled Subsystem'

  // Start for MATLABSystem: '<S5>/SourceBlock'
  ROS2_IPG_Write_SystemCore_setup(&ROS2_IPG_Write_Data_Sample1_DW.obj_n);

  // Start for MATLABSystem: '<Root>/Read Image'
  ROS2_IPG_Write_Data_Sample1_DW.obj.isInitialized = 1;

  // InitializeConditions for MATLABSystem: '<Root>/Read Image'
  memset(&ROS2_IPG_Write_Data_Sample1_DW.obj.Image[0], 0, 921600U * sizeof
         (uint8_T));
  ROS2_IPG_Write_Data_Sample1_DW.obj.ImageSize[0] = 480U;
  ROS2_IPG_Write_Data_Sample1_DW.obj.ImageSize[1] = 640U;

  // Start for MATLABSystem: '<S3>/SinkBlock'
  ROS2_IPG_Write_Data_Sample1_DW.obj_l.QOSAvoidROSNamespaceConventions = false;
  ROS2_IPG_Write_Data_Sample1_DW.obj_l.matlabCodegenIsDeleted = false;
  ROS2_IPG_Write_Data_Sample1_DW.obj_l.isSetupComplete = false;
  ROS2_IPG_Write_Data_Sample1_DW.obj_l.isInitialized = 1;
  ROS2_IPG_Wr_Publisher_setupImpl(&ROS2_IPG_Write_Data_Sample1_DW.obj_l);
  ROS2_IPG_Write_Data_Sample1_DW.obj_l.isSetupComplete = true;

  // Start for MATLABSystem: '<S4>/SinkBlock'
  ROS2_IPG_Write_Data_Sample1_DW.obj_j.QOSAvoidROSNamespaceConventions = false;
  ROS2_IPG_Write_Data_Sample1_DW.obj_j.matlabCodegenIsDeleted = false;
  ROS2_IPG_Write_Data_Sample1_DW.obj_j.isSetupComplete = false;
  ROS2_IPG_Write_Data_Sample1_DW.obj_j.isInitialized = 1;
  ROS2_IPG__Publisher_setupImpl_g(&ROS2_IPG_Write_Data_Sample1_DW.obj_j);
  ROS2_IPG_Write_Data_Sample1_DW.obj_j.isSetupComplete = true;
}

// Model terminate function
void ROS2_IPG_Write_Data_Sample1::terminate()
{
  // Terminate for MATLABSystem: '<S5>/SourceBlock'
  if (!ROS2_IPG_Write_Data_Sample1_DW.obj_n.matlabCodegenIsDeleted) {
    ROS2_IPG_Write_Data_Sample1_DW.obj_n.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S5>/SourceBlock'

  // Terminate for MATLABSystem: '<S3>/SinkBlock'
  if (!ROS2_IPG_Write_Data_Sample1_DW.obj_l.matlabCodegenIsDeleted) {
    ROS2_IPG_Write_Data_Sample1_DW.obj_l.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S3>/SinkBlock'

  // Terminate for MATLABSystem: '<S4>/SinkBlock'
  if (!ROS2_IPG_Write_Data_Sample1_DW.obj_j.matlabCodegenIsDeleted) {
    ROS2_IPG_Write_Data_Sample1_DW.obj_j.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S4>/SinkBlock'
}

// Constructor
ROS2_IPG_Write_Data_Sample1::ROS2_IPG_Write_Data_Sample1() :
  ROS2_IPG_Write_Data_Sample1_B(),
  ROS2_IPG_Write_Data_Sample1_DW(),
  ROS2_IPG_Write_Data_Sample1_M()
{
  // Currently there is no constructor body generated.
}

// Destructor
ROS2_IPG_Write_Data_Sample1::~ROS2_IPG_Write_Data_Sample1()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
RT_MODEL_ROS2_IPG_Write_Data__T * ROS2_IPG_Write_Data_Sample1::getRTM()
{
  return (&ROS2_IPG_Write_Data_Sample1_M);
}

//
// File trailer for generated code.
//
// [EOF]
//
