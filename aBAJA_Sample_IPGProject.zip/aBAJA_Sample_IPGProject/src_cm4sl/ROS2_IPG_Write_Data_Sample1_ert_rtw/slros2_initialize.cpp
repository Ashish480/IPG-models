// Copyright 2022-2023 The MathWorks, Inc.
// Generated 21-Apr-2025 01:40:35
#include "slros2_initialize.h"
// ROS2_IPG_Write_Data_Sample1/Publish
SimulinkPublisher<geometry_msgs::msg::Vector3,SL_Bus_geometry_msgs_Vector3> Pub_ROS2_IPG_Write_Data_Sample1_18;
// ROS2_IPG_Write_Data_Sample1/Publish1
SimulinkPublisher<geometry_msgs::msg::Vector3,SL_Bus_geometry_msgs_Vector3> Pub_ROS2_IPG_Write_Data_Sample1_29;
// ROS2_IPG_Write_Data_Sample1/Subscribe
SimulinkSubscriber<sensor_msgs::msg::Image,SL_Bus_sensor_msgs_Image> Sub_ROS2_IPG_Write_Data_Sample1_1;
