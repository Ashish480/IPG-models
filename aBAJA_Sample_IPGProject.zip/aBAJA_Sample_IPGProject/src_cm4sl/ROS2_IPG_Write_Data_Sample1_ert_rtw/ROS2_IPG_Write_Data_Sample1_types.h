//
// File: ROS2_IPG_Write_Data_Sample1_types.h
//
// Code generated for Simulink model 'ROS2_IPG_Write_Data_Sample1'.
//
// Model version                  : 1.0
// Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
// C/C++ source code generated on : Sat Apr 19 03:00:56 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef ROS2_IPG_Write_Data_Sample1_types_h_
#define ROS2_IPG_Write_Data_Sample1_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_Vector3_
#define DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_Vector3_

// MsgType=geometry_msgs/Vector3
struct SL_Bus_geometry_msgs_Vector3
{
  real_T x;
  real_T y;
  real_T z;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_builtin_interfaces_Time_
#define DEFINED_TYPEDEF_FOR_SL_Bus_builtin_interfaces_Time_

// MsgType=builtin_interfaces/Time
struct SL_Bus_builtin_interfaces_Time
{
  int32_T sec;
  uint32_T nanosec;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_ROSVariableLengthArrayInfo_
#define DEFINED_TYPEDEF_FOR_SL_Bus_ROSVariableLengthArrayInfo_

struct SL_Bus_ROSVariableLengthArrayInfo
{
  uint32_T CurrentLength;
  uint32_T ReceivedLength;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_std_msgs_Header_
#define DEFINED_TYPEDEF_FOR_SL_Bus_std_msgs_Header_

// MsgType=std_msgs/Header
struct SL_Bus_std_msgs_Header
{
  // MsgType=builtin_interfaces/Time
  SL_Bus_builtin_interfaces_Time stamp;

  // PrimitiveROSType=string:IsVarLen=1:VarLenCategory=data:VarLenElem=frame_id_SL_Info:TruncateAction=warn 
  uint8_T frame_id[128];

  // IsVarLen=1:VarLenCategory=length:VarLenElem=frame_id
  SL_Bus_ROSVariableLengthArrayInfo frame_id_SL_Info;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_sensor_msgs_Image_
#define DEFINED_TYPEDEF_FOR_SL_Bus_sensor_msgs_Image_

// MsgType=sensor_msgs/Image
struct SL_Bus_sensor_msgs_Image
{
  // MsgType=std_msgs/Header
  SL_Bus_std_msgs_Header header;
  uint32_T height;
  uint32_T width;

  // PrimitiveROSType=string:IsVarLen=1:VarLenCategory=data:VarLenElem=encoding_SL_Info:TruncateAction=warn 
  uint8_T encoding[128];

  // IsVarLen=1:VarLenCategory=length:VarLenElem=encoding
  SL_Bus_ROSVariableLengthArrayInfo encoding_SL_Info;
  uint8_T is_bigendian;
  uint32_T step;

  // IsVarLen=1:VarLenCategory=data:VarLenElem=data_SL_Info:TruncateAction=warn
  uint8_T data[921600];

  // IsVarLen=1:VarLenCategory=length:VarLenElem=data
  SL_Bus_ROSVariableLengthArrayInfo data_SL_Info;
};

#endif

// Custom Type definition for MATLABSystem: '<S5>/SourceBlock'
#include "rmw/qos_profiles.h"
#ifndef struct_sJ4ih70VmKcvCeguWN0mNVF
#define struct_sJ4ih70VmKcvCeguWN0mNVF

struct sJ4ih70VmKcvCeguWN0mNVF
{
  real_T sec;
  real_T nsec;
};

#endif                                 // struct_sJ4ih70VmKcvCeguWN0mNVF

#ifndef struct_ros_slros2_internal_block_Pub_T
#define struct_ros_slros2_internal_block_Pub_T

struct ros_slros2_internal_block_Pub_T
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  boolean_T QOSAvoidROSNamespaceConventions;
};

#endif                                // struct_ros_slros2_internal_block_Pub_T

#ifndef struct_ros_slros2_internal_block_Sub_T
#define struct_ros_slros2_internal_block_Sub_T

struct ros_slros2_internal_block_Sub_T
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  boolean_T QOSAvoidROSNamespaceConventions;
};

#endif                                // struct_ros_slros2_internal_block_Sub_T

#ifndef struct_ros_slros2_internal_block_Rea_T
#define struct_ros_slros2_internal_block_Rea_T

struct ros_slros2_internal_block_Rea_T
{
  int32_T isInitialized;
  uint8_T Image[921600];
  uint32_T ImageSize[2];
};

#endif                                // struct_ros_slros2_internal_block_Rea_T

// Parameters (default storage)
typedef struct P_ROS2_IPG_Write_Data_Sample1_T_ P_ROS2_IPG_Write_Data_Sample1_T;

// Forward declaration for rtModel
typedef struct tag_RTM_ROS2_IPG_Write_Data_S_T RT_MODEL_ROS2_IPG_Write_Data__T;

#endif                                 // ROS2_IPG_Write_Data_Sample1_types_h_

//
// File trailer for generated code.
//
// [EOF]
//
