//
// File: RADARSubscribeTest_Sample1_24a.cpp
//
// Code generated for Simulink model 'RADARSubscribeTest_Sample1_24a'.
//
// Model version                  : 1.0
// Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
// C/C++ source code generated on : Mon Apr 21 02:10:11 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "RADARSubscribeTest_Sample1_24a.h"
#include "RADARSubscribeTest_Sample1_24a_types.h"
#include "rmw/qos_profiles.h"
#include "rtwtypes.h"
#include <stddef.h>

void RADARSubscribeTest_Sample1_24a::RADARSubsc_Subscriber_setupImpl(const
  ros_slros2_internal_block_Sub_T *obj)
{
  rmw_qos_profile_t qos_profile;
  sJ4ih70VmKcvCeguWN0mNVF lifespan;
  sJ4ih70VmKcvCeguWN0mNVF liveliness_lease_duration;
  char_T b_zeroDelimTopic[13];
  static const char_T b_zeroDelimTopic_0[13] = "/RadarTracks";
  qos_profile = rmw_qos_profile_default;

  // Start for MATLABSystem: '<S2>/SourceBlock'
  RADARSubscribeTest_Sample1_24_B.deadline.sec = 0.0;
  RADARSubscribeTest_Sample1_24_B.deadline.nsec = 0.0;
  lifespan.sec = 0.0;
  lifespan.nsec = 0.0;
  liveliness_lease_duration.sec = 0.0;
  liveliness_lease_duration.nsec = 0.0;
  SET_QOS_VALUES(qos_profile, RMW_QOS_POLICY_HISTORY_KEEP_LAST, (size_t)1.0,
                 RMW_QOS_POLICY_DURABILITY_VOLATILE,
                 RMW_QOS_POLICY_RELIABILITY_RELIABLE,
                 RADARSubscribeTest_Sample1_24_B.deadline, lifespan,
                 RMW_QOS_POLICY_LIVELINESS_AUTOMATIC, liveliness_lease_duration,
                 (bool)obj->QOSAvoidROSNamespaceConventions);
  for (int32_T i = 0; i < 13; i++) {
    // Start for MATLABSystem: '<S2>/SourceBlock'
    b_zeroDelimTopic[i] = b_zeroDelimTopic_0[i];
  }

  Sub_RADARSubscribeTest_Sample1_24a_1.createSubscriber(&b_zeroDelimTopic[0],
    qos_profile);
}

// Model step function
void RADARSubscribeTest_Sample1_24a::step()
{
  // MATLABSystem: '<S2>/SourceBlock'
  Sub_RADARSubscribeTest_Sample1_24a_1.getLatestMessage
    (&RADARSubscribeTest_Sample1_24_B.r);
}

// Model initialize function
void RADARSubscribeTest_Sample1_24a::initialize()
{
  // Start for MATLABSystem: '<S2>/SourceBlock'
  RADARSubscribeTest_Sample1_2_DW.obj.QOSAvoidROSNamespaceConventions = false;
  RADARSubscribeTest_Sample1_2_DW.obj.matlabCodegenIsDeleted = false;
  RADARSubscribeTest_Sample1_2_DW.obj.isSetupComplete = false;
  RADARSubscribeTest_Sample1_2_DW.obj.isInitialized = 1;
  RADARSubsc_Subscriber_setupImpl(&RADARSubscribeTest_Sample1_2_DW.obj);
  RADARSubscribeTest_Sample1_2_DW.obj.isSetupComplete = true;
}

// Model terminate function
void RADARSubscribeTest_Sample1_24a::terminate()
{
  // Terminate for MATLABSystem: '<S2>/SourceBlock'
  if (!RADARSubscribeTest_Sample1_2_DW.obj.matlabCodegenIsDeleted) {
    RADARSubscribeTest_Sample1_2_DW.obj.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S2>/SourceBlock'
}

// Constructor
RADARSubscribeTest_Sample1_24a::RADARSubscribeTest_Sample1_24a() :
  RADARSubscribeTest_Sample1_24_B(),
  RADARSubscribeTest_Sample1_2_DW(),
  RADARSubscribeTest_Sample1_2_M()
{
  // Currently there is no constructor body generated.
}

// Destructor
RADARSubscribeTest_Sample1_24a::~RADARSubscribeTest_Sample1_24a()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
RT_MODEL_RADARSubscribeTest_S_T * RADARSubscribeTest_Sample1_24a::getRTM()
{
  return (&RADARSubscribeTest_Sample1_2_M);
}

//
// File trailer for generated code.
//
// [EOF]
//
