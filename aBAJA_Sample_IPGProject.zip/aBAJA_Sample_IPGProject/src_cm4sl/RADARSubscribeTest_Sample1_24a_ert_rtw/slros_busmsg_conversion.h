#ifndef _SLROS_BUSMSG_CONVERSION_H_
#define _SLROS_BUSMSG_CONVERSION_H_

#include "rclcpp/rclcpp.hpp"
#include <builtin_interfaces/msg/time.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <geometry_msgs/msg/vector3.hpp>
#include <radar_msgs/msg/radar_track.hpp>
#include <radar_msgs/msg/radar_tracks.hpp>
#include <std_msgs/msg/header.hpp>
#include <unique_identifier_msgs/msg/uuid.hpp>
#include "RADARSubscribeTest_Sample1_24a_types.h"
#include "slros_msgconvert_utils.h"


void convertFromBus(builtin_interfaces::msg::Time& msgPtr, SL_Bus_builtin_interfaces_Time const* busPtr);
void convertToBus(SL_Bus_builtin_interfaces_Time* busPtr, const builtin_interfaces::msg::Time& msgPtr);

void convertFromBus(geometry_msgs::msg::Point& msgPtr, SL_Bus_geometry_msgs_Point const* busPtr);
void convertToBus(SL_Bus_geometry_msgs_Point* busPtr, const geometry_msgs::msg::Point& msgPtr);

void convertFromBus(geometry_msgs::msg::Vector3& msgPtr, SL_Bus_geometry_msgs_Vector3 const* busPtr);
void convertToBus(SL_Bus_geometry_msgs_Vector3* busPtr, const geometry_msgs::msg::Vector3& msgPtr);

void convertFromBus(radar_msgs::msg::RadarTrack& msgPtr, SL_Bus_radar_msgs_RadarTrack const* busPtr);
void convertToBus(SL_Bus_radar_msgs_RadarTrack* busPtr, const radar_msgs::msg::RadarTrack& msgPtr);

void convertFromBus(radar_msgs::msg::RadarTracks& msgPtr, SL_Bus_radar_msgs_RadarTracks const* busPtr);
void convertToBus(SL_Bus_radar_msgs_RadarTracks* busPtr, const radar_msgs::msg::RadarTracks& msgPtr);

void convertFromBus(std_msgs::msg::Header& msgPtr, SL_Bus_std_msgs_Header const* busPtr);
void convertToBus(SL_Bus_std_msgs_Header* busPtr, const std_msgs::msg::Header& msgPtr);

void convertFromBus(unique_identifier_msgs::msg::UUID& msgPtr, SL_Bus_unique_identifier_msgs_UUID const* busPtr);
void convertToBus(SL_Bus_unique_identifier_msgs_UUID* busPtr, const unique_identifier_msgs::msg::UUID& msgPtr);


#endif
