//
// File: RADARSubscribeTest_Sample1_24a_private.h
//
// Code generated for Simulink model 'RADARSubscribeTest_Sample1_24a'.
//
// Model version                  : 1.0
// Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
// C/C++ source code generated on : Mon Apr 21 02:10:11 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RADARSubscribeTest_Sample1_24a_private_h_
#define RADARSubscribeTest_Sample1_24a_private_h_
#include "rtwtypes.h"
#include "RADARSubscribeTest_Sample1_24a_types.h"
#endif                             // RADARSubscribeTest_Sample1_24a_private_h_

//
// File trailer for generated code.
//
// [EOF]
//
