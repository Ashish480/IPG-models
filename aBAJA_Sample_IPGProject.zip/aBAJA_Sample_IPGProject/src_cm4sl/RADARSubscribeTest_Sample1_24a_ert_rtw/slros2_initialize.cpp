// Copyright 2022-2023 The MathWorks, Inc.
// Generated 21-Apr-2025 02:10:15
#include "slros2_initialize.h"
// RADARSubscribeTest_Sample1_24a/Subscribe
SimulinkSubscriber<radar_msgs::msg::RadarTracks,SL_Bus_radar_msgs_RadarTracks> Sub_RADARSubscribeTest_Sample1_24a_1;
