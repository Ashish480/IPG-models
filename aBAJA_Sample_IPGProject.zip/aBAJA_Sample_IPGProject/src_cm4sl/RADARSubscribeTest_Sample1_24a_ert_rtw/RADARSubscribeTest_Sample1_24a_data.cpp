//
// File: RADARSubscribeTest_Sample1_24a_data.cpp
//
// Code generated for Simulink model 'RADARSubscribeTest_Sample1_24a'.
//
// Model version                  : 1.0
// Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
// C/C++ source code generated on : Mon Apr 21 02:10:11 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "RADARSubscribeTest_Sample1_24a.h"

// Block parameters (default storage)
P_RADARSubscribeTest_Sample1__T RADARSubscribeTest_Sample1_24a::
  RADARSubscribeTest_Sample1_24_P = {
  // Computed Parameter: Out1_Y0
  //  Referenced by: '<S4>/Out1'

  {
    {
      {
        0,                             // sec
        0U                             // nanosec
      },                               // stamp

      {
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U }
      ,                                // frame_id

      {
        0U,                            // CurrentLength
        0U                             // ReceivedLength
      }                                // frame_id_SL_Info
    },                                 // header

    {
      {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      } }
    // tracks
  },

  // Computed Parameter: Constant_Value
  //  Referenced by: '<S2>/Constant'

  {
    {
      {
        0,                             // sec
        0U                             // nanosec
      },                               // stamp

      {
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U }
      ,                                // frame_id

      {
        0U,                            // CurrentLength
        0U                             // ReceivedLength
      }                                // frame_id_SL_Info
    },                                 // header

    {
      {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      }, {
        {
          {
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
          // uuid
        },                             // uuid

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // position

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // velocity

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // acceleration

        {
          0.0,                         // x
          0.0,                         // y
          0.0                          // z
        },                             // size
        0U,                            // classification

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // position_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // velocity_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        ,                              // acceleration_covariance

        {
          0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
        // size_covariance
      } }
    // tracks
  },

  // Computed Parameter: positionArray_Y0
  //  Referenced by: '<S1>/positionArray'

  0.0,

  // Computed Parameter: velocityArray_Y0
  //  Referenced by: '<S1>/velocityArray'

  0.0,

  // Computed Parameter: accelerationArray_Y0
  //  Referenced by: '<S1>/accelerationArray'

  0.0,

  // Computed Parameter: sizeArray_Y0
  //  Referenced by: '<S1>/sizeArray'

  0.0,

  // Computed Parameter: classificationArray_Y0
  //  Referenced by: '<S1>/classificationArray'

  0.0,

  // Computed Parameter: positionCovariance_Y0
  //  Referenced by: '<S1>/positionCovariance'

  0.0,

  // Computed Parameter: velocityCovariance_Y0
  //  Referenced by: '<S1>/velocityCovariance'

  0.0,

  // Computed Parameter: accelerationCovariance_Y0
  //  Referenced by: '<S1>/accelerationCovariance'

  0.0,

  // Computed Parameter: sizeCovariance_Y0
  //  Referenced by: '<S1>/sizeCovariance'

  0.0
};

//
// File trailer for generated code.
//
// [EOF]
//
