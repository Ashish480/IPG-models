function rosmsgOut = UUID(slBusIn, rosmsgOut)
%#codegen
%   Copyright 2021 The MathWorks, Inc.
    rosmsgOut.uuid = uint8(slBusIn.uuid);
end
