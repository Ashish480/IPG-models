function rosmsgOut = RadarTracks(slBusIn, rosmsgOut)
%#codegen
%   Copyright 2021 The MathWorks, Inc.
    rosmsgOut.header = bus_conv_fcns.ros2.busToMsg.std_msgs.Header(slBusIn.header,rosmsgOut.header(1));
    for iter=1:30
        rosmsgOut.tracks(iter) = bus_conv_fcns.ros2.busToMsg.radar_msgs.RadarTrack(slBusIn.tracks(iter),rosmsgOut.tracks(1));
    end
end
