function rosmsgOut = RadarTrack(slBusIn, rosmsgOut)
%#codegen
%   Copyright 2021 The MathWorks, Inc.
    rosmsgOut.uuid = bus_conv_fcns.ros2.busToMsg.unique_identifier_msgs.UUID(slBusIn.uuid,rosmsgOut.uuid(1));
    rosmsgOut.position = bus_conv_fcns.ros2.busToMsg.geometry_msgs.Point(slBusIn.position,rosmsgOut.position(1));
    rosmsgOut.velocity = bus_conv_fcns.ros2.busToMsg.geometry_msgs.Vector3(slBusIn.velocity,rosmsgOut.velocity(1));
    rosmsgOut.acceleration = bus_conv_fcns.ros2.busToMsg.geometry_msgs.Vector3(slBusIn.acceleration,rosmsgOut.acceleration(1));
    rosmsgOut.size = bus_conv_fcns.ros2.busToMsg.geometry_msgs.Vector3(slBusIn.size,rosmsgOut.size(1));
    rosmsgOut.classification = uint16(slBusIn.classification);
    rosmsgOut.position_covariance = single(slBusIn.position_covariance);
    rosmsgOut.velocity_covariance = single(slBusIn.velocity_covariance);
    rosmsgOut.acceleration_covariance = single(slBusIn.acceleration_covariance);
    rosmsgOut.size_covariance = single(slBusIn.size_covariance);
end
