% set shared variables
global ReferenceModel;

global postfix_updated;
global postfix_backup;

global src_mdl;
global trg_mdl;

global SFun_list_src;
global SFun_list_trg;

global XM;
global XMaker;
