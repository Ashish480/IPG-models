#ifndef __c3_generic_updated_aBAJA2025_Version1_h__
#define __c3_generic_updated_aBAJA2025_Version1_h__

/* Forward Declarations */
#ifndef c3_typedef_c3_SL_Bus_builtin_interfaces_Time
#define c3_typedef_c3_SL_Bus_builtin_interfaces_Time

typedef struct c3_SL_Bus_builtin_interfaces_Time_tag
  c3_SL_Bus_builtin_interfaces_Time;

#endif                                 /* c3_typedef_c3_SL_Bus_builtin_interfaces_Time */

#ifndef c3_typedef_c3_SL_Bus_ROSVariableLengthArrayInfo
#define c3_typedef_c3_SL_Bus_ROSVariableLengthArrayInfo

typedef struct c3_SL_Bus_ROSVariableLengthArrayInfo_tag
  c3_SL_Bus_ROSVariableLengthArrayInfo;

#endif                                 /* c3_typedef_c3_SL_Bus_ROSVariableLengthArrayInfo */

#ifndef c3_typedef_c3_SL_Bus_std_msgs_Header
#define c3_typedef_c3_SL_Bus_std_msgs_Header

typedef struct c3_SL_Bus_std_msgs_Header_tag c3_SL_Bus_std_msgs_Header;

#endif                                 /* c3_typedef_c3_SL_Bus_std_msgs_Header */

#ifndef c3_typedef_c3_SL_Bus_unique_identifier_msgs_UUID
#define c3_typedef_c3_SL_Bus_unique_identifier_msgs_UUID

typedef struct c3_SL_Bus_unique_identifier_msgs_UUID_tag
  c3_SL_Bus_unique_identifier_msgs_UUID;

#endif                                 /* c3_typedef_c3_SL_Bus_unique_identifier_msgs_UUID */

#ifndef c3_typedef_c3_SL_Bus_geometry_msgs_Point
#define c3_typedef_c3_SL_Bus_geometry_msgs_Point

typedef struct c3_SL_Bus_geometry_msgs_Point_tag c3_SL_Bus_geometry_msgs_Point;

#endif                                 /* c3_typedef_c3_SL_Bus_geometry_msgs_Point */

#ifndef c3_typedef_c3_SL_Bus_geometry_msgs_Vector3
#define c3_typedef_c3_SL_Bus_geometry_msgs_Vector3

typedef struct c3_SL_Bus_geometry_msgs_Vector3_tag
  c3_SL_Bus_geometry_msgs_Vector3;

#endif                                 /* c3_typedef_c3_SL_Bus_geometry_msgs_Vector3 */

#ifndef c3_typedef_c3_SL_Bus_radar_msgs_RadarTrack
#define c3_typedef_c3_SL_Bus_radar_msgs_RadarTrack

typedef struct c3_SL_Bus_radar_msgs_RadarTrack_tag
  c3_SL_Bus_radar_msgs_RadarTrack;

#endif                                 /* c3_typedef_c3_SL_Bus_radar_msgs_RadarTrack */

#ifndef c3_typedef_c3_SL_Bus_radar_msgs_RadarTracks
#define c3_typedef_c3_SL_Bus_radar_msgs_RadarTracks

typedef struct c3_SL_Bus_radar_msgs_RadarTracks_tag
  c3_SL_Bus_radar_msgs_RadarTracks;

#endif                                 /* c3_typedef_c3_SL_Bus_radar_msgs_RadarTracks */

#ifndef c3_typedef_c3_geometry_msgs_PointStruct_T
#define c3_typedef_c3_geometry_msgs_PointStruct_T

typedef struct c3_tag_sWkXWV391bqUjx0RHXwNgfD c3_geometry_msgs_PointStruct_T;

#endif                                 /* c3_typedef_c3_geometry_msgs_PointStruct_T */

#ifndef c3_typedef_c3_geometry_msgs_Vector3Struct_T
#define c3_typedef_c3_geometry_msgs_Vector3Struct_T

typedef struct c3_tag_snhXrUmFJbJXCTP2zFDd71 c3_geometry_msgs_Vector3Struct_T;

#endif                                 /* c3_typedef_c3_geometry_msgs_Vector3Struct_T */

#ifndef c3_typedef_c3_cell_0
#define c3_typedef_c3_cell_0

typedef struct c3_tag_7rClNlx2n452lpFDKKJsJH c3_cell_0;

#endif                                 /* c3_typedef_c3_cell_0 */

#ifndef c3_typedef_c3_cell_wrap_1
#define c3_typedef_c3_cell_wrap_1

typedef struct c3_tag_hfuMxtM3511pO8GfZjii3B c3_cell_wrap_1;

#endif                                 /* c3_typedef_c3_cell_wrap_1 */

#ifndef c3_typedef_c3_s_tiFQuw0ZDonsvxQULxkHSF
#define c3_typedef_c3_s_tiFQuw0ZDonsvxQULxkHSF

typedef struct c3_tag_tiFQuw0ZDonsvxQULxkHSF c3_s_tiFQuw0ZDonsvxQULxkHSF;

#endif                                 /* c3_typedef_c3_s_tiFQuw0ZDonsvxQULxkHSF */

#ifndef c3_typedef_c3_s_kIjER3TOnaUUvjksbP9imB
#define c3_typedef_c3_s_kIjER3TOnaUUvjksbP9imB

typedef struct c3_tag_kIjER3TOnaUUvjksbP9imB c3_s_kIjER3TOnaUUvjksbP9imB;

#endif                                 /* c3_typedef_c3_s_kIjER3TOnaUUvjksbP9imB */

#ifndef c3_typedef_c3_s_r8oingdPeAlKT8PJg7lrLB
#define c3_typedef_c3_s_r8oingdPeAlKT8PJg7lrLB

typedef struct c3_tag_r8oingdPeAlKT8PJg7lrLB c3_s_r8oingdPeAlKT8PJg7lrLB;

#endif                                 /* c3_typedef_c3_s_r8oingdPeAlKT8PJg7lrLB */

/* Type Definitions */
#ifndef c3_struct_c3_SL_Bus_builtin_interfaces_Time_tag
#define c3_struct_c3_SL_Bus_builtin_interfaces_Time_tag

struct c3_SL_Bus_builtin_interfaces_Time_tag
{
  int32_T sec;
  uint32_T nanosec;
};

#endif                                 /* c3_struct_c3_SL_Bus_builtin_interfaces_Time_tag */

#ifndef c3_typedef_c3_SL_Bus_builtin_interfaces_Time
#define c3_typedef_c3_SL_Bus_builtin_interfaces_Time

typedef struct c3_SL_Bus_builtin_interfaces_Time_tag
  c3_SL_Bus_builtin_interfaces_Time;

#endif                                 /* c3_typedef_c3_SL_Bus_builtin_interfaces_Time */

#ifndef c3_struct_c3_SL_Bus_ROSVariableLengthArrayInfo_tag
#define c3_struct_c3_SL_Bus_ROSVariableLengthArrayInfo_tag

struct c3_SL_Bus_ROSVariableLengthArrayInfo_tag
{
  uint32_T CurrentLength;
  uint32_T ReceivedLength;
};

#endif                                 /* c3_struct_c3_SL_Bus_ROSVariableLengthArrayInfo_tag */

#ifndef c3_typedef_c3_SL_Bus_ROSVariableLengthArrayInfo
#define c3_typedef_c3_SL_Bus_ROSVariableLengthArrayInfo

typedef struct c3_SL_Bus_ROSVariableLengthArrayInfo_tag
  c3_SL_Bus_ROSVariableLengthArrayInfo;

#endif                                 /* c3_typedef_c3_SL_Bus_ROSVariableLengthArrayInfo */

#ifndef c3_struct_c3_SL_Bus_std_msgs_Header_tag
#define c3_struct_c3_SL_Bus_std_msgs_Header_tag

struct c3_SL_Bus_std_msgs_Header_tag
{
  c3_SL_Bus_builtin_interfaces_Time stamp;
  uint8_T frame_id[128];
  c3_SL_Bus_ROSVariableLengthArrayInfo frame_id_SL_Info;
};

#endif                                 /* c3_struct_c3_SL_Bus_std_msgs_Header_tag */

#ifndef c3_typedef_c3_SL_Bus_std_msgs_Header
#define c3_typedef_c3_SL_Bus_std_msgs_Header

typedef struct c3_SL_Bus_std_msgs_Header_tag c3_SL_Bus_std_msgs_Header;

#endif                                 /* c3_typedef_c3_SL_Bus_std_msgs_Header */

#ifndef c3_struct_c3_SL_Bus_unique_identifier_msgs_UUID_tag
#define c3_struct_c3_SL_Bus_unique_identifier_msgs_UUID_tag

struct c3_SL_Bus_unique_identifier_msgs_UUID_tag
{
  uint8_T uuid[16];
};

#endif                                 /* c3_struct_c3_SL_Bus_unique_identifier_msgs_UUID_tag */

#ifndef c3_typedef_c3_SL_Bus_unique_identifier_msgs_UUID
#define c3_typedef_c3_SL_Bus_unique_identifier_msgs_UUID

typedef struct c3_SL_Bus_unique_identifier_msgs_UUID_tag
  c3_SL_Bus_unique_identifier_msgs_UUID;

#endif                                 /* c3_typedef_c3_SL_Bus_unique_identifier_msgs_UUID */

#ifndef c3_struct_c3_SL_Bus_geometry_msgs_Point_tag
#define c3_struct_c3_SL_Bus_geometry_msgs_Point_tag

struct c3_SL_Bus_geometry_msgs_Point_tag
{
  real_T x;
  real_T y;
  real_T z;
};

#endif                                 /* c3_struct_c3_SL_Bus_geometry_msgs_Point_tag */

#ifndef c3_typedef_c3_SL_Bus_geometry_msgs_Point
#define c3_typedef_c3_SL_Bus_geometry_msgs_Point

typedef struct c3_SL_Bus_geometry_msgs_Point_tag c3_SL_Bus_geometry_msgs_Point;

#endif                                 /* c3_typedef_c3_SL_Bus_geometry_msgs_Point */

#ifndef c3_struct_c3_SL_Bus_geometry_msgs_Vector3_tag
#define c3_struct_c3_SL_Bus_geometry_msgs_Vector3_tag

struct c3_SL_Bus_geometry_msgs_Vector3_tag
{
  real_T x;
  real_T y;
  real_T z;
};

#endif                                 /* c3_struct_c3_SL_Bus_geometry_msgs_Vector3_tag */

#ifndef c3_typedef_c3_SL_Bus_geometry_msgs_Vector3
#define c3_typedef_c3_SL_Bus_geometry_msgs_Vector3

typedef struct c3_SL_Bus_geometry_msgs_Vector3_tag
  c3_SL_Bus_geometry_msgs_Vector3;

#endif                                 /* c3_typedef_c3_SL_Bus_geometry_msgs_Vector3 */

#ifndef c3_struct_c3_SL_Bus_radar_msgs_RadarTrack_tag
#define c3_struct_c3_SL_Bus_radar_msgs_RadarTrack_tag

struct c3_SL_Bus_radar_msgs_RadarTrack_tag
{
  c3_SL_Bus_unique_identifier_msgs_UUID uuid;
  c3_SL_Bus_geometry_msgs_Point position;
  c3_SL_Bus_geometry_msgs_Vector3 velocity;
  c3_SL_Bus_geometry_msgs_Vector3 acceleration;
  c3_SL_Bus_geometry_msgs_Vector3 size;
  uint16_T classification;
  real32_T position_covariance[6];
  real32_T velocity_covariance[6];
  real32_T acceleration_covariance[6];
  real32_T size_covariance[6];
};

#endif                                 /* c3_struct_c3_SL_Bus_radar_msgs_RadarTrack_tag */

#ifndef c3_typedef_c3_SL_Bus_radar_msgs_RadarTrack
#define c3_typedef_c3_SL_Bus_radar_msgs_RadarTrack

typedef struct c3_SL_Bus_radar_msgs_RadarTrack_tag
  c3_SL_Bus_radar_msgs_RadarTrack;

#endif                                 /* c3_typedef_c3_SL_Bus_radar_msgs_RadarTrack */

#ifndef c3_struct_c3_SL_Bus_radar_msgs_RadarTracks_tag
#define c3_struct_c3_SL_Bus_radar_msgs_RadarTracks_tag

struct c3_SL_Bus_radar_msgs_RadarTracks_tag
{
  c3_SL_Bus_std_msgs_Header header;
  c3_SL_Bus_radar_msgs_RadarTrack tracks[30];
};

#endif                                 /* c3_struct_c3_SL_Bus_radar_msgs_RadarTracks_tag */

#ifndef c3_typedef_c3_SL_Bus_radar_msgs_RadarTracks
#define c3_typedef_c3_SL_Bus_radar_msgs_RadarTracks

typedef struct c3_SL_Bus_radar_msgs_RadarTracks_tag
  c3_SL_Bus_radar_msgs_RadarTracks;

#endif                                 /* c3_typedef_c3_SL_Bus_radar_msgs_RadarTracks */

#ifndef c3_struct_c3_tag_sWkXWV391bqUjx0RHXwNgfD
#define c3_struct_c3_tag_sWkXWV391bqUjx0RHXwNgfD

struct c3_tag_sWkXWV391bqUjx0RHXwNgfD
{
  char_T MessageType[19];
  real_T x;
  real_T y;
  real_T z;
};

#endif                                 /* c3_struct_c3_tag_sWkXWV391bqUjx0RHXwNgfD */

#ifndef c3_typedef_c3_geometry_msgs_PointStruct_T
#define c3_typedef_c3_geometry_msgs_PointStruct_T

typedef struct c3_tag_sWkXWV391bqUjx0RHXwNgfD c3_geometry_msgs_PointStruct_T;

#endif                                 /* c3_typedef_c3_geometry_msgs_PointStruct_T */

#ifndef c3_struct_c3_tag_snhXrUmFJbJXCTP2zFDd71
#define c3_struct_c3_tag_snhXrUmFJbJXCTP2zFDd71

struct c3_tag_snhXrUmFJbJXCTP2zFDd71
{
  char_T MessageType[21];
  real_T x;
  real_T y;
  real_T z;
};

#endif                                 /* c3_struct_c3_tag_snhXrUmFJbJXCTP2zFDd71 */

#ifndef c3_typedef_c3_geometry_msgs_Vector3Struct_T
#define c3_typedef_c3_geometry_msgs_Vector3Struct_T

typedef struct c3_tag_snhXrUmFJbJXCTP2zFDd71 c3_geometry_msgs_Vector3Struct_T;

#endif                                 /* c3_typedef_c3_geometry_msgs_Vector3Struct_T */

#ifndef c3_struct_c3_tag_7rClNlx2n452lpFDKKJsJH
#define c3_struct_c3_tag_7rClNlx2n452lpFDKKJsJH

struct c3_tag_7rClNlx2n452lpFDKKJsJH
{
  char_T f1[4];
  char_T f2[6];
};

#endif                                 /* c3_struct_c3_tag_7rClNlx2n452lpFDKKJsJH */

#ifndef c3_typedef_c3_cell_0
#define c3_typedef_c3_cell_0

typedef struct c3_tag_7rClNlx2n452lpFDKKJsJH c3_cell_0;

#endif                                 /* c3_typedef_c3_cell_0 */

#ifndef c3_struct_c3_tag_hfuMxtM3511pO8GfZjii3B
#define c3_struct_c3_tag_hfuMxtM3511pO8GfZjii3B

struct c3_tag_hfuMxtM3511pO8GfZjii3B
{
  char_T f1[8];
};

#endif                                 /* c3_struct_c3_tag_hfuMxtM3511pO8GfZjii3B */

#ifndef c3_typedef_c3_cell_wrap_1
#define c3_typedef_c3_cell_wrap_1

typedef struct c3_tag_hfuMxtM3511pO8GfZjii3B c3_cell_wrap_1;

#endif                                 /* c3_typedef_c3_cell_wrap_1 */

#ifndef c3_struct_c3_tag_tiFQuw0ZDonsvxQULxkHSF
#define c3_struct_c3_tag_tiFQuw0ZDonsvxQULxkHSF

struct c3_tag_tiFQuw0ZDonsvxQULxkHSF
{
  char_T Value[5];
};

#endif                                 /* c3_struct_c3_tag_tiFQuw0ZDonsvxQULxkHSF */

#ifndef c3_typedef_c3_s_tiFQuw0ZDonsvxQULxkHSF
#define c3_typedef_c3_s_tiFQuw0ZDonsvxQULxkHSF

typedef struct c3_tag_tiFQuw0ZDonsvxQULxkHSF c3_s_tiFQuw0ZDonsvxQULxkHSF;

#endif                                 /* c3_typedef_c3_s_tiFQuw0ZDonsvxQULxkHSF */

#ifndef c3_struct_c3_tag_kIjER3TOnaUUvjksbP9imB
#define c3_struct_c3_tag_kIjER3TOnaUUvjksbP9imB

struct c3_tag_kIjER3TOnaUUvjksbP9imB
{
  c3_cell_0 _data;
};

#endif                                 /* c3_struct_c3_tag_kIjER3TOnaUUvjksbP9imB */

#ifndef c3_typedef_c3_s_kIjER3TOnaUUvjksbP9imB
#define c3_typedef_c3_s_kIjER3TOnaUUvjksbP9imB

typedef struct c3_tag_kIjER3TOnaUUvjksbP9imB c3_s_kIjER3TOnaUUvjksbP9imB;

#endif                                 /* c3_typedef_c3_s_kIjER3TOnaUUvjksbP9imB */

#ifndef c3_struct_c3_tag_r8oingdPeAlKT8PJg7lrLB
#define c3_struct_c3_tag_r8oingdPeAlKT8PJg7lrLB

struct c3_tag_r8oingdPeAlKT8PJg7lrLB
{
  c3_cell_wrap_1 _data;
};

#endif                                 /* c3_struct_c3_tag_r8oingdPeAlKT8PJg7lrLB */

#ifndef c3_typedef_c3_s_r8oingdPeAlKT8PJg7lrLB
#define c3_typedef_c3_s_r8oingdPeAlKT8PJg7lrLB

typedef struct c3_tag_r8oingdPeAlKT8PJg7lrLB c3_s_r8oingdPeAlKT8PJg7lrLB;

#endif                                 /* c3_typedef_c3_s_r8oingdPeAlKT8PJg7lrLB */

#ifndef typedef_SFc3_generic_updated_aBAJA2025_Version1InstanceStruct
#define typedef_SFc3_generic_updated_aBAJA2025_Version1InstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  int32_T c3_sfEvent;
  boolean_T c3_doneDoubleBufferReInit;
  void *c3_RuntimeVar;
  int32_T c3_IsDebuggerActive;
  int32_T c3_IsSequenceViewerPresent;
  int32_T c3_SequenceViewerOptimization;
  int32_T c3_IsHeatMapPresent;
  uint8_T c3_JITStateAnimation[1];
  uint8_T c3_JITTransitionAnimation[1];
  uint32_T c3_mlFcnLineNumber;
  void *c3_fcnDataPtrs[15];
  const char_T *c3_dataNames[15];
  uint32_T c3_numFcnVars;
  uint32_T c3_ssIds[15];
  uint32_T c3_statuses[15];
  void *c3_outMexFcns[15];
  void *c3_inMexFcns[15];
  CovrtStateflowInstance *c3_covrtInstance;
  void *c3_fEmlrtCtx;
  c3_SL_Bus_radar_msgs_RadarTracks *c3_emptyTracksMessage;
  c3_SL_Bus_radar_msgs_RadarTracks *c3_msg;
  real_T (*c3_positionArray)[90];
  real_T (*c3_velocityArray)[90];
  real_T (*c3_accelerationArray)[90];
  real_T (*c3_sizeArray)[90];
  uint16_T (*c3_classificationArray)[30];
  real32_T (*c3_positionCovariance)[180];
  real32_T (*c3_velocityCovariance)[180];
  real32_T (*c3_accelerationCovariance)[180];
  real32_T (*c3_sizeCovariance)[180];
} SFc3_generic_updated_aBAJA2025_Version1InstanceStruct;

#endif                                 /* typedef_SFc3_generic_updated_aBAJA2025_Version1InstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray
  *sf_c3_generic_updated_aBAJA2025_Version1_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c3_generic_updated_aBAJA2025_Version1_get_check_sum(mxArray *
  plhs[]);
extern void c3_generic_updated_aBAJA2025_Version1_method_dispatcher(SimStruct *S,
  int_T method, void *data);

#endif
