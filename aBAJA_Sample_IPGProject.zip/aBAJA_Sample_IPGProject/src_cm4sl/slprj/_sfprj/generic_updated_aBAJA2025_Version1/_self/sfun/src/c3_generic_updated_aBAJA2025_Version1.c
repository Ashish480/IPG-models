/* Include files */

#include "generic_updated_aBAJA2025_Version1_sfun.h"
#include "c3_generic_updated_aBAJA2025_Version1.h"
#include "mwmathutil.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(S);
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

/* Forward Declarations */

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;
static emlrtRSInfo c3_emlrtRSI = { 4,  /* lineNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fcnName */
  "#generic_updated_aBAJA2025_Version1:3268"/* pathName */
};

static emlrtRSInfo c3_b_emlrtRSI = { 5,/* lineNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fcnName */
  "#generic_updated_aBAJA2025_Version1:3268"/* pathName */
};

static emlrtRSInfo c3_c_emlrtRSI = { 62,/* lineNo */
  "ros2message",                       /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\ros\\mlros2\\ros2message.m"/* pathName */
};

static emlrtDCInfo c3_emlrtDCI = { 21, /* lineNo */
  79,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_emlrtBCI = { 1,  /* iFirst */
  30,                                  /* iLast */
  21,                                  /* lineNo */
  79,                                  /* colNo */
  "positionCovariance",                /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_b_emlrtDCI = { 22,/* lineNo */
  79,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_b_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  22,                                  /* lineNo */
  79,                                  /* colNo */
  "velocityCovariance",                /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_c_emlrtDCI = { 23,/* lineNo */
  87,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_c_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  23,                                  /* lineNo */
  87,                                  /* colNo */
  "accelerationCovariance",            /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_d_emlrtDCI = { 24,/* lineNo */
  71,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_d_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  24,                                  /* lineNo */
  71,                                  /* colNo */
  "sizeCovariance",                    /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c3_e_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  8,                                   /* lineNo */
  65,                                  /* colNo */
  "positionArray",                     /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_e_emlrtDCI = { 8,/* lineNo */
  65,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_f_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  8,                                   /* lineNo */
  35,                                  /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_f_emlrtDCI = { 8,/* lineNo */
  35,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_g_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  9,                                   /* lineNo */
  65,                                  /* colNo */
  "positionArray",                     /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_g_emlrtDCI = { 9,/* lineNo */
  65,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_h_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  9,                                   /* lineNo */
  35,                                  /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_h_emlrtDCI = { 9,/* lineNo */
  35,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_i_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  10,                                  /* lineNo */
  65,                                  /* colNo */
  "positionArray",                     /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_i_emlrtDCI = { 10,/* lineNo */
  65,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_j_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  10,                                  /* lineNo */
  35,                                  /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_j_emlrtDCI = { 10,/* lineNo */
  35,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_k_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  11,                                  /* lineNo */
  65,                                  /* colNo */
  "velocityArray",                     /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_k_emlrtDCI = { 11,/* lineNo */
  65,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_l_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  11,                                  /* lineNo */
  35,                                  /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_l_emlrtDCI = { 11,/* lineNo */
  35,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_m_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  12,                                  /* lineNo */
  65,                                  /* colNo */
  "velocityArray",                     /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_m_emlrtDCI = { 12,/* lineNo */
  65,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_n_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  12,                                  /* lineNo */
  35,                                  /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_n_emlrtDCI = { 12,/* lineNo */
  35,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_o_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  13,                                  /* lineNo */
  65,                                  /* colNo */
  "velocityArray",                     /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_o_emlrtDCI = { 13,/* lineNo */
  65,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_p_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  13,                                  /* lineNo */
  35,                                  /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_p_emlrtDCI = { 13,/* lineNo */
  35,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_q_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  14,                                  /* lineNo */
  73,                                  /* colNo */
  "accelerationArray",                 /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_q_emlrtDCI = { 14,/* lineNo */
  73,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_r_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  14,                                  /* lineNo */
  35,                                  /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_r_emlrtDCI = { 14,/* lineNo */
  35,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_s_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  15,                                  /* lineNo */
  73,                                  /* colNo */
  "accelerationArray",                 /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_s_emlrtDCI = { 15,/* lineNo */
  73,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_t_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  15,                                  /* lineNo */
  35,                                  /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_t_emlrtDCI = { 15,/* lineNo */
  35,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_u_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  16,                                  /* lineNo */
  73,                                  /* colNo */
  "accelerationArray",                 /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_u_emlrtDCI = { 16,/* lineNo */
  73,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_v_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  16,                                  /* lineNo */
  35,                                  /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_v_emlrtDCI = { 16,/* lineNo */
  35,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_w_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  17,                                  /* lineNo */
  57,                                  /* colNo */
  "sizeArray",                         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_w_emlrtDCI = { 17,/* lineNo */
  57,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_x_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  17,                                  /* lineNo */
  35,                                  /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_x_emlrtDCI = { 17,/* lineNo */
  35,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_y_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  18,                                  /* lineNo */
  57,                                  /* colNo */
  "sizeArray",                         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_y_emlrtDCI = { 18,/* lineNo */
  57,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_ab_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  18,                                  /* lineNo */
  35,                                  /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_ab_emlrtDCI = { 18,/* lineNo */
  35,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_bb_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  19,                                  /* lineNo */
  57,                                  /* colNo */
  "sizeArray",                         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_bb_emlrtDCI = { 19,/* lineNo */
  57,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_cb_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  19,                                  /* lineNo */
  35,                                  /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_cb_emlrtDCI = { 19,/* lineNo */
  35,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_db_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  20,                                  /* lineNo */
  75,                                  /* colNo */
  "classificationArray",               /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c3_db_emlrtDCI = { 20,/* lineNo */
  75,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_eb_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  20,                                  /* lineNo */
  35,                                  /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_eb_emlrtDCI = { 20,/* lineNo */
  35,                                  /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_fb_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  21,                                  /* lineNo */
  9,                                   /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_fb_emlrtDCI = { 21,/* lineNo */
  9,                                   /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_gb_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  22,                                  /* lineNo */
  9,                                   /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_gb_emlrtDCI = { 22,/* lineNo */
  9,                                   /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_hb_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  23,                                  /* lineNo */
  9,                                   /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_hb_emlrtDCI = { 23,/* lineNo */
  9,                                   /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c3_ib_emlrtBCI = { 1,/* iFirst */
  30,                                  /* iLast */
  24,                                  /* lineNo */
  9,                                   /* colNo */
  "emptyTracksMessage.tracks",         /* aName */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c3_ib_emlrtDCI = { 24,/* lineNo */
  9,                                   /* colNo */
  "CarMaker/RADAR Sensor/Subsystem/MATLAB Function2",/* fName */
  "#generic_updated_aBAJA2025_Version1:3268",/* pName */
  1                                    /* checkKind */
};

static const char_T *c3_sv[3] = { "x", "y", "z" };

/* Function Declarations */
static void initialize_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void initialize_params_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void mdl_start_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void mdl_terminate_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void mdl_setup_runtime_resources_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void mdl_cleanup_runtime_resources_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void enable_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void disable_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void sf_gateway_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void ext_mode_exec_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void c3_update_jit_animation_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void c3_do_animation_call_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static const mxArray *get_sim_state_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void set_sim_state_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_st);
static c3_geometry_msgs_PointStruct_T c3_geometry_msgs_PointStruct
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static c3_geometry_msgs_Vector3Struct_T c3_geometry_msgs_Vector3Struct
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void c3_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_nullptr, const char_T *c3_identifier,
   c3_SL_Bus_radar_msgs_RadarTracks *c3_y);
static void c3_b_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId,
   c3_SL_Bus_radar_msgs_RadarTracks *c3_y);
static void c3_c_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId,
   c3_SL_Bus_std_msgs_Header *c3_y);
static c3_SL_Bus_builtin_interfaces_Time c3_d_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static int32_T c3_e_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static uint32_T c3_f_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static void c3_g_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId, uint8_T c3_y[128]);
static c3_SL_Bus_ROSVariableLengthArrayInfo c3_h_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static void c3_i_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId,
   c3_SL_Bus_radar_msgs_RadarTrack c3_y[30]);
static c3_SL_Bus_unique_identifier_msgs_UUID c3_j_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static void c3_k_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId, uint8_T c3_y[16]);
static c3_SL_Bus_geometry_msgs_Point c3_l_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static real_T c3_m_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static c3_SL_Bus_geometry_msgs_Vector3 c3_n_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static uint16_T c3_o_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static void c3_p_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId, real32_T c3_y[6]);
static void c3_chart_data_browse_helper
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, int32_T
   c3_ssIdNumber, const mxArray **c3_mxData, uint8_T *c3_isValueTooBig);
static void init_dsm_address_info
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);
static void init_simulink_io_address
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  emlrtStack c3_st = { NULL,           /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  c3_st.tls = chartInstance->c3_fEmlrtCtx;
  emlrtLicenseCheckR2022a(&c3_st, "EMLRT:runTime:MexFunctionNeedsLicense",
    "ros_toolbox", 2);
  sim_mode_is_external(chartInstance->S);
  chartInstance->c3_doneDoubleBufferReInit = false;
  chartInstance->c3_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void initialize_params_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_start_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  sim_mode_is_external(chartInstance->S);
}

static void mdl_terminate_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_setup_runtime_resources_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  static const int32_T c3_b_postfixPredicateTree[2] = { 0, -1 };

  static const int32_T c3_postfixPredicateTree[2] = { 0, -1 };

  static const int32_T c3_b_condTxtEndIdx[1] = { 474 };

  static const int32_T c3_b_condTxtStartIdx[1] = { 453 };

  static const int32_T c3_condTxtEndIdx[1] = { 466 };

  static const int32_T c3_condTxtStartIdx[1] = { 445 };

  static const uint32_T c3_decisionTxtEndIdx = 0U;
  static const uint32_T c3_decisionTxtStartIdx = 0U;
  setDataBrowseFcn(chartInstance->S, (void *)&c3_chart_data_browse_helper);
  chartInstance->c3_RuntimeVar = sfListenerCacheSimStruct(chartInstance->S);
  sfListenerInitializeRuntimeVars(chartInstance->c3_RuntimeVar,
    &chartInstance->c3_IsDebuggerActive,
    &chartInstance->c3_IsSequenceViewerPresent, 0, 0,
    &chartInstance->c3_mlFcnLineNumber, &chartInstance->c3_IsHeatMapPresent, 0);
  sfSetAnimationVectors(chartInstance->S, &chartInstance->c3_JITStateAnimation[0],
                        &chartInstance->c3_JITTransitionAnimation[0]);
  covrtCreateStateflowInstanceData(chartInstance->c3_covrtInstance, 1U, 0U, 1U,
    28U);
  covrtChartInitFcn(chartInstance->c3_covrtInstance, 0U, false, false, false);
  covrtStateInitFcn(chartInstance->c3_covrtInstance, 0U, 0U, false, false, false,
                    0U, &c3_decisionTxtStartIdx, &c3_decisionTxtEndIdx);
  covrtTransInitFcn(chartInstance->c3_covrtInstance, 0U, 0, NULL, NULL, 0U, NULL);
  covrtEmlInitFcn(chartInstance->c3_covrtInstance, "", 4U, 0U, 1U, 0U, 0U, 0U,
                  0U, 0U, 1U, 0U, 0U, 0U);
  covrtEmlFcnInitFcn(chartInstance->c3_covrtInstance, 4U, 0U, 0U,
                     "c3_generic_updated_aBAJA2025_Version1", 0, -1, 1740);
  covrtEmlForInitFcn(chartInstance->c3_covrtInstance, 4U, 0U, 0U, 402, 421, 1701);
  covrtEmlInitFcn(chartInstance->c3_covrtInstance,
                  "C:/CM_Projects/aBAJA_Sample_IPGProject/src_cm4sl/msgdef/geometry_msgs_PointStruct.m",
                  14U, 0U, 1U, 0U, 1U, 0U, 0U, 0U, 0U, 0U, 1U, 1U);
  covrtEmlFcnInitFcn(chartInstance->c3_covrtInstance, 14U, 0U, 0U,
                     "geometry_msgs_PointStruct", 0, -1, 513);
  covrtEmlIfInitFcn(chartInstance->c3_covrtInstance, 14U, 0U, 0U, 441, 466, -1,
                    509, false);
  covrtEmlMCDCInitFcn(chartInstance->c3_covrtInstance, 14U, 0U, 0U, 444, 466, 1U,
                      0U, &c3_condTxtStartIdx[0], &c3_condTxtEndIdx[0], 2U,
                      &c3_postfixPredicateTree[0], false);
  covrtEmlInitFcn(chartInstance->c3_covrtInstance,
                  "C:/CM_Projects/aBAJA_Sample_IPGProject/src_cm4sl/msgdef/geometry_msgs_Vector3Struct.m",
                  14U, 1U, 1U, 0U, 1U, 0U, 0U, 0U, 0U, 0U, 1U, 1U);
  covrtEmlFcnInitFcn(chartInstance->c3_covrtInstance, 14U, 1U, 0U,
                     "geometry_msgs_Vector3Struct", 0, -1, 521);
  covrtEmlIfInitFcn(chartInstance->c3_covrtInstance, 14U, 1U, 0U, 449, 474, -1,
                    517, false);
  covrtEmlMCDCInitFcn(chartInstance->c3_covrtInstance, 14U, 1U, 0U, 452, 474, 1U,
                      0U, &c3_b_condTxtStartIdx[0], &c3_b_condTxtEndIdx[0], 2U,
                      &c3_b_postfixPredicateTree[0], false);
}

static void mdl_cleanup_runtime_resources_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  sfListenerLightTerminate(chartInstance->c3_RuntimeVar);
  covrtDeleteStateflowInstanceData(chartInstance->c3_covrtInstance);
}

static void enable_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void sf_gateway_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  c3_SL_Bus_radar_msgs_RadarTracks c3_b_emptyTracksMessage;
  emlrtStack c3_st = { NULL,           /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  real_T c3_b_accelerationArray[90];
  real_T c3_b_positionArray[90];
  real_T c3_b_sizeArray[90];
  real_T c3_b_velocityArray[90];
  real_T c3_c_i;
  int32_T c3_b_i;
  int32_T c3_d_i;
  int32_T c3_e_i;
  int32_T c3_f_i;
  int32_T c3_g_i;
  int32_T c3_i;
  int32_T c3_i1;
  int32_T c3_i10;
  int32_T c3_i11;
  int32_T c3_i12;
  int32_T c3_i13;
  int32_T c3_i14;
  int32_T c3_i15;
  int32_T c3_i16;
  int32_T c3_i17;
  int32_T c3_i18;
  int32_T c3_i19;
  int32_T c3_i2;
  int32_T c3_i20;
  int32_T c3_i21;
  int32_T c3_i22;
  int32_T c3_i23;
  int32_T c3_i24;
  int32_T c3_i25;
  int32_T c3_i26;
  int32_T c3_i27;
  int32_T c3_i28;
  int32_T c3_i29;
  int32_T c3_i3;
  int32_T c3_i30;
  int32_T c3_i31;
  int32_T c3_i32;
  int32_T c3_i33;
  int32_T c3_i34;
  int32_T c3_i35;
  int32_T c3_i36;
  int32_T c3_i37;
  int32_T c3_i38;
  int32_T c3_i39;
  int32_T c3_i4;
  int32_T c3_i40;
  int32_T c3_i41;
  int32_T c3_i42;
  int32_T c3_i43;
  int32_T c3_i44;
  int32_T c3_i45;
  int32_T c3_i46;
  int32_T c3_i47;
  int32_T c3_i48;
  int32_T c3_i49;
  int32_T c3_i5;
  int32_T c3_i50;
  int32_T c3_i51;
  int32_T c3_i52;
  int32_T c3_i53;
  int32_T c3_i54;
  int32_T c3_i55;
  int32_T c3_i56;
  int32_T c3_i57;
  int32_T c3_i58;
  int32_T c3_i59;
  int32_T c3_i6;
  int32_T c3_i60;
  int32_T c3_i61;
  int32_T c3_i62;
  int32_T c3_i63;
  int32_T c3_i64;
  int32_T c3_i65;
  int32_T c3_i66;
  int32_T c3_i67;
  int32_T c3_i68;
  int32_T c3_i69;
  int32_T c3_i7;
  int32_T c3_i8;
  int32_T c3_i9;
  real32_T c3_b_accelerationCovariance[180];
  real32_T c3_b_positionCovariance[180];
  real32_T c3_b_sizeCovariance[180];
  real32_T c3_b_velocityCovariance[180];
  uint16_T c3_b_classificationArray[30];
  c3_st.tls = chartInstance->c3_fEmlrtCtx;
  for (c3_i = 0; c3_i < 180; c3_i++) {
    covrtSigUpdateFcn(chartInstance->c3_covrtInstance, 9U, (real_T)
                      (*chartInstance->c3_sizeCovariance)[c3_i]);
  }

  for (c3_i1 = 0; c3_i1 < 180; c3_i1++) {
    covrtSigUpdateFcn(chartInstance->c3_covrtInstance, 8U, (real_T)
                      (*chartInstance->c3_accelerationCovariance)[c3_i1]);
  }

  for (c3_i2 = 0; c3_i2 < 180; c3_i2++) {
    covrtSigUpdateFcn(chartInstance->c3_covrtInstance, 7U, (real_T)
                      (*chartInstance->c3_velocityCovariance)[c3_i2]);
  }

  for (c3_i3 = 0; c3_i3 < 180; c3_i3++) {
    covrtSigUpdateFcn(chartInstance->c3_covrtInstance, 6U, (real_T)
                      (*chartInstance->c3_positionCovariance)[c3_i3]);
  }

  for (c3_i4 = 0; c3_i4 < 30; c3_i4++) {
    covrtSigUpdateFcn(chartInstance->c3_covrtInstance, 5U, (real_T)
                      (*chartInstance->c3_classificationArray)[c3_i4]);
  }

  for (c3_i5 = 0; c3_i5 < 90; c3_i5++) {
    covrtSigUpdateFcn(chartInstance->c3_covrtInstance, 4U,
                      (*chartInstance->c3_sizeArray)[c3_i5]);
  }

  for (c3_i6 = 0; c3_i6 < 90; c3_i6++) {
    covrtSigUpdateFcn(chartInstance->c3_covrtInstance, 3U,
                      (*chartInstance->c3_accelerationArray)[c3_i6]);
  }

  for (c3_i7 = 0; c3_i7 < 90; c3_i7++) {
    covrtSigUpdateFcn(chartInstance->c3_covrtInstance, 2U,
                      (*chartInstance->c3_velocityArray)[c3_i7]);
  }

  for (c3_i8 = 0; c3_i8 < 90; c3_i8++) {
    covrtSigUpdateFcn(chartInstance->c3_covrtInstance, 1U,
                      (*chartInstance->c3_positionArray)[c3_i8]);
  }

  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c3_JITTransitionAnimation[0] = 0U;
  chartInstance->c3_sfEvent = CALL_EVENT;
  c3_b_emptyTracksMessage.header.stamp.sec = *(int32_T *)&((char_T *)
    (c3_SL_Bus_builtin_interfaces_Time *)&((char_T *)(c3_SL_Bus_std_msgs_Header *)
    &((char_T *)chartInstance->c3_emptyTracksMessage)[0])[0])[0];
  c3_b_emptyTracksMessage.header.stamp.nanosec = *(uint32_T *)&((char_T *)
    (c3_SL_Bus_builtin_interfaces_Time *)&((char_T *)(c3_SL_Bus_std_msgs_Header *)
    &((char_T *)chartInstance->c3_emptyTracksMessage)[0])[0])[4];
  for (c3_i9 = 0; c3_i9 < 128; c3_i9++) {
    c3_b_emptyTracksMessage.header.frame_id[c3_i9] = (*(uint8_T (*)[128])&
      ((char_T *)(c3_SL_Bus_std_msgs_Header *)&((char_T *)
      chartInstance->c3_emptyTracksMessage)[0])[8])[c3_i9];
  }

  c3_b_emptyTracksMessage.header.frame_id_SL_Info.CurrentLength = *(uint32_T *)
    &((char_T *)(c3_SL_Bus_ROSVariableLengthArrayInfo *)&((char_T *)
       (c3_SL_Bus_std_msgs_Header *)&((char_T *)
        chartInstance->c3_emptyTracksMessage)[0])[136])[0];
  c3_b_emptyTracksMessage.header.frame_id_SL_Info.ReceivedLength = *(uint32_T *)
    &((char_T *)(c3_SL_Bus_ROSVariableLengthArrayInfo *)&((char_T *)
       (c3_SL_Bus_std_msgs_Header *)&((char_T *)
        chartInstance->c3_emptyTracksMessage)[0])[136])[4];
  for (c3_i10 = 0; c3_i10 < 30; c3_i10++) {
    for (c3_i12 = 0; c3_i12 < 16; c3_i12++) {
      c3_b_emptyTracksMessage.tracks[c3_i10].uuid.uuid[c3_i12] = (*(uint8_T (*)
        [16])&((char_T *)(c3_SL_Bus_unique_identifier_msgs_UUID *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])[0])
        [0])[c3_i12];
    }

    c3_b_emptyTracksMessage.tracks[c3_i10].position.x = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
      chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])[16])[0];
    c3_b_emptyTracksMessage.tracks[c3_i10].position.y = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
      chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])[16])[8];
    c3_b_emptyTracksMessage.tracks[c3_i10].position.z = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
      chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])[16])
      [16];
    c3_b_emptyTracksMessage.tracks[c3_i10].velocity.x = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
      chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])[40])[0];
    c3_b_emptyTracksMessage.tracks[c3_i10].velocity.y = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
      chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])[40])[8];
    c3_b_emptyTracksMessage.tracks[c3_i10].velocity.z = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
      chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])[40])
      [16];
    c3_b_emptyTracksMessage.tracks[c3_i10].acceleration.x = *(real_T *)&((char_T
      *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
      chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])[64])[0];
    c3_b_emptyTracksMessage.tracks[c3_i10].acceleration.y = *(real_T *)&((char_T
      *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
      chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])[64])[8];
    c3_b_emptyTracksMessage.tracks[c3_i10].acceleration.z = *(real_T *)&((char_T
      *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
      chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])[64])
      [16];
    c3_b_emptyTracksMessage.tracks[c3_i10].size.x = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
      chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])[88])[0];
    c3_b_emptyTracksMessage.tracks[c3_i10].size.y = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
      chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])[88])[8];
    c3_b_emptyTracksMessage.tracks[c3_i10].size.z = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
      chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])[88])
      [16];
    c3_b_emptyTracksMessage.tracks[c3_i10].classification = *(uint16_T *)
      &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
         (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
          chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])
      [112];
    for (c3_i20 = 0; c3_i20 < 6; c3_i20++) {
      c3_b_emptyTracksMessage.tracks[c3_i10].position_covariance[c3_i20] =
        (*(real32_T (*)[6])&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
          &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
            chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])
         [116])[c3_i20];
    }

    for (c3_i22 = 0; c3_i22 < 6; c3_i22++) {
      c3_b_emptyTracksMessage.tracks[c3_i10].velocity_covariance[c3_i22] =
        (*(real32_T (*)[6])&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
          &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
            chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])
         [140])[c3_i22];
    }

    for (c3_i23 = 0; c3_i23 < 6; c3_i23++) {
      c3_b_emptyTracksMessage.tracks[c3_i10].acceleration_covariance[c3_i23] = (*
        (real32_T (*)[6])&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
                           &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])
        &((char_T *)chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)
                           c3_i10])[164])[c3_i23];
    }

    for (c3_i24 = 0; c3_i24 < 6; c3_i24++) {
      c3_b_emptyTracksMessage.tracks[c3_i10].size_covariance[c3_i24] =
        (*(real32_T (*)[6])&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
          &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
            chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i10])
         [188])[c3_i24];
    }
  }

  for (c3_i11 = 0; c3_i11 < 90; c3_i11++) {
    c3_b_positionArray[c3_i11] = (*chartInstance->c3_positionArray)[c3_i11];
  }

  for (c3_i13 = 0; c3_i13 < 90; c3_i13++) {
    c3_b_velocityArray[c3_i13] = (*chartInstance->c3_velocityArray)[c3_i13];
  }

  for (c3_i14 = 0; c3_i14 < 90; c3_i14++) {
    c3_b_accelerationArray[c3_i14] = (*chartInstance->c3_accelerationArray)
      [c3_i14];
  }

  for (c3_i15 = 0; c3_i15 < 90; c3_i15++) {
    c3_b_sizeArray[c3_i15] = (*chartInstance->c3_sizeArray)[c3_i15];
  }

  for (c3_i16 = 0; c3_i16 < 30; c3_i16++) {
    c3_b_classificationArray[c3_i16] = (*chartInstance->c3_classificationArray)
      [c3_i16];
  }

  for (c3_i17 = 0; c3_i17 < 180; c3_i17++) {
    c3_b_positionCovariance[c3_i17] = (*chartInstance->c3_positionCovariance)
      [c3_i17];
  }

  for (c3_i18 = 0; c3_i18 < 180; c3_i18++) {
    c3_b_velocityCovariance[c3_i18] = (*chartInstance->c3_velocityCovariance)
      [c3_i18];
  }

  for (c3_i19 = 0; c3_i19 < 180; c3_i19++) {
    c3_b_accelerationCovariance[c3_i19] =
      (*chartInstance->c3_accelerationCovariance)[c3_i19];
  }

  for (c3_i21 = 0; c3_i21 < 180; c3_i21++) {
    c3_b_sizeCovariance[c3_i21] = (*chartInstance->c3_sizeCovariance)[c3_i21];
  }

  covrtEmlFcnEval(chartInstance->c3_covrtInstance, 4U, 0, 0);
  c3_geometry_msgs_PointStruct(chartInstance);
  c3_geometry_msgs_Vector3Struct(chartInstance);
  for (c3_b_i = 0; c3_b_i < 30; c3_b_i++) {
    c3_c_i = 1.0 + (real_T)c3_b_i;
    covrtEmlForEval(chartInstance->c3_covrtInstance, 4U, 0, 0, 1);
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_e_emlrtDCI, &c3_st);
    }

    c3_i26 = (int32_T)c3_c_i;
    if ((c3_i26 < 1) || (c3_i26 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i26, 1, 30, &c3_e_emlrtBCI, &c3_st);
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_f_emlrtDCI, &c3_st);
    }

    c3_i29 = (int32_T)c3_c_i;
    if ((c3_i29 < 1) || (c3_i29 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i29, 1, 30, &c3_f_emlrtBCI, &c3_st);
    }

    c3_b_emptyTracksMessage.tracks[c3_i29 - 1].position.x =
      c3_b_positionArray[c3_i26 - 1];
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_g_emlrtDCI, &c3_st);
    }

    c3_i30 = (int32_T)c3_c_i;
    if ((c3_i30 < 1) || (c3_i30 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i30, 1, 30, &c3_g_emlrtBCI, &c3_st);
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_h_emlrtDCI, &c3_st);
    }

    c3_i31 = (int32_T)c3_c_i;
    if ((c3_i31 < 1) || (c3_i31 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i31, 1, 30, &c3_h_emlrtBCI, &c3_st);
    }

    c3_b_emptyTracksMessage.tracks[c3_i31 - 1].position.y =
      c3_b_positionArray[c3_i30 + 29];
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_i_emlrtDCI, &c3_st);
    }

    c3_i34 = (int32_T)c3_c_i;
    if ((c3_i34 < 1) || (c3_i34 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i34, 1, 30, &c3_i_emlrtBCI, &c3_st);
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_j_emlrtDCI, &c3_st);
    }

    c3_i37 = (int32_T)c3_c_i;
    if ((c3_i37 < 1) || (c3_i37 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i37, 1, 30, &c3_j_emlrtBCI, &c3_st);
    }

    c3_b_emptyTracksMessage.tracks[c3_i37 - 1].position.z =
      c3_b_positionArray[c3_i34 + 59];
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_k_emlrtDCI, &c3_st);
    }

    c3_i38 = (int32_T)c3_c_i;
    if ((c3_i38 < 1) || (c3_i38 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i38, 1, 30, &c3_k_emlrtBCI, &c3_st);
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_l_emlrtDCI, &c3_st);
    }

    c3_i39 = (int32_T)c3_c_i;
    if ((c3_i39 < 1) || (c3_i39 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i39, 1, 30, &c3_l_emlrtBCI, &c3_st);
    }

    c3_b_emptyTracksMessage.tracks[c3_i39 - 1].velocity.x =
      c3_b_velocityArray[c3_i38 - 1];
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_m_emlrtDCI, &c3_st);
    }

    c3_i40 = (int32_T)c3_c_i;
    if ((c3_i40 < 1) || (c3_i40 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i40, 1, 30, &c3_m_emlrtBCI, &c3_st);
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_n_emlrtDCI, &c3_st);
    }

    c3_i41 = (int32_T)c3_c_i;
    if ((c3_i41 < 1) || (c3_i41 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i41, 1, 30, &c3_n_emlrtBCI, &c3_st);
    }

    c3_b_emptyTracksMessage.tracks[c3_i41 - 1].velocity.y =
      c3_b_velocityArray[c3_i40 + 29];
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_o_emlrtDCI, &c3_st);
    }

    c3_i42 = (int32_T)c3_c_i;
    if ((c3_i42 < 1) || (c3_i42 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i42, 1, 30, &c3_o_emlrtBCI, &c3_st);
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_p_emlrtDCI, &c3_st);
    }

    c3_i43 = (int32_T)c3_c_i;
    if ((c3_i43 < 1) || (c3_i43 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i43, 1, 30, &c3_p_emlrtBCI, &c3_st);
    }

    c3_b_emptyTracksMessage.tracks[c3_i43 - 1].velocity.z =
      c3_b_velocityArray[c3_i42 + 59];
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_q_emlrtDCI, &c3_st);
    }

    c3_i44 = (int32_T)c3_c_i;
    if ((c3_i44 < 1) || (c3_i44 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i44, 1, 30, &c3_q_emlrtBCI, &c3_st);
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_r_emlrtDCI, &c3_st);
    }

    c3_i45 = (int32_T)c3_c_i;
    if ((c3_i45 < 1) || (c3_i45 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i45, 1, 30, &c3_r_emlrtBCI, &c3_st);
    }

    c3_b_emptyTracksMessage.tracks[c3_i45 - 1].acceleration.x =
      c3_b_accelerationArray[c3_i44 - 1];
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_s_emlrtDCI, &c3_st);
    }

    c3_i46 = (int32_T)c3_c_i;
    if ((c3_i46 < 1) || (c3_i46 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i46, 1, 30, &c3_s_emlrtBCI, &c3_st);
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_t_emlrtDCI, &c3_st);
    }

    c3_i47 = (int32_T)c3_c_i;
    if ((c3_i47 < 1) || (c3_i47 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i47, 1, 30, &c3_t_emlrtBCI, &c3_st);
    }

    c3_b_emptyTracksMessage.tracks[c3_i47 - 1].acceleration.y =
      c3_b_accelerationArray[c3_i46 + 29];
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_u_emlrtDCI, &c3_st);
    }

    c3_i48 = (int32_T)c3_c_i;
    if ((c3_i48 < 1) || (c3_i48 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i48, 1, 30, &c3_u_emlrtBCI, &c3_st);
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_v_emlrtDCI, &c3_st);
    }

    c3_i49 = (int32_T)c3_c_i;
    if ((c3_i49 < 1) || (c3_i49 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i49, 1, 30, &c3_v_emlrtBCI, &c3_st);
    }

    c3_b_emptyTracksMessage.tracks[c3_i49 - 1].acceleration.z =
      c3_b_accelerationArray[c3_i48 + 59];
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_w_emlrtDCI, &c3_st);
    }

    c3_i50 = (int32_T)c3_c_i;
    if ((c3_i50 < 1) || (c3_i50 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i50, 1, 30, &c3_w_emlrtBCI, &c3_st);
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_x_emlrtDCI, &c3_st);
    }

    c3_i51 = (int32_T)c3_c_i;
    if ((c3_i51 < 1) || (c3_i51 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i51, 1, 30, &c3_x_emlrtBCI, &c3_st);
    }

    c3_b_emptyTracksMessage.tracks[c3_i51 - 1].size.x = c3_b_sizeArray[c3_i50 -
      1];
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_y_emlrtDCI, &c3_st);
    }

    c3_i52 = (int32_T)c3_c_i;
    if ((c3_i52 < 1) || (c3_i52 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i52, 1, 30, &c3_y_emlrtBCI, &c3_st);
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_ab_emlrtDCI, &c3_st);
    }

    c3_i53 = (int32_T)c3_c_i;
    if ((c3_i53 < 1) || (c3_i53 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i53, 1, 30, &c3_ab_emlrtBCI, &c3_st);
    }

    c3_b_emptyTracksMessage.tracks[c3_i53 - 1].size.y = c3_b_sizeArray[c3_i52 +
      29];
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_bb_emlrtDCI, &c3_st);
    }

    c3_i54 = (int32_T)c3_c_i;
    if ((c3_i54 < 1) || (c3_i54 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i54, 1, 30, &c3_bb_emlrtBCI, &c3_st);
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_cb_emlrtDCI, &c3_st);
    }

    c3_i55 = (int32_T)c3_c_i;
    if ((c3_i55 < 1) || (c3_i55 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i55, 1, 30, &c3_cb_emlrtBCI, &c3_st);
    }

    c3_b_emptyTracksMessage.tracks[c3_i55 - 1].size.z = c3_b_sizeArray[c3_i54 +
      59];
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_db_emlrtDCI, &c3_st);
    }

    c3_i56 = (int32_T)c3_c_i;
    if ((c3_i56 < 1) || (c3_i56 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i56, 1, 30, &c3_db_emlrtBCI, &c3_st);
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_eb_emlrtDCI, &c3_st);
    }

    c3_i57 = (int32_T)c3_c_i;
    if ((c3_i57 < 1) || (c3_i57 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i57, 1, 30, &c3_eb_emlrtBCI, &c3_st);
    }

    c3_b_emptyTracksMessage.tracks[c3_i57 - 1].classification =
      c3_b_classificationArray[c3_i56 - 1];
    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_emlrtDCI, &c3_st);
    }

    c3_i58 = (int32_T)c3_c_i;
    if ((c3_i58 < 1) || (c3_i58 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i58, 1, 30, &c3_emlrtBCI, &c3_st);
    }

    c3_d_i = c3_i58 - 1;
    for (c3_i59 = 0; c3_i59 < 6; c3_i59++) {
      if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
        emlrtIntegerCheckR2012b(c3_c_i, &c3_fb_emlrtDCI, &c3_st);
      }

      c3_i61 = (int32_T)c3_c_i;
      if ((c3_i61 < 1) || (c3_i61 > 30)) {
        emlrtDynamicBoundsCheckR2012b(c3_i61, 1, 30, &c3_fb_emlrtBCI, &c3_st);
      }

      c3_b_emptyTracksMessage.tracks[c3_i61 - 1].position_covariance[c3_i59] =
        c3_b_positionCovariance[c3_d_i + 30 * c3_i59];
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_b_emlrtDCI, &c3_st);
    }

    c3_i60 = (int32_T)c3_c_i;
    if ((c3_i60 < 1) || (c3_i60 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i60, 1, 30, &c3_b_emlrtBCI, &c3_st);
    }

    c3_e_i = c3_i60 - 1;
    for (c3_i62 = 0; c3_i62 < 6; c3_i62++) {
      if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
        emlrtIntegerCheckR2012b(c3_c_i, &c3_gb_emlrtDCI, &c3_st);
      }

      c3_i64 = (int32_T)c3_c_i;
      if ((c3_i64 < 1) || (c3_i64 > 30)) {
        emlrtDynamicBoundsCheckR2012b(c3_i64, 1, 30, &c3_gb_emlrtBCI, &c3_st);
      }

      c3_b_emptyTracksMessage.tracks[c3_i64 - 1].velocity_covariance[c3_i62] =
        c3_b_velocityCovariance[c3_e_i + 30 * c3_i62];
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_c_emlrtDCI, &c3_st);
    }

    c3_i63 = (int32_T)c3_c_i;
    if ((c3_i63 < 1) || (c3_i63 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i63, 1, 30, &c3_c_emlrtBCI, &c3_st);
    }

    c3_f_i = c3_i63 - 1;
    for (c3_i65 = 0; c3_i65 < 6; c3_i65++) {
      if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
        emlrtIntegerCheckR2012b(c3_c_i, &c3_hb_emlrtDCI, &c3_st);
      }

      c3_i67 = (int32_T)c3_c_i;
      if ((c3_i67 < 1) || (c3_i67 > 30)) {
        emlrtDynamicBoundsCheckR2012b(c3_i67, 1, 30, &c3_hb_emlrtBCI, &c3_st);
      }

      c3_b_emptyTracksMessage.tracks[c3_i67 - 1].acceleration_covariance[c3_i65]
        = c3_b_accelerationCovariance[c3_f_i + 30 * c3_i65];
    }

    if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
      emlrtIntegerCheckR2012b(c3_c_i, &c3_d_emlrtDCI, &c3_st);
    }

    c3_i66 = (int32_T)c3_c_i;
    if ((c3_i66 < 1) || (c3_i66 > 30)) {
      emlrtDynamicBoundsCheckR2012b(c3_i66, 1, 30, &c3_d_emlrtBCI, &c3_st);
    }

    c3_g_i = c3_i66 - 1;
    for (c3_i68 = 0; c3_i68 < 6; c3_i68++) {
      if (c3_c_i != (real_T)(int32_T)muDoubleScalarFloor(c3_c_i)) {
        emlrtIntegerCheckR2012b(c3_c_i, &c3_ib_emlrtDCI, &c3_st);
      }

      c3_i69 = (int32_T)c3_c_i;
      if ((c3_i69 < 1) || (c3_i69 > 30)) {
        emlrtDynamicBoundsCheckR2012b(c3_i69, 1, 30, &c3_ib_emlrtBCI, &c3_st);
      }

      c3_b_emptyTracksMessage.tracks[c3_i69 - 1].size_covariance[c3_i68] =
        c3_b_sizeCovariance[c3_g_i + 30 * c3_i68];
    }

    _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
  }

  covrtEmlForEval(chartInstance->c3_covrtInstance, 4U, 0, 0, 0);
  *(int32_T *)&((char_T *)(c3_SL_Bus_builtin_interfaces_Time *)&((char_T *)
    (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[0])[0] =
    c3_b_emptyTracksMessage.header.stamp.sec;
  *(uint32_T *)&((char_T *)(c3_SL_Bus_builtin_interfaces_Time *)&((char_T *)
    (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[0])[4] =
    c3_b_emptyTracksMessage.header.stamp.nanosec;
  for (c3_i25 = 0; c3_i25 < 128; c3_i25++) {
    (*(uint8_T (*)[128])&((char_T *)(c3_SL_Bus_std_msgs_Header *)&((char_T *)
       chartInstance->c3_msg)[0])[8])[c3_i25] =
      c3_b_emptyTracksMessage.header.frame_id[c3_i25];
  }

  *(uint32_T *)&((char_T *)(c3_SL_Bus_ROSVariableLengthArrayInfo *)&((char_T *)
    (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[136])[0]
    = c3_b_emptyTracksMessage.header.frame_id_SL_Info.CurrentLength;
  *(uint32_T *)&((char_T *)(c3_SL_Bus_ROSVariableLengthArrayInfo *)&((char_T *)
    (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[136])[4]
    = c3_b_emptyTracksMessage.header.frame_id_SL_Info.ReceivedLength;
  for (c3_i27 = 0; c3_i27 < 30; c3_i27++) {
    for (c3_i28 = 0; c3_i28 < 16; c3_i28++) {
      (*(uint8_T (*)[16])&((char_T *)(c3_SL_Bus_unique_identifier_msgs_UUID *)
                           &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
         &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
           chartInstance->c3_msg)[144])[216 * (int32_T)c3_i27])[0])[0])[c3_i28] =
        c3_b_emptyTracksMessage.tracks[c3_i27].uuid.uuid[c3_i28];
    }

    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i27])[16])[0] =
      c3_b_emptyTracksMessage.tracks[c3_i27].position.x;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i27])[16])[8] =
      c3_b_emptyTracksMessage.tracks[c3_i27].position.y;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i27])[16])[16] =
      c3_b_emptyTracksMessage.tracks[c3_i27].position.z;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i27])[40])[0] =
      c3_b_emptyTracksMessage.tracks[c3_i27].velocity.x;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i27])[40])[8] =
      c3_b_emptyTracksMessage.tracks[c3_i27].velocity.y;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i27])[40])[16] =
      c3_b_emptyTracksMessage.tracks[c3_i27].velocity.z;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i27])[64])[0] =
      c3_b_emptyTracksMessage.tracks[c3_i27].acceleration.x;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i27])[64])[8] =
      c3_b_emptyTracksMessage.tracks[c3_i27].acceleration.y;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i27])[64])[16] =
      c3_b_emptyTracksMessage.tracks[c3_i27].acceleration.z;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i27])[88])[0] =
      c3_b_emptyTracksMessage.tracks[c3_i27].size.x;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i27])[88])[8] =
      c3_b_emptyTracksMessage.tracks[c3_i27].size.y;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i27])[88])[16] =
      c3_b_emptyTracksMessage.tracks[c3_i27].size.z;
    *(uint16_T *)&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i27])[112] =
      c3_b_emptyTracksMessage.tracks[c3_i27].classification;
    for (c3_i32 = 0; c3_i32 < 6; c3_i32++) {
      (*(real32_T (*)[6])&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
                           &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])
         &((char_T *)chartInstance->c3_msg)[144])[216 * (int32_T)c3_i27])[116])
        [c3_i32] = c3_b_emptyTracksMessage.tracks[c3_i27]
        .position_covariance[c3_i32];
    }

    for (c3_i33 = 0; c3_i33 < 6; c3_i33++) {
      (*(real32_T (*)[6])&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
                           &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])
         &((char_T *)chartInstance->c3_msg)[144])[216 * (int32_T)c3_i27])[140])
        [c3_i33] = c3_b_emptyTracksMessage.tracks[c3_i27]
        .velocity_covariance[c3_i33];
    }

    for (c3_i35 = 0; c3_i35 < 6; c3_i35++) {
      (*(real32_T (*)[6])&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
                           &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])
         &((char_T *)chartInstance->c3_msg)[144])[216 * (int32_T)c3_i27])[164])
        [c3_i35] = c3_b_emptyTracksMessage.tracks[c3_i27].
        acceleration_covariance[c3_i35];
    }

    for (c3_i36 = 0; c3_i36 < 6; c3_i36++) {
      (*(real32_T (*)[6])&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
                           &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])
         &((char_T *)chartInstance->c3_msg)[144])[216 * (int32_T)c3_i27])[188])
        [c3_i36] = c3_b_emptyTracksMessage.tracks[c3_i27].size_covariance[c3_i36];
    }
  }
}

static void ext_mode_exec_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c3_update_jit_animation_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c3_do_animation_call_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static const mxArray *get_sim_state_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  static const char_T *c3_sv1[3] = { "stamp", "frame_id", "frame_id_SL_Info" };

  static const char_T *c3_sv5[3] = { "x", "y", "z" };

  static const char_T *c3_b_sv[2] = { "header", "tracks" };

  static const char_T *c3_sv2[2] = { "sec", "nanosec" };

  static const char_T *c3_sv3[2] = { "CurrentLength", "ReceivedLength" };

  static const char_T *c3_sv4[1] = { "uuid" };

  c3_SL_Bus_ROSVariableLengthArrayInfo c3_f_u;
  c3_SL_Bus_builtin_interfaces_Time c3_b_u;
  c3_SL_Bus_geometry_msgs_Point c3_l_u;
  c3_SL_Bus_geometry_msgs_Vector3 c3_p_u;
  c3_SL_Bus_radar_msgs_RadarTrack c3_i_u[30];
  const c3_SL_Bus_radar_msgs_RadarTrack *c3_r;
  c3_SL_Bus_std_msgs_Header c3_u;
  c3_SL_Bus_unique_identifier_msgs_UUID c3_j_u;
  const mxArray *c3_ab_y = NULL;
  const mxArray *c3_b_y = NULL;
  const mxArray *c3_bb_y = NULL;
  const mxArray *c3_c_y = NULL;
  const mxArray *c3_cb_y = NULL;
  const mxArray *c3_d_y = NULL;
  const mxArray *c3_db_y = NULL;
  const mxArray *c3_e_y = NULL;
  const mxArray *c3_eb_y = NULL;
  const mxArray *c3_f_y = NULL;
  const mxArray *c3_fb_y = NULL;
  const mxArray *c3_g_y = NULL;
  const mxArray *c3_gb_y = NULL;
  const mxArray *c3_h_y = NULL;
  const mxArray *c3_hb_y = NULL;
  const mxArray *c3_i_y = NULL;
  const mxArray *c3_ib_y = NULL;
  const mxArray *c3_j_y = NULL;
  const mxArray *c3_k_y = NULL;
  const mxArray *c3_l_y = NULL;
  const mxArray *c3_m_y = NULL;
  const mxArray *c3_n_y = NULL;
  const mxArray *c3_o_y = NULL;
  const mxArray *c3_p_y = NULL;
  const mxArray *c3_q_y = NULL;
  const mxArray *c3_r_y = NULL;
  const mxArray *c3_s_y = NULL;
  const mxArray *c3_st;
  const mxArray *c3_t_y = NULL;
  const mxArray *c3_u_y = NULL;
  const mxArray *c3_v_y = NULL;
  const mxArray *c3_w_y = NULL;
  const mxArray *c3_x_y = NULL;
  const mxArray *c3_y = NULL;
  const mxArray *c3_y_y = NULL;
  real_T c3_m_u;
  real_T c3_n_u;
  real_T c3_o_u;
  real_T c3_q_u;
  real_T c3_r_u;
  real_T c3_s_u;
  real_T c3_t_u;
  real_T c3_u_u;
  real_T c3_v_u;
  real_T c3_w_u;
  real_T c3_x_u;
  real_T c3_y_u;
  int32_T c3_dims[1] = { 30 };

  int32_T c3_c_u;
  int32_T c3_i;
  int32_T c3_i1;
  int32_T c3_i10;
  int32_T c3_i11;
  int32_T c3_i12;
  int32_T c3_i13;
  int32_T c3_i2;
  int32_T c3_i3;
  int32_T c3_i4;
  int32_T c3_i5;
  int32_T c3_i6;
  int32_T c3_i7;
  int32_T c3_i8;
  int32_T c3_i9;
  real32_T c3_bb_u[6];
  uint32_T c3_d_u;
  uint32_T c3_g_u;
  uint32_T c3_h_u;
  uint16_T c3_ab_u;
  const char_T *c3_fieldNames[10] = { "uuid", "position", "velocity",
    "acceleration", "size", "classification", "position_covariance",
    "velocity_covariance", "acceleration_covariance", "size_covariance" };

  uint8_T c3_e_u[128];
  uint8_T c3_k_u[16];
  c3_st = NULL;
  c3_st = NULL;
  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_createcellmatrix(1, 1), false);
  c3_b_y = NULL;
  sf_mex_assign(&c3_b_y, sf_mex_createstruct("structure", 2, c3_b_sv, 2, 1, 1),
                false);
  c3_u.stamp.sec = *(int32_T *)&((char_T *)(c3_SL_Bus_builtin_interfaces_Time *)
    &((char_T *)(c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)
      [0])[0])[0];
  c3_u.stamp.nanosec = *(uint32_T *)&((char_T *)
    (c3_SL_Bus_builtin_interfaces_Time *)&((char_T *)(c3_SL_Bus_std_msgs_Header *)
    &((char_T *)chartInstance->c3_msg)[0])[0])[4];
  for (c3_i = 0; c3_i < 128; c3_i++) {
    c3_u.frame_id[c3_i] = (*(uint8_T (*)[128])&((char_T *)
      (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[8])
      [c3_i];
  }

  c3_u.frame_id_SL_Info.CurrentLength = *(uint32_T *)&((char_T *)
    (c3_SL_Bus_ROSVariableLengthArrayInfo *)&((char_T *)
    (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[136])[0];
  c3_u.frame_id_SL_Info.ReceivedLength = *(uint32_T *)&((char_T *)
    (c3_SL_Bus_ROSVariableLengthArrayInfo *)&((char_T *)
    (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[136])[4];
  c3_c_y = NULL;
  sf_mex_assign(&c3_c_y, sf_mex_createstruct("structure", 3, c3_sv1, 2, 1, 1),
                false);
  c3_b_u = c3_u.stamp;
  c3_d_y = NULL;
  sf_mex_assign(&c3_d_y, sf_mex_createstruct("structure", 2, c3_sv2, 2, 1, 1),
                false);
  c3_c_u = c3_b_u.sec;
  c3_e_y = NULL;
  sf_mex_assign(&c3_e_y, sf_mex_create("y", &c3_c_u, 6, 0U, 0, 0U, 0), false);
  sf_mex_setfieldbyindex(c3_d_y, 0, "sec", c3_e_y, 0);
  c3_d_u = c3_b_u.nanosec;
  c3_f_y = NULL;
  sf_mex_assign(&c3_f_y, sf_mex_create("y", &c3_d_u, 7, 0U, 0, 0U, 0), false);
  sf_mex_setfieldbyindex(c3_d_y, 0, "nanosec", c3_f_y, 1);
  sf_mex_setfieldbyindex(c3_c_y, 0, "stamp", c3_d_y, 0);
  for (c3_i1 = 0; c3_i1 < 128; c3_i1++) {
    c3_e_u[c3_i1] = c3_u.frame_id[c3_i1];
  }

  c3_g_y = NULL;
  sf_mex_assign(&c3_g_y, sf_mex_create("y", c3_e_u, 3, 0U, 1, 0U, 1, 128), false);
  sf_mex_setfieldbyindex(c3_c_y, 0, "frame_id", c3_g_y, 1);
  c3_f_u = c3_u.frame_id_SL_Info;
  c3_h_y = NULL;
  sf_mex_assign(&c3_h_y, sf_mex_createstruct("structure", 2, c3_sv3, 2, 1, 1),
                false);
  c3_g_u = c3_f_u.CurrentLength;
  c3_i_y = NULL;
  sf_mex_assign(&c3_i_y, sf_mex_create("y", &c3_g_u, 7, 0U, 0, 0U, 0), false);
  sf_mex_setfieldbyindex(c3_h_y, 0, "CurrentLength", c3_i_y, 0);
  c3_h_u = c3_f_u.ReceivedLength;
  c3_j_y = NULL;
  sf_mex_assign(&c3_j_y, sf_mex_create("y", &c3_h_u, 7, 0U, 0, 0U, 0), false);
  sf_mex_setfieldbyindex(c3_h_y, 0, "ReceivedLength", c3_j_y, 1);
  sf_mex_setfieldbyindex(c3_c_y, 0, "frame_id_SL_Info", c3_h_y, 2);
  sf_mex_setfieldbyindex(c3_b_y, 0, "header", c3_c_y, 0);
  for (c3_i2 = 0; c3_i2 < 30; c3_i2++) {
    for (c3_i3 = 0; c3_i3 < 16; c3_i3++) {
      c3_i_u[c3_i2].uuid.uuid[c3_i3] = (*(uint8_T (*)[16])&((char_T *)
        (c3_SL_Bus_unique_identifier_msgs_UUID *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i2])[0])[0])[c3_i3];
    }

    c3_i_u[c3_i2].position.x = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i2])[16])[0];
    c3_i_u[c3_i2].position.y = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i2])[16])[8];
    c3_i_u[c3_i2].position.z = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i2])[16])[16];
    c3_i_u[c3_i2].velocity.x = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i2])[40])[0];
    c3_i_u[c3_i2].velocity.y = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i2])[40])[8];
    c3_i_u[c3_i2].velocity.z = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i2])[40])[16];
    c3_i_u[c3_i2].acceleration.x = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i2])[64])[0];
    c3_i_u[c3_i2].acceleration.y = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i2])[64])[8];
    c3_i_u[c3_i2].acceleration.z = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i2])[64])[16];
    c3_i_u[c3_i2].size.x = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i2])[88])[0];
    c3_i_u[c3_i2].size.y = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i2])[88])[8];
    c3_i_u[c3_i2].size.z = *(real_T *)&((char_T *)
      (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i2])[88])[16];
    c3_i_u[c3_i2].classification = *(uint16_T *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i2])[112];
    for (c3_i6 = 0; c3_i6 < 6; c3_i6++) {
      c3_i_u[c3_i2].position_covariance[c3_i6] = (*(real32_T (*)[6])&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i2])[116])[c3_i6];
    }

    for (c3_i7 = 0; c3_i7 < 6; c3_i7++) {
      c3_i_u[c3_i2].velocity_covariance[c3_i7] = (*(real32_T (*)[6])&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i2])[140])[c3_i7];
    }

    for (c3_i8 = 0; c3_i8 < 6; c3_i8++) {
      c3_i_u[c3_i2].acceleration_covariance[c3_i8] = (*(real32_T (*)[6])&
        ((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i2])[164])[c3_i8];
    }

    for (c3_i9 = 0; c3_i9 < 6; c3_i9++) {
      c3_i_u[c3_i2].size_covariance[c3_i9] = (*(real32_T (*)[6])&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i2])[188])[c3_i9];
    }
  }

  c3_k_y = NULL;
  sf_mex_assign(&c3_k_y, sf_mex_createstructarray("structure", 1, &c3_dims[0],
    10, &c3_fieldNames[0]), false);
  for (c3_i4 = 0; c3_i4 < 30; c3_i4++) {
    c3_r = &c3_i_u[c3_i4];
    c3_j_u = c3_r->uuid;
    c3_l_y = NULL;
    sf_mex_assign(&c3_l_y, sf_mex_createstruct("structure", 1, c3_sv4, 2, 1, 1),
                  false);
    for (c3_i5 = 0; c3_i5 < 16; c3_i5++) {
      c3_k_u[c3_i5] = c3_j_u.uuid[c3_i5];
    }

    c3_m_y = NULL;
    sf_mex_assign(&c3_m_y, sf_mex_create("y", c3_k_u, 3, 0U, 1, 0U, 1, 16),
                  false);
    sf_mex_setfieldbyindex(c3_l_y, 0, "uuid", c3_m_y, 0);
    sf_mex_setfieldbyindex(c3_k_y, c3_i4, "uuid", c3_l_y, 0);
    c3_l_u = c3_r->position;
    c3_n_y = NULL;
    sf_mex_assign(&c3_n_y, sf_mex_createstruct("structure", 3, c3_sv5, 2, 1, 1),
                  false);
    c3_m_u = c3_l_u.x;
    c3_o_y = NULL;
    sf_mex_assign(&c3_o_y, sf_mex_create("y", &c3_m_u, 0, 0U, 0, 0U, 0), false);
    sf_mex_setfieldbyindex(c3_n_y, 0, "x", c3_o_y, 0);
    c3_n_u = c3_l_u.y;
    c3_p_y = NULL;
    sf_mex_assign(&c3_p_y, sf_mex_create("y", &c3_n_u, 0, 0U, 0, 0U, 0), false);
    sf_mex_setfieldbyindex(c3_n_y, 0, "y", c3_p_y, 1);
    c3_o_u = c3_l_u.z;
    c3_q_y = NULL;
    sf_mex_assign(&c3_q_y, sf_mex_create("y", &c3_o_u, 0, 0U, 0, 0U, 0), false);
    sf_mex_setfieldbyindex(c3_n_y, 0, "z", c3_q_y, 2);
    sf_mex_setfieldbyindex(c3_k_y, c3_i4, "position", c3_n_y, 1);
    c3_p_u = c3_r->velocity;
    c3_r_y = NULL;
    sf_mex_assign(&c3_r_y, sf_mex_createstruct("structure", 3, c3_sv5, 2, 1, 1),
                  false);
    c3_q_u = c3_p_u.x;
    c3_s_y = NULL;
    sf_mex_assign(&c3_s_y, sf_mex_create("y", &c3_q_u, 0, 0U, 0, 0U, 0), false);
    sf_mex_setfieldbyindex(c3_r_y, 0, "x", c3_s_y, 0);
    c3_r_u = c3_p_u.y;
    c3_t_y = NULL;
    sf_mex_assign(&c3_t_y, sf_mex_create("y", &c3_r_u, 0, 0U, 0, 0U, 0), false);
    sf_mex_setfieldbyindex(c3_r_y, 0, "y", c3_t_y, 1);
    c3_s_u = c3_p_u.z;
    c3_u_y = NULL;
    sf_mex_assign(&c3_u_y, sf_mex_create("y", &c3_s_u, 0, 0U, 0, 0U, 0), false);
    sf_mex_setfieldbyindex(c3_r_y, 0, "z", c3_u_y, 2);
    sf_mex_setfieldbyindex(c3_k_y, c3_i4, "velocity", c3_r_y, 2);
    c3_p_u = c3_r->acceleration;
    c3_v_y = NULL;
    sf_mex_assign(&c3_v_y, sf_mex_createstruct("structure", 3, c3_sv5, 2, 1, 1),
                  false);
    c3_t_u = c3_p_u.x;
    c3_w_y = NULL;
    sf_mex_assign(&c3_w_y, sf_mex_create("y", &c3_t_u, 0, 0U, 0, 0U, 0), false);
    sf_mex_setfieldbyindex(c3_v_y, 0, "x", c3_w_y, 0);
    c3_u_u = c3_p_u.y;
    c3_x_y = NULL;
    sf_mex_assign(&c3_x_y, sf_mex_create("y", &c3_u_u, 0, 0U, 0, 0U, 0), false);
    sf_mex_setfieldbyindex(c3_v_y, 0, "y", c3_x_y, 1);
    c3_v_u = c3_p_u.z;
    c3_y_y = NULL;
    sf_mex_assign(&c3_y_y, sf_mex_create("y", &c3_v_u, 0, 0U, 0, 0U, 0), false);
    sf_mex_setfieldbyindex(c3_v_y, 0, "z", c3_y_y, 2);
    sf_mex_setfieldbyindex(c3_k_y, c3_i4, "acceleration", c3_v_y, 3);
    c3_p_u = c3_r->size;
    c3_ab_y = NULL;
    sf_mex_assign(&c3_ab_y, sf_mex_createstruct("structure", 3, c3_sv5, 2, 1, 1),
                  false);
    c3_w_u = c3_p_u.x;
    c3_bb_y = NULL;
    sf_mex_assign(&c3_bb_y, sf_mex_create("y", &c3_w_u, 0, 0U, 0, 0U, 0), false);
    sf_mex_setfieldbyindex(c3_ab_y, 0, "x", c3_bb_y, 0);
    c3_x_u = c3_p_u.y;
    c3_cb_y = NULL;
    sf_mex_assign(&c3_cb_y, sf_mex_create("y", &c3_x_u, 0, 0U, 0, 0U, 0), false);
    sf_mex_setfieldbyindex(c3_ab_y, 0, "y", c3_cb_y, 1);
    c3_y_u = c3_p_u.z;
    c3_db_y = NULL;
    sf_mex_assign(&c3_db_y, sf_mex_create("y", &c3_y_u, 0, 0U, 0, 0U, 0), false);
    sf_mex_setfieldbyindex(c3_ab_y, 0, "z", c3_db_y, 2);
    sf_mex_setfieldbyindex(c3_k_y, c3_i4, "size", c3_ab_y, 4);
    c3_ab_u = c3_r->classification;
    c3_eb_y = NULL;
    sf_mex_assign(&c3_eb_y, sf_mex_create("y", &c3_ab_u, 5, 0U, 0, 0U, 0), false);
    sf_mex_setfieldbyindex(c3_k_y, c3_i4, "classification", c3_eb_y, 5);
    for (c3_i10 = 0; c3_i10 < 6; c3_i10++) {
      c3_bb_u[c3_i10] = c3_r->position_covariance[c3_i10];
    }

    c3_fb_y = NULL;
    sf_mex_assign(&c3_fb_y, sf_mex_create("y", c3_bb_u, 1, 0U, 1, 0U, 1, 6),
                  false);
    sf_mex_setfieldbyindex(c3_k_y, c3_i4, "position_covariance", c3_fb_y, 6);
    for (c3_i11 = 0; c3_i11 < 6; c3_i11++) {
      c3_bb_u[c3_i11] = c3_r->velocity_covariance[c3_i11];
    }

    c3_gb_y = NULL;
    sf_mex_assign(&c3_gb_y, sf_mex_create("y", c3_bb_u, 1, 0U, 1, 0U, 1, 6),
                  false);
    sf_mex_setfieldbyindex(c3_k_y, c3_i4, "velocity_covariance", c3_gb_y, 7);
    for (c3_i12 = 0; c3_i12 < 6; c3_i12++) {
      c3_bb_u[c3_i12] = c3_r->acceleration_covariance[c3_i12];
    }

    c3_hb_y = NULL;
    sf_mex_assign(&c3_hb_y, sf_mex_create("y", c3_bb_u, 1, 0U, 1, 0U, 1, 6),
                  false);
    sf_mex_setfieldbyindex(c3_k_y, c3_i4, "acceleration_covariance", c3_hb_y, 8);
    for (c3_i13 = 0; c3_i13 < 6; c3_i13++) {
      c3_bb_u[c3_i13] = c3_r->size_covariance[c3_i13];
    }

    c3_ib_y = NULL;
    sf_mex_assign(&c3_ib_y, sf_mex_create("y", c3_bb_u, 1, 0U, 1, 0U, 1, 6),
                  false);
    sf_mex_setfieldbyindex(c3_k_y, c3_i4, "size_covariance", c3_ib_y, 9);
  }

  sf_mex_setfieldbyindex(c3_b_y, 0, "tracks", c3_k_y, 1);
  sf_mex_setcell(c3_y, 0, c3_b_y);
  sf_mex_assign(&c3_st, c3_y, false);
  return c3_st;
}

static void set_sim_state_c3_generic_updated_aBAJA2025_Version1
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_st)
{
  c3_SL_Bus_radar_msgs_RadarTracks c3_r;
  const mxArray *c3_u;
  int32_T c3_i;
  int32_T c3_i1;
  int32_T c3_i2;
  int32_T c3_i3;
  int32_T c3_i4;
  int32_T c3_i5;
  int32_T c3_i6;
  chartInstance->c3_doneDoubleBufferReInit = true;
  c3_u = sf_mex_dup(c3_st);
  c3_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c3_u, 0)), "msg",
                      &c3_r);
  *(int32_T *)&((char_T *)(c3_SL_Bus_builtin_interfaces_Time *)&((char_T *)
    (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[0])[0] =
    c3_r.header.stamp.sec;
  *(uint32_T *)&((char_T *)(c3_SL_Bus_builtin_interfaces_Time *)&((char_T *)
    (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[0])[4] =
    c3_r.header.stamp.nanosec;
  for (c3_i = 0; c3_i < 128; c3_i++) {
    (*(uint8_T (*)[128])&((char_T *)(c3_SL_Bus_std_msgs_Header *)&((char_T *)
       chartInstance->c3_msg)[0])[8])[c3_i] = c3_r.header.frame_id[c3_i];
  }

  *(uint32_T *)&((char_T *)(c3_SL_Bus_ROSVariableLengthArrayInfo *)&((char_T *)
    (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[136])[0]
    = c3_r.header.frame_id_SL_Info.CurrentLength;
  *(uint32_T *)&((char_T *)(c3_SL_Bus_ROSVariableLengthArrayInfo *)&((char_T *)
    (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[136])[4]
    = c3_r.header.frame_id_SL_Info.ReceivedLength;
  for (c3_i1 = 0; c3_i1 < 30; c3_i1++) {
    for (c3_i2 = 0; c3_i2 < 16; c3_i2++) {
      (*(uint8_T (*)[16])&((char_T *)(c3_SL_Bus_unique_identifier_msgs_UUID *)
                           &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
         &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
           chartInstance->c3_msg)[144])[216 * (int32_T)c3_i1])[0])[0])[c3_i2] =
        c3_r.tracks[c3_i1].uuid.uuid[c3_i2];
    }

    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i1])[16])[0] = c3_r.tracks[c3_i1].position.x;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i1])[16])[8] = c3_r.tracks[c3_i1].position.y;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i1])[16])[16] = c3_r.tracks[c3_i1].position.z;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i1])[40])[0] = c3_r.tracks[c3_i1].velocity.x;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i1])[40])[8] = c3_r.tracks[c3_i1].velocity.y;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i1])[40])[16] = c3_r.tracks[c3_i1].velocity.z;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i1])[64])[0] = c3_r.tracks[c3_i1].acceleration.x;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i1])[64])[8] = c3_r.tracks[c3_i1].acceleration.y;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i1])[64])[16] = c3_r.tracks[c3_i1].acceleration.z;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i1])[88])[0] = c3_r.tracks[c3_i1].size.x;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i1])[88])[8] = c3_r.tracks[c3_i1].size.y;
    *(real_T *)&((char_T *)(c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i1])[88])[16] = c3_r.tracks[c3_i1].size.z;
    *(uint16_T *)&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
      (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)chartInstance->c3_msg)
      [144])[216 * (int32_T)c3_i1])[112] = c3_r.tracks[c3_i1].classification;
    for (c3_i3 = 0; c3_i3 < 6; c3_i3++) {
      (*(real32_T (*)[6])&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
                           &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])
         &((char_T *)chartInstance->c3_msg)[144])[216 * (int32_T)c3_i1])[116])
        [c3_i3] = c3_r.tracks[c3_i1].position_covariance[c3_i3];
    }

    for (c3_i4 = 0; c3_i4 < 6; c3_i4++) {
      (*(real32_T (*)[6])&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
                           &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])
         &((char_T *)chartInstance->c3_msg)[144])[216 * (int32_T)c3_i1])[140])
        [c3_i4] = c3_r.tracks[c3_i1].velocity_covariance[c3_i4];
    }

    for (c3_i5 = 0; c3_i5 < 6; c3_i5++) {
      (*(real32_T (*)[6])&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
                           &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])
         &((char_T *)chartInstance->c3_msg)[144])[216 * (int32_T)c3_i1])[164])
        [c3_i5] = c3_r.tracks[c3_i1].acceleration_covariance[c3_i5];
    }

    for (c3_i6 = 0; c3_i6 < 6; c3_i6++) {
      (*(real32_T (*)[6])&((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)
                           &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack (*)[30])
         &((char_T *)chartInstance->c3_msg)[144])[216 * (int32_T)c3_i1])[188])
        [c3_i6] = c3_r.tracks[c3_i1].size_covariance[c3_i6];
    }
  }

  sf_mex_destroy(&c3_u);
  sf_mex_destroy(&c3_st);
}

static c3_geometry_msgs_PointStruct_T c3_geometry_msgs_PointStruct
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  static c3_geometry_msgs_PointStruct_T c3_r = { { 'g', 'e', 'o', 'm', 'e', 't',
      'r', 'y', '_', 'm', 's', 'g', 's', '/', 'P', 'o', 'i', 'n', 't' },/* MessageType */
    0.0,                               /* x */
    0.0,                               /* y */
    0.0                                /* z */
  };

  c3_geometry_msgs_PointStruct_T c3_b_msg;
  c3_b_msg = c3_r;
  covrtEmlFcnEval(chartInstance->c3_covrtInstance, 14U, 0, 0);
  covrtEmlCondEval(chartInstance->c3_covrtInstance, 14U, 0, 0, false);
  covrtEmlMcdcEval(chartInstance->c3_covrtInstance, 14U, 0, 0, true);
  covrtEmlIfEval(chartInstance->c3_covrtInstance, 14U, 0, 0, true);

  //(&c3_b_msg);
  return c3_b_msg;
}

static c3_geometry_msgs_Vector3Struct_T c3_geometry_msgs_Vector3Struct
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  static c3_geometry_msgs_Vector3Struct_T c3_r = { { 'g', 'e', 'o', 'm', 'e',
      't', 'r', 'y', '_', 'm', 's', 'g', 's', '/', 'V', 'e', 'c', 't', 'o', 'r',
      '3' },                           /* MessageType */
    0.0,                               /* x */
    0.0,                               /* y */
    0.0                                /* z */
  };

  c3_geometry_msgs_Vector3Struct_T c3_b_msg;
  c3_b_msg = c3_r;
  covrtEmlFcnEval(chartInstance->c3_covrtInstance, 14U, 1, 0);
  covrtEmlCondEval(chartInstance->c3_covrtInstance, 14U, 1, 0, false);
  covrtEmlMcdcEval(chartInstance->c3_covrtInstance, 14U, 1, 0, true);
  covrtEmlIfEval(chartInstance->c3_covrtInstance, 14U, 1, 0, true);

  //(&c3_b_msg);
  return c3_b_msg;
}

const mxArray
  *sf_c3_generic_updated_aBAJA2025_Version1_get_eml_resolved_functions_info(void)
{
  const mxArray *c3_nameCaptureInfo = NULL;
  const char_T *c3_data[5] = {
    "789ced544f4bc3301c4d454110752741bc7a169de29c3737ff4d99d4756c83456adbc5ad2e6924893a6f7e03413c087e11ef825fc22fe1cdabebd66c6ba174e8"
    "984cfd1dfacbe32579afbf9607944c560100cc8076bd4fb5fbb487635e1f03fe0af24a609fe2df0e26c0b8ef9ce4efbc6e5147a0866803c720a873b24289ed18",
    "8ec8df5c20c010a7f80a555acc998d51de2648eb05472e22bb3d5407b894bb4ed79055d72e096035de75887b41671e8f21ef3bdee73c5642e6110bf0e5cccec9"
    "223104364c46a9588482526cd206649443829bcfb8bb8c13c4b951454b24e0f3f69b3ee7237c4abe8a284182dde88457b9ae52db119a60979608f839fda29f60",
    "85f99125f59ebfa827ef2f44e849bebc7392de84e9acae327a8e2cc1a191da3ad8d235835c60a467d43d8f809c59ba45d63886cd5155d0190c1d9dfb31a3e636"
    "dbe77b047b77ff64ab3fbdbeb5a861e93dac5febc3d493f5537a8d90fbfafd0fe742f462013e8d73c24c1e64f7ebb5dab6998893623da9ee767da8113a513e40",
    "081ed6fd7f257717227c4ade1f1e8566c050b6da93bca39abba5083dc90f2c777da35b22bf35775f3eeeff73170c3e775387c7d4dc2be696c986bdacad25abb9"
    "042aa5463f773f010b49cf13", "" };

  c3_nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&c3_data[0], 3080U, &c3_nameCaptureInfo);
  return c3_nameCaptureInfo;
}

static void c3_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_nullptr, const char_T *c3_identifier,
   c3_SL_Bus_radar_msgs_RadarTracks *c3_y)
{
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fIdentifier = (const char_T *)c3_identifier;
  c3_thisId.fParent = NULL;
  c3_thisId.bParentIsCell = false;
  c3_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c3_nullptr), &c3_thisId, c3_y);
  sf_mex_destroy(&c3_nullptr);
}

static void c3_b_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId,
   c3_SL_Bus_radar_msgs_RadarTracks *c3_y)
{
  static const char_T *c3_fieldNames[2] = { "header", "tracks" };

  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fParent = c3_parentId;
  c3_thisId.bParentIsCell = false;
  sf_mex_check_struct(c3_parentId, c3_u, 2, &c3_fieldNames[0], 0U, NULL);
  c3_thisId.fIdentifier = "header";
  c3_c_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u, "header",
    "header", 0)), &c3_thisId, &c3_y->header);
  c3_thisId.fIdentifier = "tracks";
  c3_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u, "tracks",
    "tracks", 0)), &c3_thisId, c3_y->tracks);
  sf_mex_destroy(&c3_u);
}

static void c3_c_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId,
   c3_SL_Bus_std_msgs_Header *c3_y)
{
  static const char_T *c3_fieldNames[3] = { "stamp", "frame_id",
    "frame_id_SL_Info" };

  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fParent = c3_parentId;
  c3_thisId.bParentIsCell = false;
  sf_mex_check_struct(c3_parentId, c3_u, 3, &c3_fieldNames[0], 0U, NULL);
  c3_thisId.fIdentifier = "stamp";
  c3_y->stamp = c3_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield
    (c3_u, "stamp", "stamp", 0)), &c3_thisId);
  c3_thisId.fIdentifier = "frame_id";
  c3_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u,
    "frame_id", "frame_id", 0)), &c3_thisId, c3_y->frame_id);
  c3_thisId.fIdentifier = "frame_id_SL_Info";
  c3_y->frame_id_SL_Info = c3_h_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c3_u, "frame_id_SL_Info", "frame_id_SL_Info", 0)),
    &c3_thisId);
  sf_mex_destroy(&c3_u);
}

static c3_SL_Bus_builtin_interfaces_Time c3_d_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  static const char_T *c3_fieldNames[2] = { "sec", "nanosec" };

  c3_SL_Bus_builtin_interfaces_Time c3_y;
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fParent = c3_parentId;
  c3_thisId.bParentIsCell = false;
  sf_mex_check_struct(c3_parentId, c3_u, 2, &c3_fieldNames[0], 0U, NULL);
  c3_thisId.fIdentifier = "sec";
  c3_y.sec = c3_e_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield
    (c3_u, "sec", "sec", 0)), &c3_thisId);
  c3_thisId.fIdentifier = "nanosec";
  c3_y.nanosec = c3_f_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield
    (c3_u, "nanosec", "nanosec", 0)), &c3_thisId);
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static int32_T c3_e_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  int32_T c3_i;
  int32_T c3_y;
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), &c3_i, 1, 6, 0U, 0, 0U, 0);
  c3_y = c3_i;
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static uint32_T c3_f_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  uint32_T c3_b_u;
  uint32_T c3_y;
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), &c3_b_u, 1, 7, 0U, 0, 0U, 0);
  c3_y = c3_b_u;
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static void c3_g_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId, uint8_T c3_y[128])
{
  int32_T c3_i;
  uint8_T c3_uv[128];
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), c3_uv, 1, 3, 0U, 1, 0U, 1, 128);
  for (c3_i = 0; c3_i < 128; c3_i++) {
    c3_y[c3_i] = c3_uv[c3_i];
  }

  sf_mex_destroy(&c3_u);
}

static c3_SL_Bus_ROSVariableLengthArrayInfo c3_h_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  static const char_T *c3_fieldNames[2] = { "CurrentLength", "ReceivedLength" };

  c3_SL_Bus_ROSVariableLengthArrayInfo c3_y;
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fParent = c3_parentId;
  c3_thisId.bParentIsCell = false;
  sf_mex_check_struct(c3_parentId, c3_u, 2, &c3_fieldNames[0], 0U, NULL);
  c3_thisId.fIdentifier = "CurrentLength";
  c3_y.CurrentLength = c3_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c3_u, "CurrentLength", "CurrentLength", 0)), &c3_thisId);
  c3_thisId.fIdentifier = "ReceivedLength";
  c3_y.ReceivedLength = c3_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c3_u, "ReceivedLength", "ReceivedLength", 0)), &c3_thisId);
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static void c3_i_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId,
   c3_SL_Bus_radar_msgs_RadarTrack c3_y[30])
{
  static const char_T *c3_fieldNames[10] = { "uuid", "position", "velocity",
    "acceleration", "size", "classification", "position_covariance",
    "velocity_covariance", "acceleration_covariance", "size_covariance" };

  emlrtMsgIdentifier c3_thisId;
  int32_T c3_iv[1];
  int32_T c3_i;
  c3_iv[0] = 30;
  c3_thisId.fParent = c3_parentId;
  c3_thisId.bParentIsCell = false;
  sf_mex_check_struct(c3_parentId, c3_u, 10, &c3_fieldNames[0], 1U, c3_iv);
  for (c3_i = 0; c3_i < 30; c3_i++) {
    c3_thisId.fIdentifier = "uuid";
    c3_y[c3_i].uuid = c3_j_emlrt_marshallIn(chartInstance, sf_mex_dup
      (sf_mex_getfield(c3_u, "uuid", "uuid", c3_i)), &c3_thisId);
    c3_thisId.fIdentifier = "position";
    c3_y[c3_i].position = c3_l_emlrt_marshallIn(chartInstance, sf_mex_dup
      (sf_mex_getfield(c3_u, "position", "position", c3_i)), &c3_thisId);
    c3_thisId.fIdentifier = "velocity";
    c3_y[c3_i].velocity = c3_n_emlrt_marshallIn(chartInstance, sf_mex_dup
      (sf_mex_getfield(c3_u, "velocity", "velocity", c3_i)), &c3_thisId);
    c3_thisId.fIdentifier = "acceleration";
    c3_y[c3_i].acceleration = c3_n_emlrt_marshallIn(chartInstance, sf_mex_dup
      (sf_mex_getfield(c3_u, "acceleration", "acceleration", c3_i)), &c3_thisId);
    c3_thisId.fIdentifier = "size";
    c3_y[c3_i].size = c3_n_emlrt_marshallIn(chartInstance, sf_mex_dup
      (sf_mex_getfield(c3_u, "size", "size", c3_i)), &c3_thisId);
    c3_thisId.fIdentifier = "classification";
    c3_y[c3_i].classification = c3_o_emlrt_marshallIn(chartInstance, sf_mex_dup
      (sf_mex_getfield(c3_u, "classification", "classification", c3_i)),
      &c3_thisId);
    c3_thisId.fIdentifier = "position_covariance";
    c3_p_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u,
      "position_covariance", "position_covariance", c3_i)), &c3_thisId,
                          c3_y[c3_i].position_covariance);
    c3_thisId.fIdentifier = "velocity_covariance";
    c3_p_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u,
      "velocity_covariance", "velocity_covariance", c3_i)), &c3_thisId,
                          c3_y[c3_i].velocity_covariance);
    c3_thisId.fIdentifier = "acceleration_covariance";
    c3_p_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u,
      "acceleration_covariance", "acceleration_covariance", c3_i)), &c3_thisId,
                          c3_y[c3_i].acceleration_covariance);
    c3_thisId.fIdentifier = "size_covariance";
    c3_p_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u,
      "size_covariance", "size_covariance", c3_i)), &c3_thisId, c3_y[c3_i].
                          size_covariance);
  }

  sf_mex_destroy(&c3_u);
}

static c3_SL_Bus_unique_identifier_msgs_UUID c3_j_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  static const char_T *c3_fieldNames[1] = { "uuid" };

  c3_SL_Bus_unique_identifier_msgs_UUID c3_y;
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fParent = c3_parentId;
  c3_thisId.bParentIsCell = false;
  sf_mex_check_struct(c3_parentId, c3_u, 1, &c3_fieldNames[0], 0U, NULL);
  c3_thisId.fIdentifier = "uuid";
  c3_k_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u, "uuid",
    "uuid", 0)), &c3_thisId, c3_y.uuid);
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static void c3_k_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId, uint8_T c3_y[16])
{
  int32_T c3_i;
  uint8_T c3_uv[16];
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), c3_uv, 1, 3, 0U, 1, 0U, 1, 16);
  for (c3_i = 0; c3_i < 16; c3_i++) {
    c3_y[c3_i] = c3_uv[c3_i];
  }

  sf_mex_destroy(&c3_u);
}

static c3_SL_Bus_geometry_msgs_Point c3_l_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  c3_SL_Bus_geometry_msgs_Point c3_y;
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fParent = c3_parentId;
  c3_thisId.bParentIsCell = false;
  sf_mex_check_struct(c3_parentId, c3_u, 3, &c3_sv[0], 0U, NULL);
  c3_thisId.fIdentifier = "x";
  c3_y.x = c3_m_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u,
    "x", "x", 0)), &c3_thisId);
  c3_thisId.fIdentifier = "y";
  c3_y.y = c3_m_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u,
    "y", "y", 0)), &c3_thisId);
  c3_thisId.fIdentifier = "z";
  c3_y.z = c3_m_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u,
    "z", "z", 0)), &c3_thisId);
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static real_T c3_m_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  real_T c3_d;
  real_T c3_y;
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), &c3_d, 1, 0, 0U, 0, 0U, 0);
  c3_y = c3_d;
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static c3_SL_Bus_geometry_msgs_Vector3 c3_n_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  c3_SL_Bus_geometry_msgs_Vector3 c3_y;
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fParent = c3_parentId;
  c3_thisId.bParentIsCell = false;
  sf_mex_check_struct(c3_parentId, c3_u, 3, &c3_sv[0], 0U, NULL);
  c3_thisId.fIdentifier = "x";
  c3_y.x = c3_m_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u,
    "x", "x", 0)), &c3_thisId);
  c3_thisId.fIdentifier = "y";
  c3_y.y = c3_m_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u,
    "y", "y", 0)), &c3_thisId);
  c3_thisId.fIdentifier = "z";
  c3_y.z = c3_m_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c3_u,
    "z", "z", 0)), &c3_thisId);
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static uint16_T c3_o_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  uint16_T c3_b_u;
  uint16_T c3_y;
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), &c3_b_u, 1, 5, 0U, 0, 0U, 0);
  c3_y = c3_b_u;
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static void c3_p_emlrt_marshallIn
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, const
   mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId, real32_T c3_y[6])
{
  int32_T c3_i;
  real32_T c3_fv[6];
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), c3_fv, 0, 1, 0U, 1, 0U, 1, 6);
  for (c3_i = 0; c3_i < 6; c3_i++) {
    c3_y[c3_i] = c3_fv[c3_i];
  }

  sf_mex_destroy(&c3_u);
}

static void c3_chart_data_browse_helper
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance, int32_T
   c3_ssIdNumber, const mxArray **c3_mxData, uint8_T *c3_isValueTooBig)
{
  c3_SL_Bus_radar_msgs_RadarTrack *c3_r2;
  c3_SL_Bus_radar_msgs_RadarTrack *c3_r3;
  c3_SL_Bus_radar_msgs_RadarTracks c3_r;
  c3_SL_Bus_radar_msgs_RadarTracks c3_r1;
  const mxArray *c3_m = NULL;
  const mxArray *c3_m1 = NULL;
  const mxArray *c3_m10 = NULL;
  const mxArray *c3_m11 = NULL;
  const mxArray *c3_m12 = NULL;
  const mxArray *c3_m13 = NULL;
  const mxArray *c3_m14 = NULL;
  const mxArray *c3_m15 = NULL;
  const mxArray *c3_m16 = NULL;
  const mxArray *c3_m17 = NULL;
  const mxArray *c3_m18 = NULL;
  const mxArray *c3_m19 = NULL;
  const mxArray *c3_m2 = NULL;
  const mxArray *c3_m3 = NULL;
  const mxArray *c3_m4 = NULL;
  const mxArray *c3_m5 = NULL;
  const mxArray *c3_m6 = NULL;
  const mxArray *c3_m7 = NULL;
  const mxArray *c3_m8 = NULL;
  const mxArray *c3_m9 = NULL;
  int32_T c3_i;
  int32_T c3_i1;
  int32_T c3_i10;
  int32_T c3_i11;
  int32_T c3_i12;
  int32_T c3_i13;
  int32_T c3_i14;
  int32_T c3_i15;
  int32_T c3_i2;
  int32_T c3_i3;
  int32_T c3_i4;
  int32_T c3_i5;
  int32_T c3_i6;
  int32_T c3_i7;
  int32_T c3_i8;
  int32_T c3_i9;
  *c3_mxData = NULL;
  *c3_mxData = NULL;
  *c3_isValueTooBig = 0U;
  switch (c3_ssIdNumber) {
   case 4U:
    c3_r.header.stamp.sec = *(int32_T *)&((char_T *)
      (c3_SL_Bus_builtin_interfaces_Time *)&((char_T *)
      (c3_SL_Bus_std_msgs_Header *)&((char_T *)
      chartInstance->c3_emptyTracksMessage)[0])[0])[0];
    c3_r.header.stamp.nanosec = *(uint32_T *)&((char_T *)
      (c3_SL_Bus_builtin_interfaces_Time *)&((char_T *)
      (c3_SL_Bus_std_msgs_Header *)&((char_T *)
      chartInstance->c3_emptyTracksMessage)[0])[0])[4];
    for (c3_i = 0; c3_i < 128; c3_i++) {
      c3_r.header.frame_id[c3_i] = (*(uint8_T (*)[128])&((char_T *)
        (c3_SL_Bus_std_msgs_Header *)&((char_T *)
        chartInstance->c3_emptyTracksMessage)[0])[8])[c3_i];
    }

    c3_r.header.frame_id_SL_Info.CurrentLength = *(uint32_T *)&((char_T *)
      (c3_SL_Bus_ROSVariableLengthArrayInfo *)&((char_T *)
      (c3_SL_Bus_std_msgs_Header *)&((char_T *)
      chartInstance->c3_emptyTracksMessage)[0])[136])[0];
    c3_r.header.frame_id_SL_Info.ReceivedLength = *(uint32_T *)&((char_T *)
      (c3_SL_Bus_ROSVariableLengthArrayInfo *)&((char_T *)
      (c3_SL_Bus_std_msgs_Header *)&((char_T *)
      chartInstance->c3_emptyTracksMessage)[0])[136])[4];
    for (c3_i2 = 0; c3_i2 < 30; c3_i2++) {
      for (c3_i4 = 0; c3_i4 < 16; c3_i4++) {
        c3_r.tracks[c3_i2].uuid.uuid[c3_i4] = (*(uint8_T (*)[16])&((char_T *)
          (c3_SL_Bus_unique_identifier_msgs_UUID *)&((char_T *)
          (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
          (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
          chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[0])
          [0])[c3_i4];
      }

      c3_r.tracks[c3_i2].position.x = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[16])
        [0];
      c3_r.tracks[c3_i2].position.y = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[16])
        [8];
      c3_r.tracks[c3_i2].position.z = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[16])
        [16];
      c3_r.tracks[c3_i2].velocity.x = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[40])
        [0];
      c3_r.tracks[c3_i2].velocity.y = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[40])
        [8];
      c3_r.tracks[c3_i2].velocity.z = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[40])
        [16];
      c3_r.tracks[c3_i2].acceleration.x = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[64])
        [0];
      c3_r.tracks[c3_i2].acceleration.y = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[64])
        [8];
      c3_r.tracks[c3_i2].acceleration.z = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[64])
        [16];
      c3_r.tracks[c3_i2].size.x = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[88])
        [0];
      c3_r.tracks[c3_i2].size.y = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[88])
        [8];
      c3_r.tracks[c3_i2].size.z = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[88])
        [16];
      c3_r.tracks[c3_i2].classification = *(uint16_T *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[112];
      for (c3_i6 = 0; c3_i6 < 6; c3_i6++) {
        c3_r.tracks[c3_i2].position_covariance[c3_i6] = (*(real32_T (*)[6])&
          ((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
          (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
          chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[116])
          [c3_i6];
      }

      for (c3_i8 = 0; c3_i8 < 6; c3_i8++) {
        c3_r.tracks[c3_i2].velocity_covariance[c3_i8] = (*(real32_T (*)[6])&
          ((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
          (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
          chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[140])
          [c3_i8];
      }

      for (c3_i10 = 0; c3_i10 < 6; c3_i10++) {
        c3_r.tracks[c3_i2].acceleration_covariance[c3_i10] = (*(real32_T (*)[6])
          &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
          (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
          chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[164])
          [c3_i10];
      }

      for (c3_i13 = 0; c3_i13 < 6; c3_i13++) {
        c3_r.tracks[c3_i2].size_covariance[c3_i13] = (*(real32_T (*)[6])&
          ((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
          (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
          chartInstance->c3_emptyTracksMessage)[144])[216 * (int32_T)c3_i2])[188])
          [c3_i13];
      }
    }

    c3_m8 = NULL;
    sf_mex_assign(&c3_m8, sf_mex_createstruct("mxData", 0, NULL, 0), false);
    c3_m = NULL;
    sf_mex_assign(&c3_m, sf_mex_createstruct("mxData", 0, NULL, 0), false);
    c3_m1 = NULL;
    sf_mex_assign(&c3_m1, sf_mex_createstruct("mxData", 0, NULL, 0), false);
    sf_mex_addfield(c3_m1, sf_mex_create("mxData", &c3_r.header.stamp.sec, 6, 0U,
      0, 0U, 0), "sec", "mxData", 0);
    sf_mex_addfield(c3_m1, sf_mex_create("mxData", &c3_r.header.stamp.nanosec, 7,
      0U, 0, 0U, 0), "nanosec", "mxData", 0);
    sf_mex_addfield(c3_m, sf_mex_dup(c3_m1), "stamp", "mxData", 0);
    sf_mex_destroy(&c3_m1);
    sf_mex_addfield(c3_m, sf_mex_create("mxData", c3_r.header.frame_id, 3, 0U, 1,
      0U, 1, 128), "frame_id", "mxData", 0);
    c3_m2 = NULL;
    sf_mex_assign(&c3_m2, sf_mex_createstruct("mxData", 0, NULL, 0), false);
    sf_mex_addfield(c3_m2, sf_mex_create("mxData",
      &c3_r.header.frame_id_SL_Info.CurrentLength, 7, 0U, 0, 0U, 0),
                    "CurrentLength", "mxData", 0);
    sf_mex_addfield(c3_m2, sf_mex_create("mxData",
      &c3_r.header.frame_id_SL_Info.ReceivedLength, 7, 0U, 0, 0U, 0),
                    "ReceivedLength", "mxData", 0);
    sf_mex_addfield(c3_m, sf_mex_dup(c3_m2), "frame_id_SL_Info", "mxData", 0);
    sf_mex_destroy(&c3_m2);
    sf_mex_addfield(c3_m8, sf_mex_dup(c3_m), "header", "mxData", 0);
    sf_mex_destroy(&c3_m);
    c3_m3 = NULL;
    sf_mex_assign(&c3_m3, sf_mex_createstruct("mxData", 0, NULL, 1, 30), false);
    for (c3_i12 = 0; c3_i12 < 30; c3_i12++) {
      c3_r2 = &c3_r.tracks[c3_i12];
      c3_m4 = NULL;
      sf_mex_assign(&c3_m4, sf_mex_createstruct("mxData", 0, NULL, 0), false);
      sf_mex_addfield(c3_m4, sf_mex_create("mxData", c3_r2->uuid.uuid, 3, 0U, 1,
        0U, 1, 16), "uuid", "mxData", 0);
      sf_mex_addfield(c3_m3, sf_mex_dup(c3_m4), "uuid", "mxData", c3_i12);
      sf_mex_destroy(&c3_m4);
      c3_m5 = NULL;
      sf_mex_assign(&c3_m5, sf_mex_createstruct("mxData", 0, NULL, 0), false);
      sf_mex_addfield(c3_m5, sf_mex_create("mxData", &c3_r2->position.x, 0, 0U,
        0, 0U, 0), "x", "mxData", 0);
      sf_mex_addfield(c3_m5, sf_mex_create("mxData", &c3_r2->position.y, 0, 0U,
        0, 0U, 0), "y", "mxData", 0);
      sf_mex_addfield(c3_m5, sf_mex_create("mxData", &c3_r2->position.z, 0, 0U,
        0, 0U, 0), "z", "mxData", 0);
      sf_mex_addfield(c3_m3, sf_mex_dup(c3_m5), "position", "mxData", c3_i12);
      sf_mex_destroy(&c3_m5);
      c3_m6 = NULL;
      sf_mex_assign(&c3_m6, sf_mex_createstruct("mxData", 0, NULL, 0), false);
      sf_mex_addfield(c3_m6, sf_mex_create("mxData", &c3_r2->velocity.x, 0, 0U,
        0, 0U, 0), "x", "mxData", 0);
      sf_mex_addfield(c3_m6, sf_mex_create("mxData", &c3_r2->velocity.y, 0, 0U,
        0, 0U, 0), "y", "mxData", 0);
      sf_mex_addfield(c3_m6, sf_mex_create("mxData", &c3_r2->velocity.z, 0, 0U,
        0, 0U, 0), "z", "mxData", 0);
      sf_mex_addfield(c3_m3, sf_mex_dup(c3_m6), "velocity", "mxData", c3_i12);
      sf_mex_destroy(&c3_m6);
      c3_m7 = NULL;
      sf_mex_assign(&c3_m7, sf_mex_createstruct("mxData", 0, NULL, 0), false);
      sf_mex_addfield(c3_m7, sf_mex_create("mxData", &c3_r2->acceleration.x, 0,
        0U, 0, 0U, 0), "x", "mxData", 0);
      sf_mex_addfield(c3_m7, sf_mex_create("mxData", &c3_r2->acceleration.y, 0,
        0U, 0, 0U, 0), "y", "mxData", 0);
      sf_mex_addfield(c3_m7, sf_mex_create("mxData", &c3_r2->acceleration.z, 0,
        0U, 0, 0U, 0), "z", "mxData", 0);
      sf_mex_addfield(c3_m3, sf_mex_dup(c3_m7), "acceleration", "mxData", c3_i12);
      sf_mex_destroy(&c3_m7);
      c3_m10 = NULL;
      sf_mex_assign(&c3_m10, sf_mex_createstruct("mxData", 0, NULL, 0), false);
      sf_mex_addfield(c3_m10, sf_mex_create("mxData", &c3_r2->size.x, 0, 0U, 0,
        0U, 0), "x", "mxData", 0);
      sf_mex_addfield(c3_m10, sf_mex_create("mxData", &c3_r2->size.y, 0, 0U, 0,
        0U, 0), "y", "mxData", 0);
      sf_mex_addfield(c3_m10, sf_mex_create("mxData", &c3_r2->size.z, 0, 0U, 0,
        0U, 0), "z", "mxData", 0);
      sf_mex_addfield(c3_m3, sf_mex_dup(c3_m10), "size", "mxData", c3_i12);
      sf_mex_destroy(&c3_m10);
      sf_mex_addfield(c3_m3, sf_mex_create("mxData", &c3_r2->classification, 5,
        0U, 0, 0U, 0), "classification", "mxData", c3_i12);
      sf_mex_addfield(c3_m3, sf_mex_create("mxData", c3_r2->position_covariance,
        1, 0U, 1, 0U, 1, 6), "position_covariance", "mxData", c3_i12);
      sf_mex_addfield(c3_m3, sf_mex_create("mxData", c3_r2->velocity_covariance,
        1, 0U, 1, 0U, 1, 6), "velocity_covariance", "mxData", c3_i12);
      sf_mex_addfield(c3_m3, sf_mex_create("mxData",
        c3_r2->acceleration_covariance, 1, 0U, 1, 0U, 1, 6),
                      "acceleration_covariance", "mxData", c3_i12);
      sf_mex_addfield(c3_m3, sf_mex_create("mxData", c3_r2->size_covariance, 1,
        0U, 1, 0U, 1, 6), "size_covariance", "mxData", c3_i12);
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    sf_mex_addfield(c3_m8, sf_mex_dup(c3_m3), "tracks", "mxData", 0);
    sf_mex_destroy(&c3_m3);
    sf_mex_assign(c3_mxData, c3_m8, false);
    break;

   case 5U:
    c3_r1.header.stamp.sec = *(int32_T *)&((char_T *)
      (c3_SL_Bus_builtin_interfaces_Time *)&((char_T *)
      (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[0])[0];
    c3_r1.header.stamp.nanosec = *(uint32_T *)&((char_T *)
      (c3_SL_Bus_builtin_interfaces_Time *)&((char_T *)
      (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[0])[4];
    for (c3_i1 = 0; c3_i1 < 128; c3_i1++) {
      c3_r1.header.frame_id[c3_i1] = (*(uint8_T (*)[128])&((char_T *)
        (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[8])
        [c3_i1];
    }

    c3_r1.header.frame_id_SL_Info.CurrentLength = *(uint32_T *)&((char_T *)
      (c3_SL_Bus_ROSVariableLengthArrayInfo *)&((char_T *)
      (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[136])
      [0];
    c3_r1.header.frame_id_SL_Info.ReceivedLength = *(uint32_T *)&((char_T *)
      (c3_SL_Bus_ROSVariableLengthArrayInfo *)&((char_T *)
      (c3_SL_Bus_std_msgs_Header *)&((char_T *)chartInstance->c3_msg)[0])[136])
      [4];
    for (c3_i3 = 0; c3_i3 < 30; c3_i3++) {
      for (c3_i5 = 0; c3_i5 < 16; c3_i5++) {
        c3_r1.tracks[c3_i3].uuid.uuid[c3_i5] = (*(uint8_T (*)[16])&((char_T *)
          (c3_SL_Bus_unique_identifier_msgs_UUID *)&((char_T *)
          (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
          (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
          chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[0])[0])[c3_i5];
      }

      c3_r1.tracks[c3_i3].position.x = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[16])[0];
      c3_r1.tracks[c3_i3].position.y = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[16])[8];
      c3_r1.tracks[c3_i3].position.z = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Point *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[16])[16];
      c3_r1.tracks[c3_i3].velocity.x = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[40])[0];
      c3_r1.tracks[c3_i3].velocity.y = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[40])[8];
      c3_r1.tracks[c3_i3].velocity.z = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[40])[16];
      c3_r1.tracks[c3_i3].acceleration.x = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[64])[0];
      c3_r1.tracks[c3_i3].acceleration.y = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[64])[8];
      c3_r1.tracks[c3_i3].acceleration.z = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[64])[16];
      c3_r1.tracks[c3_i3].size.x = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[88])[0];
      c3_r1.tracks[c3_i3].size.y = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[88])[8];
      c3_r1.tracks[c3_i3].size.z = *(real_T *)&((char_T *)
        (c3_SL_Bus_geometry_msgs_Vector3 *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[88])[16];
      c3_r1.tracks[c3_i3].classification = *(uint16_T *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
        (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
        chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[112];
      for (c3_i7 = 0; c3_i7 < 6; c3_i7++) {
        c3_r1.tracks[c3_i3].position_covariance[c3_i7] = (*(real32_T (*)[6])&
          ((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
          (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
          chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[116])[c3_i7];
      }

      for (c3_i9 = 0; c3_i9 < 6; c3_i9++) {
        c3_r1.tracks[c3_i3].velocity_covariance[c3_i9] = (*(real32_T (*)[6])&
          ((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
          (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
          chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[140])[c3_i9];
      }

      for (c3_i11 = 0; c3_i11 < 6; c3_i11++) {
        c3_r1.tracks[c3_i3].acceleration_covariance[c3_i11] = (*(real32_T (*)[6])
          &((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
          (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
          chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[164])[c3_i11];
      }

      for (c3_i15 = 0; c3_i15 < 6; c3_i15++) {
        c3_r1.tracks[c3_i3].size_covariance[c3_i15] = (*(real32_T (*)[6])&
          ((char_T *)(c3_SL_Bus_radar_msgs_RadarTrack *)&((char_T *)
          (c3_SL_Bus_radar_msgs_RadarTrack (*)[30])&((char_T *)
          chartInstance->c3_msg)[144])[216 * (int32_T)c3_i3])[188])[c3_i15];
      }
    }

    c3_m9 = NULL;
    sf_mex_assign(&c3_m9, sf_mex_createstruct("mxData", 0, NULL, 0), false);
    c3_m11 = NULL;
    sf_mex_assign(&c3_m11, sf_mex_createstruct("mxData", 0, NULL, 0), false);
    c3_m12 = NULL;
    sf_mex_assign(&c3_m12, sf_mex_createstruct("mxData", 0, NULL, 0), false);
    sf_mex_addfield(c3_m12, sf_mex_create("mxData", &c3_r1.header.stamp.sec, 6,
      0U, 0, 0U, 0), "sec", "mxData", 0);
    sf_mex_addfield(c3_m12, sf_mex_create("mxData", &c3_r1.header.stamp.nanosec,
      7, 0U, 0, 0U, 0), "nanosec", "mxData", 0);
    sf_mex_addfield(c3_m11, sf_mex_dup(c3_m12), "stamp", "mxData", 0);
    sf_mex_destroy(&c3_m12);
    sf_mex_addfield(c3_m11, sf_mex_create("mxData", c3_r1.header.frame_id, 3, 0U,
      1, 0U, 1, 128), "frame_id", "mxData", 0);
    c3_m13 = NULL;
    sf_mex_assign(&c3_m13, sf_mex_createstruct("mxData", 0, NULL, 0), false);
    sf_mex_addfield(c3_m13, sf_mex_create("mxData",
      &c3_r1.header.frame_id_SL_Info.CurrentLength, 7, 0U, 0, 0U, 0),
                    "CurrentLength", "mxData", 0);
    sf_mex_addfield(c3_m13, sf_mex_create("mxData",
      &c3_r1.header.frame_id_SL_Info.ReceivedLength, 7, 0U, 0, 0U, 0),
                    "ReceivedLength", "mxData", 0);
    sf_mex_addfield(c3_m11, sf_mex_dup(c3_m13), "frame_id_SL_Info", "mxData", 0);
    sf_mex_destroy(&c3_m13);
    sf_mex_addfield(c3_m9, sf_mex_dup(c3_m11), "header", "mxData", 0);
    sf_mex_destroy(&c3_m11);
    c3_m14 = NULL;
    sf_mex_assign(&c3_m14, sf_mex_createstruct("mxData", 0, NULL, 1, 30), false);
    for (c3_i14 = 0; c3_i14 < 30; c3_i14++) {
      c3_r3 = &c3_r1.tracks[c3_i14];
      c3_m15 = NULL;
      sf_mex_assign(&c3_m15, sf_mex_createstruct("mxData", 0, NULL, 0), false);
      sf_mex_addfield(c3_m15, sf_mex_create("mxData", c3_r3->uuid.uuid, 3, 0U, 1,
        0U, 1, 16), "uuid", "mxData", 0);
      sf_mex_addfield(c3_m14, sf_mex_dup(c3_m15), "uuid", "mxData", c3_i14);
      sf_mex_destroy(&c3_m15);
      c3_m16 = NULL;
      sf_mex_assign(&c3_m16, sf_mex_createstruct("mxData", 0, NULL, 0), false);
      sf_mex_addfield(c3_m16, sf_mex_create("mxData", &c3_r3->position.x, 0, 0U,
        0, 0U, 0), "x", "mxData", 0);
      sf_mex_addfield(c3_m16, sf_mex_create("mxData", &c3_r3->position.y, 0, 0U,
        0, 0U, 0), "y", "mxData", 0);
      sf_mex_addfield(c3_m16, sf_mex_create("mxData", &c3_r3->position.z, 0, 0U,
        0, 0U, 0), "z", "mxData", 0);
      sf_mex_addfield(c3_m14, sf_mex_dup(c3_m16), "position", "mxData", c3_i14);
      sf_mex_destroy(&c3_m16);
      c3_m17 = NULL;
      sf_mex_assign(&c3_m17, sf_mex_createstruct("mxData", 0, NULL, 0), false);
      sf_mex_addfield(c3_m17, sf_mex_create("mxData", &c3_r3->velocity.x, 0, 0U,
        0, 0U, 0), "x", "mxData", 0);
      sf_mex_addfield(c3_m17, sf_mex_create("mxData", &c3_r3->velocity.y, 0, 0U,
        0, 0U, 0), "y", "mxData", 0);
      sf_mex_addfield(c3_m17, sf_mex_create("mxData", &c3_r3->velocity.z, 0, 0U,
        0, 0U, 0), "z", "mxData", 0);
      sf_mex_addfield(c3_m14, sf_mex_dup(c3_m17), "velocity", "mxData", c3_i14);
      sf_mex_destroy(&c3_m17);
      c3_m18 = NULL;
      sf_mex_assign(&c3_m18, sf_mex_createstruct("mxData", 0, NULL, 0), false);
      sf_mex_addfield(c3_m18, sf_mex_create("mxData", &c3_r3->acceleration.x, 0,
        0U, 0, 0U, 0), "x", "mxData", 0);
      sf_mex_addfield(c3_m18, sf_mex_create("mxData", &c3_r3->acceleration.y, 0,
        0U, 0, 0U, 0), "y", "mxData", 0);
      sf_mex_addfield(c3_m18, sf_mex_create("mxData", &c3_r3->acceleration.z, 0,
        0U, 0, 0U, 0), "z", "mxData", 0);
      sf_mex_addfield(c3_m14, sf_mex_dup(c3_m18), "acceleration", "mxData",
                      c3_i14);
      sf_mex_destroy(&c3_m18);
      c3_m19 = NULL;
      sf_mex_assign(&c3_m19, sf_mex_createstruct("mxData", 0, NULL, 0), false);
      sf_mex_addfield(c3_m19, sf_mex_create("mxData", &c3_r3->size.x, 0, 0U, 0,
        0U, 0), "x", "mxData", 0);
      sf_mex_addfield(c3_m19, sf_mex_create("mxData", &c3_r3->size.y, 0, 0U, 0,
        0U, 0), "y", "mxData", 0);
      sf_mex_addfield(c3_m19, sf_mex_create("mxData", &c3_r3->size.z, 0, 0U, 0,
        0U, 0), "z", "mxData", 0);
      sf_mex_addfield(c3_m14, sf_mex_dup(c3_m19), "size", "mxData", c3_i14);
      sf_mex_destroy(&c3_m19);
      sf_mex_addfield(c3_m14, sf_mex_create("mxData", &c3_r3->classification, 5,
        0U, 0, 0U, 0), "classification", "mxData", c3_i14);
      sf_mex_addfield(c3_m14, sf_mex_create("mxData", c3_r3->position_covariance,
        1, 0U, 1, 0U, 1, 6), "position_covariance", "mxData", c3_i14);
      sf_mex_addfield(c3_m14, sf_mex_create("mxData", c3_r3->velocity_covariance,
        1, 0U, 1, 0U, 1, 6), "velocity_covariance", "mxData", c3_i14);
      sf_mex_addfield(c3_m14, sf_mex_create("mxData",
        c3_r3->acceleration_covariance, 1, 0U, 1, 0U, 1, 6),
                      "acceleration_covariance", "mxData", c3_i14);
      sf_mex_addfield(c3_m14, sf_mex_create("mxData", c3_r3->size_covariance, 1,
        0U, 1, 0U, 1, 6), "size_covariance", "mxData", c3_i14);
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    sf_mex_addfield(c3_m9, sf_mex_dup(c3_m14), "tracks", "mxData", 0);
    sf_mex_destroy(&c3_m14);
    sf_mex_assign(c3_mxData, c3_m9, false);
    break;

   case 6U:
    sf_mex_assign(c3_mxData, sf_mex_create("mxData",
      *chartInstance->c3_positionArray, 0, 0U, 1, 0U, 2, 30, 3), false);
    break;

   case 7U:
    sf_mex_assign(c3_mxData, sf_mex_create("mxData",
      *chartInstance->c3_velocityArray, 0, 0U, 1, 0U, 2, 30, 3), false);
    break;

   case 8U:
    sf_mex_assign(c3_mxData, sf_mex_create("mxData",
      *chartInstance->c3_accelerationArray, 0, 0U, 1, 0U, 2, 30, 3), false);
    break;

   case 9U:
    sf_mex_assign(c3_mxData, sf_mex_create("mxData",
      *chartInstance->c3_sizeArray, 0, 0U, 1, 0U, 2, 30, 3), false);
    break;

   case 10U:
    sf_mex_assign(c3_mxData, sf_mex_create("mxData",
      *chartInstance->c3_classificationArray, 5, 0U, 1, 0U, 2, 30, 1), false);
    break;

   case 11U:
    sf_mex_assign(c3_mxData, sf_mex_create("mxData",
      *chartInstance->c3_positionCovariance, 1, 0U, 1, 0U, 2, 30, 6), false);
    break;

   case 12U:
    sf_mex_assign(c3_mxData, sf_mex_create("mxData",
      *chartInstance->c3_velocityCovariance, 1, 0U, 1, 0U, 2, 30, 6), false);
    break;

   case 13U:
    sf_mex_assign(c3_mxData, sf_mex_create("mxData",
      *chartInstance->c3_accelerationCovariance, 1, 0U, 1, 0U, 2, 30, 6), false);
    break;

   case 14U:
    sf_mex_assign(c3_mxData, sf_mex_create("mxData",
      *chartInstance->c3_sizeCovariance, 1, 0U, 1, 0U, 2, 30, 6), false);
    break;
  }

  sf_mex_destroy(&c3_m);
  sf_mex_destroy(&c3_m1);
  sf_mex_destroy(&c3_m2);
  sf_mex_destroy(&c3_m3);
  sf_mex_destroy(&c3_m4);
  sf_mex_destroy(&c3_m5);
  sf_mex_destroy(&c3_m6);
  sf_mex_destroy(&c3_m7);
  sf_mex_destroy(&c3_m10);
  sf_mex_destroy(&c3_m11);
  sf_mex_destroy(&c3_m12);
  sf_mex_destroy(&c3_m13);
  sf_mex_destroy(&c3_m14);
  sf_mex_destroy(&c3_m15);
  sf_mex_destroy(&c3_m16);
  sf_mex_destroy(&c3_m17);
  sf_mex_destroy(&c3_m18);
  sf_mex_destroy(&c3_m19);
}

static void init_dsm_address_info
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address
  (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance)
{
  chartInstance->c3_covrtInstance = (CovrtStateflowInstance *)
    sfrtGetCovrtInstance(chartInstance->S);
  chartInstance->c3_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c3_emptyTracksMessage = (c3_SL_Bus_radar_msgs_RadarTracks *)
    ssGetInputPortSignal_wrapper(chartInstance->S, 0);
  chartInstance->c3_msg = (c3_SL_Bus_radar_msgs_RadarTracks *)
    ssGetOutputPortSignal_wrapper(chartInstance->S, 1);
  chartInstance->c3_positionArray = (real_T (*)[90])ssGetInputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c3_velocityArray = (real_T (*)[90])ssGetInputPortSignal_wrapper
    (chartInstance->S, 2);
  chartInstance->c3_accelerationArray = (real_T (*)[90])
    ssGetInputPortSignal_wrapper(chartInstance->S, 3);
  chartInstance->c3_sizeArray = (real_T (*)[90])ssGetInputPortSignal_wrapper
    (chartInstance->S, 4);
  chartInstance->c3_classificationArray = (uint16_T (*)[30])
    ssGetInputPortSignal_wrapper(chartInstance->S, 5);
  chartInstance->c3_positionCovariance = (real32_T (*)[180])
    ssGetInputPortSignal_wrapper(chartInstance->S, 6);
  chartInstance->c3_velocityCovariance = (real32_T (*)[180])
    ssGetInputPortSignal_wrapper(chartInstance->S, 7);
  chartInstance->c3_accelerationCovariance = (real32_T (*)[180])
    ssGetInputPortSignal_wrapper(chartInstance->S, 8);
  chartInstance->c3_sizeCovariance = (real32_T (*)[180])
    ssGetInputPortSignal_wrapper(chartInstance->S, 9);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* SFunction Glue Code */
void sf_c3_generic_updated_aBAJA2025_Version1_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1879670299U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(132668054U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3953801007U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(4042127315U);
}

mxArray *sf_c3_generic_updated_aBAJA2025_Version1_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c3_generic_updated_aBAJA2025_Version1_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("late");
  mxArray *fallbackReason = mxCreateString("ir_function_calls");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("//");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c3_generic_updated_aBAJA2025_Version1_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

static const mxArray
  *sf_get_sim_state_info_c3_generic_updated_aBAJA2025_Version1(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  mxArray *mxVarInfo = sf_mex_decode(
    "eNpjYPT0ZQACPiCWYGRgYAPSHEDMxAABrFA+IxKGiLPAxRWAuKSyIBUkXlyU7JkCpPMSc8H8xNI"
    "Kz7y0fLD5FgwI89kImM8JFYeAD/aU6RdxAOk3QNLPgkU/M5J+ASAvtzgd7G4QAAA1Bw2G"
    );
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c3_generic_updated_aBAJA2025_Version1_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const char* sf_get_instance_specialization(void)
{
  return "sYSnueXY2FkgrTjcPOtx7pD";
}

static void sf_opaque_initialize_c3_generic_updated_aBAJA2025_Version1(void
  *chartInstanceVar)
{
  initialize_params_c3_generic_updated_aBAJA2025_Version1
    ((SFc3_generic_updated_aBAJA2025_Version1InstanceStruct*) chartInstanceVar);
  initialize_c3_generic_updated_aBAJA2025_Version1
    ((SFc3_generic_updated_aBAJA2025_Version1InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c3_generic_updated_aBAJA2025_Version1(void
  *chartInstanceVar)
{
  enable_c3_generic_updated_aBAJA2025_Version1
    ((SFc3_generic_updated_aBAJA2025_Version1InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c3_generic_updated_aBAJA2025_Version1(void
  *chartInstanceVar)
{
  disable_c3_generic_updated_aBAJA2025_Version1
    ((SFc3_generic_updated_aBAJA2025_Version1InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c3_generic_updated_aBAJA2025_Version1(void
  *chartInstanceVar)
{
  sf_gateway_c3_generic_updated_aBAJA2025_Version1
    ((SFc3_generic_updated_aBAJA2025_Version1InstanceStruct*) chartInstanceVar);
}

static const mxArray*
  sf_opaque_get_sim_state_c3_generic_updated_aBAJA2025_Version1(SimStruct* S)
{
  return get_sim_state_c3_generic_updated_aBAJA2025_Version1
    ((SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *)
     sf_get_chart_instance_ptr(S));    /* raw sim ctx */
}

static void sf_opaque_set_sim_state_c3_generic_updated_aBAJA2025_Version1
  (SimStruct* S, const mxArray *st)
{
  set_sim_state_c3_generic_updated_aBAJA2025_Version1
    ((SFc3_generic_updated_aBAJA2025_Version1InstanceStruct*)
     sf_get_chart_instance_ptr(S), st);
}

static void
  sf_opaque_cleanup_runtime_resources_c3_generic_updated_aBAJA2025_Version1(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc3_generic_updated_aBAJA2025_Version1InstanceStruct*)
                    chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_generic_updated_aBAJA2025_Version1_optimization_info();
    }

    mdl_cleanup_runtime_resources_c3_generic_updated_aBAJA2025_Version1
      ((SFc3_generic_updated_aBAJA2025_Version1InstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_mdl_start_c3_generic_updated_aBAJA2025_Version1(void
  *chartInstanceVar)
{
  mdl_start_c3_generic_updated_aBAJA2025_Version1
    ((SFc3_generic_updated_aBAJA2025_Version1InstanceStruct*) chartInstanceVar);
  if (chartInstanceVar) {
    sf_reset_warnings_ChartRunTimeInfo
      (((SFc3_generic_updated_aBAJA2025_Version1InstanceStruct*)chartInstanceVar)
       ->S);
  }
}

static void sf_opaque_mdl_terminate_c3_generic_updated_aBAJA2025_Version1(void
  *chartInstanceVar)
{
  mdl_terminate_c3_generic_updated_aBAJA2025_Version1
    ((SFc3_generic_updated_aBAJA2025_Version1InstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c3_generic_updated_aBAJA2025_Version1(SimStruct
  *S)
{
  mdlProcessParamsCommon(S);
  if (sf_machine_global_initializer_called()) {
    initialize_params_c3_generic_updated_aBAJA2025_Version1
      ((SFc3_generic_updated_aBAJA2025_Version1InstanceStruct*)
       sf_get_chart_instance_ptr(S));
  }
}

const char* sf_c3_generic_updated_aBAJA2025_Version1_get_post_codegen_info(void)
{
  int i;
  const char* encStrCodegen [27] = {
    "eNrdWVtvG0UUXqelpVVTLkJcVAQ8FIkXqtRpaYMQNPEldUkak3Uupa6s8e6xd+rdGXdm1rERP4A",
    "3JMQbPweEeOAHIPEneIK+wZn12tlsnHh3TZvAShv77Po7t/nOnLMbI1dZN/C4jOc37xjGOfx8Ec",
    "85Y3i8EMq5yDm8ftb4JJSrFw3DcohQFdbiRvrD4ja0gZl+q0X7KbHM96pEEE9msMuIB5sguesry",
    "lk65ylrgQBmoYIuFyqVXUk936WsU/aZpS3LHYdajulw37VXUCGxN5g7OMpu11dVtFikAixVBrCV",
    "I7jfdsouaR+fBaH2Cg5YHel7qXMlQZl+V4cq131X0a4LpT5YFSYVwSzIKfGaiigoqH5qhlBpjtD",
    "c67qUsOS5dog0oYvsULDVtfHvhq8wewntor0mZURxQYlb8tyCZnhCbNVFP9eR1m7qPCtPFaHpt9",
    "uUtXV2he8Bw/iRJwly1SrwHgjShg2WsgZ1dKV+sMBjXiavwYqmZaYa9L3hqshM2MBuqYcZkhntl",
    "i1WIK4r02FrvLsGPXAD+0WiSAbs0H4KsJTUrvFtInQVpKwkn9EnPoTYAmc2Tb7CvRgq2HDv4+aZ",
    "AE49TSmwMc1j18eKpnHSl4p7BSyj4tpaQnuHsRWmQLSIBYn3PkGoBHQ44FVKuzaVpOlqNGZJBVE",
    "m1gAsM9SQLZ8V97joYI7TbrL7udKVkA4NdhuKoCDYMErI7m3i+gl99iTucJoeWxJ3rHR2EavrJx",
    "PYIpYDtu4n1IV1kFqBTLw/Yx9Zxmh7VA2KIC1Bu0kryZdgYyPRWaoNurDFOozvsbLgnhlOBMfwC",
    "gB3DSIYtoUVbEtiUEbnk3kt4ElNMyvLeOYR5ZKm5sYqMOwsOlbdCYmFVVViOLqhQ7NgTfoVtnYm",
    "qVQ4Tg1KQQ3YwTz6Zi7dPPpKKC+Oa6kiawJXimAbZjgpLTeDYQ9q1IPggklwphiK4aHtLhj7di/",
    "MHW93Dr/lMuKMGXG7EdzZCfl5P4J7OZStxUZbLwa1Gn4wE9kNsrJ8bzm/kL/Z2AYhcY2uT/DrUo",
    "L8j/y6e/74dZuL4eZD+dvgWQC3677aH9D3K4B7yHumdOkgpXEle8gTfbTocA3NqHBfS145cmss6",
    "Fv6e9AQTGwIwokUkhsVgnicKXm+Hsuzlh9WSo+uDgtAcK6u1hXnbpP364LLuufi37z+mveG2881",
    "L2KvOsXeWzF7Wm4D90CJQQM3RtmocsqUibOjpY7gdVzv6IjqHT8XTvFnO4bT8sPSo8LH9cJ6oyr",
    "4Y+wOsh7QrDGsuEaluhreqEthNSzvhnTr6LoNrfqRoegkaX9uR/x5aQov58PrP/z8e24UTxb89x",
    "/tNWbBR/k0K/7ulPV4PbYeWi64m6q5dG/9bsdxis1beW+ns1QtD/V9ENGXm6Avyossvz9t9XMlZ",
    "u/KofrZRmJysRipoGdZP7sx3O6/WT8HQrnmnVT9/PjXd//p+ln5/AveXN3ZXPBu0wXzxlJ78xbs",
    "rjyf+smKu3PMXHHx0FwRXhsfk/XMx+yejek5F+bs1fNLf2/81Pszb7Yuf/10+ddZ5qpfUs6Bl0P",
    "57dF7jfGTX+/Qw1ESPrwR44OW5QOT+bD7IF/utEXtsVXdUP1b3WKmuXV0/T08lZ5utH5hVezICE",
    "T84buzOP/PTdF/4QD///hsNvxrd6btgxp35kC+zuhntQM8Pu3z9UnN8yfpZ5L5/mJGXG7G54nnh",
    "Zs1vmfdB07b77POQ6ctjvjncetvHFr/0xvXb0a6PvRuKH86ftdccKhrT3jbFd5eA9KadPd/wu+n",
    "KfM3mhNKOn/hP8u+XFxmxB1IOnypMLqMw3sPxPiWACInv0M8iT40ae6b1Ocvxepby3uU2XxPfng",
    "9fzM/S1/7BzYnzS0=",
    ""
  };

  static char newstr [1893] = "";
  newstr[0] = '\0';
  for (i = 0; i < 27; i++) {
    strcat(newstr, encStrCodegen[i]);
  }

  return newstr;
}

static void mdlSetWorkWidths_c3_generic_updated_aBAJA2025_Version1(SimStruct *S)
{
  const char* newstr =
    sf_c3_generic_updated_aBAJA2025_Version1_get_post_codegen_info();
  sf_set_work_widths(S, newstr);
  ssSetChecksum0(S,(4281927442U));
  ssSetChecksum1(S,(4134978639U));
  ssSetChecksum2(S,(241586994U));
  ssSetChecksum3(S,(3426875516U));
}

static void mdlRTW_c3_generic_updated_aBAJA2025_Version1(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlSetupRuntimeResources_c3_generic_updated_aBAJA2025_Version1
  (SimStruct *S)
{
  SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *chartInstance;
  chartInstance = (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct *)
    utMalloc(sizeof(SFc3_generic_updated_aBAJA2025_Version1InstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof
         (SFc3_generic_updated_aBAJA2025_Version1InstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c3_generic_updated_aBAJA2025_Version1;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c3_generic_updated_aBAJA2025_Version1;
  chartInstance->chartInfo.mdlStart =
    sf_opaque_mdl_start_c3_generic_updated_aBAJA2025_Version1;
  chartInstance->chartInfo.mdlTerminate =
    sf_opaque_mdl_terminate_c3_generic_updated_aBAJA2025_Version1;
  chartInstance->chartInfo.mdlCleanupRuntimeResources =
    sf_opaque_cleanup_runtime_resources_c3_generic_updated_aBAJA2025_Version1;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c3_generic_updated_aBAJA2025_Version1;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c3_generic_updated_aBAJA2025_Version1;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c3_generic_updated_aBAJA2025_Version1;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c3_generic_updated_aBAJA2025_Version1;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c3_generic_updated_aBAJA2025_Version1;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c3_generic_updated_aBAJA2025_Version1;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c3_generic_updated_aBAJA2025_Version1;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartEventFcn = NULL;
  chartInstance->S = S;
  chartInstance->chartInfo.dispatchToExportedFcn = NULL;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  mdl_setup_runtime_resources_c3_generic_updated_aBAJA2025_Version1
    (chartInstance);
}

void c3_generic_updated_aBAJA2025_Version1_method_dispatcher(SimStruct *S, int_T
  method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_SETUP_RUNTIME_RESOURCES:
    mdlSetupRuntimeResources_c3_generic_updated_aBAJA2025_Version1(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c3_generic_updated_aBAJA2025_Version1(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c3_generic_updated_aBAJA2025_Version1(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c3_generic_updated_aBAJA2025_Version1_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
