/*
 * rtmodel.h
 *
 * Code generation for Simulink model "RADAR_ROS_Message_One_Time_Run_24a".
 *
 * Simulink Coder version                : 24.1 (R2024a) 19-Nov-2023
 * C++ source code generated on : Thu May  1 01:50:08 2025
 *
 * Note that the generated code is not dependent on this header file.
 * The file is used in cojuction with the automatic build procedure.
 * It is included by the sample main executable harness
 * MATLAB/rtw/c/src/common/rt_main.c.
 *
 */

#ifndef rtmodel_h_
#define rtmodel_h_
#include "RADAR_ROS_Message_One_Time_Run_24a.h"
#define MODEL_CLASSNAME                RADAR_ROS_Message_One_Time_Run_24a
#define MODEL_STEPNAME                 step

/*
 * ROOT_IO_FORMAT: 0 (Individual arguments)
 * ROOT_IO_FORMAT: 1 (Structure reference)
 * ROOT_IO_FORMAT: 2 (Part of model data structure)
 */
#define ROOT_IO_FORMAT                 2

/* Macros generated for backwards compatibility  */
#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((void*) 0)
#endif
#endif                                 /* rtmodel_h_ */
