/*
 * RADAR_ROS_Message_One_Time_Run_24a_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "RADAR_ROS_Message_One_Time_Run_24a".
 *
 * Model version              : 1.1
 * Simulink Coder version : 24.1 (R2024a) 19-Nov-2023
 * C++ source code generated on : Thu May  1 01:50:08 2025
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RADAR_ROS_Message_One_Time_Run_24a_types_h_
#define RADAR_ROS_Message_One_Time_Run_24a_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_builtin_interfaces_Time_
#define DEFINED_TYPEDEF_FOR_SL_Bus_builtin_interfaces_Time_

struct SL_Bus_builtin_interfaces_Time
{
  int32_T sec;
  uint32_T nanosec;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_ROSVariableLengthArrayInfo_
#define DEFINED_TYPEDEF_FOR_SL_Bus_ROSVariableLengthArrayInfo_

struct SL_Bus_ROSVariableLengthArrayInfo
{
  uint32_T CurrentLength;
  uint32_T ReceivedLength;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_std_msgs_Header_
#define DEFINED_TYPEDEF_FOR_SL_Bus_std_msgs_Header_

struct SL_Bus_std_msgs_Header
{
  SL_Bus_builtin_interfaces_Time stamp;
  uint8_T frame_id[128];
  SL_Bus_ROSVariableLengthArrayInfo frame_id_SL_Info;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_sensor_msgs_Image_
#define DEFINED_TYPEDEF_FOR_SL_Bus_sensor_msgs_Image_

struct SL_Bus_sensor_msgs_Image
{
  SL_Bus_std_msgs_Header header;
  uint32_T height;
  uint32_T width;
  uint8_T encoding[128];
  SL_Bus_ROSVariableLengthArrayInfo encoding_SL_Info;
  uint8_T is_bigendian;
  uint32_T step;
  uint8_T data[128];
  SL_Bus_ROSVariableLengthArrayInfo data_SL_Info;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_unique_identifier_msgs_UUID_
#define DEFINED_TYPEDEF_FOR_SL_Bus_unique_identifier_msgs_UUID_

struct SL_Bus_unique_identifier_msgs_UUID
{
  uint8_T uuid[16];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_Point_
#define DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_Point_

struct SL_Bus_geometry_msgs_Point
{
  real_T x;
  real_T y;
  real_T z;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_Vector3_
#define DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_Vector3_

struct SL_Bus_geometry_msgs_Vector3
{
  real_T x;
  real_T y;
  real_T z;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_radar_msgs_RadarTrack_
#define DEFINED_TYPEDEF_FOR_SL_Bus_radar_msgs_RadarTrack_

struct SL_Bus_radar_msgs_RadarTrack
{
  SL_Bus_unique_identifier_msgs_UUID uuid;
  SL_Bus_geometry_msgs_Point position;
  SL_Bus_geometry_msgs_Vector3 velocity;
  SL_Bus_geometry_msgs_Vector3 acceleration;
  SL_Bus_geometry_msgs_Vector3 size;
  uint16_T classification;
  real32_T position_covariance[6];
  real32_T velocity_covariance[6];
  real32_T acceleration_covariance[6];
  real32_T size_covariance[6];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_radar_msgs_RadarTracks_
#define DEFINED_TYPEDEF_FOR_SL_Bus_radar_msgs_RadarTracks_

struct SL_Bus_radar_msgs_RadarTracks
{
  SL_Bus_std_msgs_Header header;
  SL_Bus_radar_msgs_RadarTrack tracks[30];
};

#endif

/* Custom Type definition for MATLABSystem: '<S3>/SourceBlock' */
#include "rmw/qos_profiles.h"
#ifndef struct_sJ4ih70VmKcvCeguWN0mNVF
#define struct_sJ4ih70VmKcvCeguWN0mNVF

struct sJ4ih70VmKcvCeguWN0mNVF
{
  real_T sec;
  real_T nsec;
};

#endif                                 /* struct_sJ4ih70VmKcvCeguWN0mNVF */

#ifndef struct_ros_slros2_internal_block_Pub_T
#define struct_ros_slros2_internal_block_Pub_T

struct ros_slros2_internal_block_Pub_T
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  boolean_T QOSAvoidROSNamespaceConventions;
};

#endif                              /* struct_ros_slros2_internal_block_Pub_T */

#ifndef struct_ros_slros2_internal_block_Sub_T
#define struct_ros_slros2_internal_block_Sub_T

struct ros_slros2_internal_block_Sub_T
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  boolean_T QOSAvoidROSNamespaceConventions;
};

#endif                              /* struct_ros_slros2_internal_block_Sub_T */

/* Parameters (default storage) */
typedef struct P_RADAR_ROS_Message_One_Time__T_ P_RADAR_ROS_Message_One_Time__T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_RADAR_ROS_Message_One_T RT_MODEL_RADAR_ROS_Message_On_T;

#endif                         /* RADAR_ROS_Message_One_Time_Run_24a_types_h_ */
