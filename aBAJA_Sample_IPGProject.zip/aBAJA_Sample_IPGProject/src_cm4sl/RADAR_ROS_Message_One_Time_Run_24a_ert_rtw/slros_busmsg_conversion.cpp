#include "slros_busmsg_conversion.h"


// Conversions between SL_Bus_builtin_interfaces_Time and builtin_interfaces::msg::Time

void convertFromBus(builtin_interfaces::msg::Time& msgPtr, SL_Bus_builtin_interfaces_Time const* busPtr)
{
  const std::string rosMessageType("builtin_interfaces/Time");

  msgPtr.nanosec =  busPtr->nanosec;
  msgPtr.sec =  busPtr->sec;
}

void convertToBus(SL_Bus_builtin_interfaces_Time* busPtr, const builtin_interfaces::msg::Time& msgPtr)
{
  const std::string rosMessageType("builtin_interfaces/Time");

  busPtr->nanosec =  msgPtr.nanosec;
  busPtr->sec =  msgPtr.sec;
}


// Conversions between SL_Bus_geometry_msgs_Point and geometry_msgs::msg::Point

void convertFromBus(geometry_msgs::msg::Point& msgPtr, SL_Bus_geometry_msgs_Point const* busPtr)
{
  const std::string rosMessageType("geometry_msgs/Point");

  msgPtr.x =  busPtr->x;
  msgPtr.y =  busPtr->y;
  msgPtr.z =  busPtr->z;
}

void convertToBus(SL_Bus_geometry_msgs_Point* busPtr, const geometry_msgs::msg::Point& msgPtr)
{
  const std::string rosMessageType("geometry_msgs/Point");

  busPtr->x =  msgPtr.x;
  busPtr->y =  msgPtr.y;
  busPtr->z =  msgPtr.z;
}


// Conversions between SL_Bus_geometry_msgs_Vector3 and geometry_msgs::msg::Vector3

void convertFromBus(geometry_msgs::msg::Vector3& msgPtr, SL_Bus_geometry_msgs_Vector3 const* busPtr)
{
  const std::string rosMessageType("geometry_msgs/Vector3");

  msgPtr.x =  busPtr->x;
  msgPtr.y =  busPtr->y;
  msgPtr.z =  busPtr->z;
}

void convertToBus(SL_Bus_geometry_msgs_Vector3* busPtr, const geometry_msgs::msg::Vector3& msgPtr)
{
  const std::string rosMessageType("geometry_msgs/Vector3");

  busPtr->x =  msgPtr.x;
  busPtr->y =  msgPtr.y;
  busPtr->z =  msgPtr.z;
}


// Conversions between SL_Bus_radar_msgs_RadarTrack and radar_msgs::msg::RadarTrack

void convertFromBus(radar_msgs::msg::RadarTrack& msgPtr, SL_Bus_radar_msgs_RadarTrack const* busPtr)
{
  const std::string rosMessageType("radar_msgs/RadarTrack");

  convertFromBus(msgPtr.acceleration, &busPtr->acceleration);
  convertFromBusFixedPrimitiveArray(msgPtr.acceleration_covariance, busPtr->acceleration_covariance);
  msgPtr.classification =  busPtr->classification;
  convertFromBus(msgPtr.position, &busPtr->position);
  convertFromBusFixedPrimitiveArray(msgPtr.position_covariance, busPtr->position_covariance);
  convertFromBus(msgPtr.size, &busPtr->size);
  convertFromBusFixedPrimitiveArray(msgPtr.size_covariance, busPtr->size_covariance);
  convertFromBus(msgPtr.uuid, &busPtr->uuid);
  convertFromBus(msgPtr.velocity, &busPtr->velocity);
  convertFromBusFixedPrimitiveArray(msgPtr.velocity_covariance, busPtr->velocity_covariance);
}

void convertToBus(SL_Bus_radar_msgs_RadarTrack* busPtr, const radar_msgs::msg::RadarTrack& msgPtr)
{
  const std::string rosMessageType("radar_msgs/RadarTrack");

  convertToBus(&busPtr->acceleration, msgPtr.acceleration);
  convertToBusFixedPrimitiveArray(busPtr->acceleration_covariance, msgPtr.acceleration_covariance, slros::NoopWarning());
  busPtr->classification =  msgPtr.classification;
  convertToBus(&busPtr->position, msgPtr.position);
  convertToBusFixedPrimitiveArray(busPtr->position_covariance, msgPtr.position_covariance, slros::NoopWarning());
  convertToBus(&busPtr->size, msgPtr.size);
  convertToBusFixedPrimitiveArray(busPtr->size_covariance, msgPtr.size_covariance, slros::NoopWarning());
  convertToBus(&busPtr->uuid, msgPtr.uuid);
  convertToBus(&busPtr->velocity, msgPtr.velocity);
  convertToBusFixedPrimitiveArray(busPtr->velocity_covariance, msgPtr.velocity_covariance, slros::NoopWarning());
}


// Conversions between SL_Bus_radar_msgs_RadarTracks and radar_msgs::msg::RadarTracks

void convertFromBus(radar_msgs::msg::RadarTracks& msgPtr, SL_Bus_radar_msgs_RadarTracks const* busPtr)
{
  const std::string rosMessageType("radar_msgs/RadarTracks");

  convertFromBus(msgPtr.header, &busPtr->header);
  convertFromBusFixedNestedArray(msgPtr.tracks, busPtr->tracks);
}

void convertToBus(SL_Bus_radar_msgs_RadarTracks* busPtr, const radar_msgs::msg::RadarTracks& msgPtr)
{
  const std::string rosMessageType("radar_msgs/RadarTracks");

  convertToBus(&busPtr->header, msgPtr.header);
  convertToBusFixedNestedArray(busPtr->tracks, msgPtr.tracks, slros::NoopWarning());
}


// Conversions between SL_Bus_sensor_msgs_Image and sensor_msgs::msg::Image

void convertFromBus(sensor_msgs::msg::Image& msgPtr, SL_Bus_sensor_msgs_Image const* busPtr)
{
  const std::string rosMessageType("sensor_msgs/Image");

  convertFromBusVariablePrimitiveArray(msgPtr.data, busPtr->data, busPtr->data_SL_Info);
  convertFromBusVariablePrimitiveArray(msgPtr.encoding, busPtr->encoding, busPtr->encoding_SL_Info);
  convertFromBus(msgPtr.header, &busPtr->header);
  msgPtr.height =  busPtr->height;
  msgPtr.is_bigendian =  busPtr->is_bigendian;
  msgPtr.step =  busPtr->step;
  msgPtr.width =  busPtr->width;
}

void convertToBus(SL_Bus_sensor_msgs_Image* busPtr, const sensor_msgs::msg::Image& msgPtr)
{
  const std::string rosMessageType("sensor_msgs/Image");

  convertToBusVariablePrimitiveArray(busPtr->data, busPtr->data_SL_Info, msgPtr.data, slros::EnabledWarning(rosMessageType, "data"));
  convertToBusVariablePrimitiveArray(busPtr->encoding, busPtr->encoding_SL_Info, msgPtr.encoding, slros::EnabledWarning(rosMessageType, "encoding"));
  convertToBus(&busPtr->header, msgPtr.header);
  busPtr->height =  msgPtr.height;
  busPtr->is_bigendian =  msgPtr.is_bigendian;
  busPtr->step =  msgPtr.step;
  busPtr->width =  msgPtr.width;
}


// Conversions between SL_Bus_std_msgs_Header and std_msgs::msg::Header

void convertFromBus(std_msgs::msg::Header& msgPtr, SL_Bus_std_msgs_Header const* busPtr)
{
  const std::string rosMessageType("std_msgs/Header");

  convertFromBusVariablePrimitiveArray(msgPtr.frame_id, busPtr->frame_id, busPtr->frame_id_SL_Info);
  convertFromBus(msgPtr.stamp, &busPtr->stamp);
}

void convertToBus(SL_Bus_std_msgs_Header* busPtr, const std_msgs::msg::Header& msgPtr)
{
  const std::string rosMessageType("std_msgs/Header");

  convertToBusVariablePrimitiveArray(busPtr->frame_id, busPtr->frame_id_SL_Info, msgPtr.frame_id, slros::EnabledWarning(rosMessageType, "frame_id"));
  convertToBus(&busPtr->stamp, msgPtr.stamp);
}


// Conversions between SL_Bus_unique_identifier_msgs_UUID and unique_identifier_msgs::msg::UUID

void convertFromBus(unique_identifier_msgs::msg::UUID& msgPtr, SL_Bus_unique_identifier_msgs_UUID const* busPtr)
{
  const std::string rosMessageType("unique_identifier_msgs/UUID");

  convertFromBusFixedPrimitiveArray(msgPtr.uuid, busPtr->uuid);
}

void convertToBus(SL_Bus_unique_identifier_msgs_UUID* busPtr, const unique_identifier_msgs::msg::UUID& msgPtr)
{
  const std::string rosMessageType("unique_identifier_msgs/UUID");

  convertToBusFixedPrimitiveArray(busPtr->uuid, msgPtr.uuid, slros::NoopWarning());
}

