/*
 * RADAR_ROS_Message_One_Time_Run_24a.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "RADAR_ROS_Message_One_Time_Run_24a".
 *
 * Model version              : 1.1
 * Simulink Coder version : 24.1 (R2024a) 19-Nov-2023
 * C++ source code generated on : Thu May  1 01:50:08 2025
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RADAR_ROS_Message_One_Time_Run_24a_h_
#define RADAR_ROS_Message_One_Time_Run_24a_h_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "slros2_initialize.h"
#include "RADAR_ROS_Message_One_Time_Run_24a_types.h"
#include <stddef.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#define RADAR_ROS_Message_One_Time_Run_24a_M (RADAR_ROS_Message_One_Time_R_M)

/* Block signals (default storage) */
struct B_RADAR_ROS_Message_One_Time__T {
  SL_Bus_radar_msgs_RadarTracks r;
  sJ4ih70VmKcvCeguWN0mNVF deadline;
  sJ4ih70VmKcvCeguWN0mNVF deadline_m;
};

/* Block states (default storage) for system '<Root>' */
struct DW_RADAR_ROS_Message_One_Time_T {
  ros_slros2_internal_block_Pub_T obj; /* '<S2>/SinkBlock' */
  ros_slros2_internal_block_Sub_T obj_n;/* '<S3>/SourceBlock' */
  boolean_T objisempty;                /* '<S3>/SourceBlock' */
  boolean_T objisempty_g;              /* '<S2>/SinkBlock' */
};

/* Parameters (default storage) */
struct P_RADAR_ROS_Message_One_Time__T_ {
  SL_Bus_radar_msgs_RadarTracks Out1_Y0;/* Computed Parameter: Out1_Y0
                                         * Referenced by: '<S4>/Out1'
                                         */
  SL_Bus_radar_msgs_RadarTracks Constant_Value;/* Computed Parameter: Constant_Value
                                                * Referenced by: '<S3>/Constant'
                                                */
  SL_Bus_sensor_msgs_Image Constant_Value_m;/* Computed Parameter: Constant_Value_m
                                             * Referenced by: '<S1>/Constant'
                                             */
};

/* Real-time Model Data Structure */
struct tag_RTM_RADAR_ROS_Message_One_T {
  const char_T *errorStatus;
};

/* Class declaration for model RADAR_ROS_Message_One_Time_Run_24a */
class RADAR_ROS_Message_One_Time_Run_24a
{
  /* public data and function members */
 public:
  /* Real-Time Model get method */
  RT_MODEL_RADAR_ROS_Message_On_T * getRTM();

  /* model start function */
  void start();

  /* Initial conditions function */
  void initialize();

  /* model step function */
  void step();

  /* model terminate function */
  void terminate();

  /* Constructor */
  RADAR_ROS_Message_One_Time_Run_24a();

  /* Destructor */
  ~RADAR_ROS_Message_One_Time_Run_24a();

  /* private data and function members */
 private:
  /* Block signals */
  B_RADAR_ROS_Message_One_Time__T RADAR_ROS_Message_One_Time_Ru_B;

  /* Block states */
  DW_RADAR_ROS_Message_One_Time_T RADAR_ROS_Message_One_Time_R_DW;

  /* Tunable parameters */
  static P_RADAR_ROS_Message_One_Time__T RADAR_ROS_Message_One_Time_Ru_P;

  /* private member function(s) for subsystem '<Root>'*/
  void RADAR_ROS_M_Publisher_setupImpl(const ros_slros2_internal_block_Pub_T
    *obj);
  void RADAR_ROS__Subscriber_setupImpl(const ros_slros2_internal_block_Sub_T
    *obj);

  /* Real-Time Model */
  RT_MODEL_RADAR_ROS_Message_On_T RADAR_ROS_Message_One_Time_R_M;
};

extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'RADAR_ROS_Message_One_Time_Run_24a'
 * '<S1>'   : 'RADAR_ROS_Message_One_Time_Run_24a/Blank Message'
 * '<S2>'   : 'RADAR_ROS_Message_One_Time_Run_24a/Publish'
 * '<S3>'   : 'RADAR_ROS_Message_One_Time_Run_24a/Subscribe'
 * '<S4>'   : 'RADAR_ROS_Message_One_Time_Run_24a/Subscribe/Enabled Subsystem'
 */
#endif                               /* RADAR_ROS_Message_One_Time_Run_24a_h_ */
