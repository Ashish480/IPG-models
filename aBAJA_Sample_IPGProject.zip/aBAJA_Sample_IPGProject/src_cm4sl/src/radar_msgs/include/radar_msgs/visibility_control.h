#ifndef RADAR_MSGS__VISIBILITY_CONTROL_H_
#define RADAR_MSGS__VISIBILITY_CONTROL_H_
#if defined _WIN32 || defined __CYGWIN__
  #ifdef __GNUC__
    #define RADAR_MSGS_EXPORT __attribute__ ((dllexport))
    #define RADAR_MSGS_IMPORT __attribute__ ((dllimport))
  #else
    #define RADAR_MSGS_EXPORT __declspec(dllexport)
    #define RADAR_MSGS_IMPORT __declspec(dllimport)
  #endif
  #ifdef RADAR_MSGS_BUILDING_LIBRARY
    #define RADAR_MSGS_PUBLIC RADAR_MSGS_EXPORT
  #else
    #define RADAR_MSGS_PUBLIC RADAR_MSGS_IMPORT
  #endif
  #define RADAR_MSGS_PUBLIC_TYPE RADAR_MSGS_PUBLIC
  #define RADAR_MSGS_LOCAL
#else
  #define RADAR_MSGS_EXPORT __attribute__ ((visibility("default")))
  #define RADAR_MSGS_IMPORT
  #if __GNUC__ >= 4
    #define RADAR_MSGS_PUBLIC __attribute__ ((visibility("default")))
    #define RADAR_MSGS_LOCAL  __attribute__ ((visibility("hidden")))
  #else
    #define RADAR_MSGS_PUBLIC
    #define RADAR_MSGS_LOCAL
  #endif
  #define RADAR_MSGS_PUBLIC_TYPE
#endif
#endif  // RADAR_MSGS__VISIBILITY_CONTROL_H_
// Generated 21-Apr-2025 02:10:18
 