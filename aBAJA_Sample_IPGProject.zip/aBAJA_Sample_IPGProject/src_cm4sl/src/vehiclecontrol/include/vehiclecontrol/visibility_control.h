#ifndef VEHICLECONTROL__VISIBILITY_CONTROL_H_
#define VEHICLECONTROL__VISIBILITY_CONTROL_H_
#if defined _WIN32 || defined __CYGWIN__
  #ifdef __GNUC__
    #define VEHICLECONTROL_EXPORT __attribute__ ((dllexport))
    #define VEHICLECONTROL_IMPORT __attribute__ ((dllimport))
  #else
    #define VEHICLECONTROL_EXPORT __declspec(dllexport)
    #define VEHICLECONTROL_IMPORT __declspec(dllimport)
  #endif
  #ifdef VEHICLECONTROL_BUILDING_LIBRARY
    #define VEHICLECONTROL_PUBLIC VEHICLECONTROL_EXPORT
  #else
    #define VEHICLECONTROL_PUBLIC VEHICLECONTROL_IMPORT
  #endif
  #define VEHICLECONTROL_PUBLIC_TYPE VEHICLECONTROL_PUBLIC
  #define VEHICLECONTROL_LOCAL
#else
  #define VEHICLECONTROL_EXPORT __attribute__ ((visibility("default")))
  #define VEHICLECONTROL_IMPORT
  #if __GNUC__ >= 4
    #define VEHICLECONTROL_PUBLIC __attribute__ ((visibility("default")))
    #define VEHICLECONTROL_LOCAL  __attribute__ ((visibility("hidden")))
  #else
    #define VEHICLECONTROL_PUBLIC
    #define VEHICLECONTROL_LOCAL
  #endif
  #define VEHICLECONTROL_PUBLIC_TYPE
#endif
#endif  // VEHICLECONTROL__VISIBILITY_CONTROL_H_
// Generated 02-May-2025 14:08:19
 