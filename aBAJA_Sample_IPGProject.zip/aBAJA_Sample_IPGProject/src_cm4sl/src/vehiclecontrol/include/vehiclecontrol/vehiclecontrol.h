/*
 * vehiclecontrol.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "vehiclecontrol".
 *
 * Model version              : 1.3
 * Simulink Coder version : 24.1 (R2024a) 19-Nov-2023
 * C++ source code generated on : Fri May  2 14:08:10 2025
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef vehiclecontrol_h_
#define vehiclecontrol_h_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "slros2_initialize.h"
#include "vehiclecontrol_types.h"
#include <stddef.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block signals (default storage) */
struct B_vehiclecontrol_T {
  char_T b_zeroDelimTopic[16];
};

/* Block states (default storage) for system '<Root>' */
struct DW_vehiclecontrol_T {
  ros_slros2_internal_block_Pub_T obj; /* '<S2>/SinkBlock' */
  boolean_T objisempty;                /* '<S2>/SinkBlock' */
};

/* Parameters (default storage) */
struct P_vehiclecontrol_T_ {
  SL_Bus_geometry_msgs_Vector3 Constant_Value;/* Computed Parameter: Constant_Value
                                               * Referenced by: '<S1>/Constant'
                                               */
  real_T Constant_Value_a;             /* Expression: 0.3530514526367188
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<Root>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<Root>/Constant2'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_vehiclecontrol_T {
  const char_T *errorStatus;
};

/* Class declaration for model vehiclecontrol */
class vehiclecontrol
{
  /* public data and function members */
 public:
  /* Real-Time Model get method */
  RT_MODEL_vehiclecontrol_T * getRTM();

  /* model start function */
  void start();

  /* Initial conditions function */
  void initialize();

  /* model step function */
  void step();

  /* model terminate function */
  void terminate();

  /* Constructor */
  vehiclecontrol();

  /* Destructor */
  ~vehiclecontrol();

  /* private data and function members */
 private:
  /* Block signals */
  B_vehiclecontrol_T vehiclecontrol_B;

  /* Block states */
  DW_vehiclecontrol_T vehiclecontrol_DW;

  /* Tunable parameters */
  static P_vehiclecontrol_T vehiclecontrol_P;

  /* private member function(s) for subsystem '<Root>'*/
  void vehiclecont_Publisher_setupImpl(const ros_slros2_internal_block_Pub_T
    *obj);

  /* Real-Time Model */
  RT_MODEL_vehiclecontrol_T vehiclecontrol_M;
};

extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'vehiclecontrol'
 * '<S1>'   : 'vehiclecontrol/Blank Message'
 * '<S2>'   : 'vehiclecontrol/Publish'
 */
#endif                                 /* vehiclecontrol_h_ */
