// Copyright 2022-2023 The MathWorks, Inc.
// Generated 02-May-2025 14:08:17
#include "slros2_initialize.h"
// vehiclecontrol/Publish
SimulinkPublisher<geometry_msgs::msg::Vector3,SL_Bus_geometry_msgs_Vector3> Pub_vehiclecontrol_1;
