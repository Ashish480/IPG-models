/*
 * vehiclecontrol.cpp
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "vehiclecontrol".
 *
 * Model version              : 1.3
 * Simulink Coder version : 24.1 (R2024a) 19-Nov-2023
 * C++ source code generated on : Fri May  2 14:08:10 2025
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "vehiclecontrol.h"
#include "vehiclecontrol_types.h"
#include "rmw/qos_profiles.h"
#include "rtwtypes.h"
#include <stddef.h>

void vehiclecontrol::vehiclecont_Publisher_setupImpl(const
  ros_slros2_internal_block_Pub_T *obj)
{
  rmw_qos_profile_t qos_profile;
  sJ4ih70VmKcvCeguWN0mNVF deadline;
  sJ4ih70VmKcvCeguWN0mNVF lifespan;
  sJ4ih70VmKcvCeguWN0mNVF liveliness_lease_duration;
  static const char_T b_zeroDelimTopic[16] = "/vehicleControl";
  qos_profile = rmw_qos_profile_default;

  /* Start for MATLABSystem: '<S2>/SinkBlock' */
  deadline.sec = 0.0;
  deadline.nsec = 0.0;
  lifespan.sec = 0.0;
  lifespan.nsec = 0.0;
  liveliness_lease_duration.sec = 0.0;
  liveliness_lease_duration.nsec = 0.0;
  SET_QOS_VALUES(qos_profile, RMW_QOS_POLICY_HISTORY_KEEP_LAST, (size_t)1.0,
                 RMW_QOS_POLICY_DURABILITY_VOLATILE,
                 RMW_QOS_POLICY_RELIABILITY_RELIABLE, deadline, lifespan,
                 RMW_QOS_POLICY_LIVELINESS_AUTOMATIC, liveliness_lease_duration,
                 (bool)obj->QOSAvoidROSNamespaceConventions);
  for (int32_T i = 0; i < 16; i++) {
    /* Start for MATLABSystem: '<S2>/SinkBlock' */
    vehiclecontrol_B.b_zeroDelimTopic[i] = b_zeroDelimTopic[i];
  }

  Pub_vehiclecontrol_1.createPublisher(&vehiclecontrol_B.b_zeroDelimTopic[0],
    qos_profile);
}

/* Model step function */
void vehiclecontrol::step()
{
  SL_Bus_geometry_msgs_Vector3 rtb_BusAssignment;

  /* BusAssignment: '<Root>/Bus Assignment' incorporates:
   *  Constant: '<Root>/Constant'
   *  Constant: '<Root>/Constant1'
   *  Constant: '<Root>/Constant2'
   */
  rtb_BusAssignment.x = vehiclecontrol_P.Constant_Value_a;
  rtb_BusAssignment.y = vehiclecontrol_P.Constant1_Value;
  rtb_BusAssignment.z = vehiclecontrol_P.Constant2_Value;

  /* MATLABSystem: '<S2>/SinkBlock' */
  Pub_vehiclecontrol_1.publish(&rtb_BusAssignment);
}

/* Model initialize function */
void vehiclecontrol::initialize()
{
  /* Start for MATLABSystem: '<S2>/SinkBlock' */
  vehiclecontrol_DW.obj.QOSAvoidROSNamespaceConventions = false;
  vehiclecontrol_DW.obj.matlabCodegenIsDeleted = false;
  vehiclecontrol_DW.objisempty = true;
  vehiclecontrol_DW.obj.isSetupComplete = false;
  vehiclecontrol_DW.obj.isInitialized = 1;
  vehiclecont_Publisher_setupImpl(&vehiclecontrol_DW.obj);
  vehiclecontrol_DW.obj.isSetupComplete = true;
}

/* Model terminate function */
void vehiclecontrol::terminate()
{
  /* Terminate for MATLABSystem: '<S2>/SinkBlock' */
  if (!vehiclecontrol_DW.obj.matlabCodegenIsDeleted) {
    vehiclecontrol_DW.obj.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S2>/SinkBlock' */
}

/* Constructor */
vehiclecontrol::vehiclecontrol() :
  vehiclecontrol_B(),
  vehiclecontrol_DW(),
  vehiclecontrol_M()
{
  /* Currently there is no constructor body generated.*/
}

/* Destructor */
vehiclecontrol::~vehiclecontrol()
{
  /* Currently there is no destructor body generated.*/
}

/* Real-Time Model get method */
RT_MODEL_vehiclecontrol_T * vehiclecontrol::getRTM()
{
  return (&vehiclecontrol_M);
}
