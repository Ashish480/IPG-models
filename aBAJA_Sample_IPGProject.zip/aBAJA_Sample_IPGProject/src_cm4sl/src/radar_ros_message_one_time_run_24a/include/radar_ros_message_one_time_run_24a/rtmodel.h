//
// File: rtmodel.h
//
// Code generated for Simulink model 'RADAR_ROS_Message_One_Time_Run_24a'.
//
// Model version                  : 1.1
// Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
// C/C++ source code generated on : Mon Apr 21 01:49:41 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef rtmodel_h_
#define rtmodel_h_
#include "RADAR_ROS_Message_One_Time_Run_24a.h"
#define MODEL_CLASSNAME                RADAR_ROS_Message_One_Time_Run_24a
#define MODEL_STEPNAME                 step

//
//  ROOT_IO_FORMAT: 0 (Individual arguments)
//  ROOT_IO_FORMAT: 1 (Structure reference)
//  ROOT_IO_FORMAT: 2 (Part of model data structure)

#define ROOT_IO_FORMAT                 1

// Macros generated for backwards compatibility
#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((void*) 0)
#endif
#endif                                 // rtmodel_h_

//
// File trailer for generated code.
//
// [EOF]
//
