//
// File: RADAR_ROS_Message_One_Time_Run_24a.cpp
//
// Code generated for Simulink model 'RADAR_ROS_Message_One_Time_Run_24a'.
//
// Model version                  : 1.1
// Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
// C/C++ source code generated on : Mon Apr 21 01:49:41 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "RADAR_ROS_Message_One_Time_Run_24a.h"
#include "RADAR_ROS_Message_One_Time_Run_24a_types.h"
#include "rmw/qos_profiles.h"
#include "rtwtypes.h"
#include <stddef.h>

void RADAR_ROS_Message_One_Time_Run_24a::RADAR_ROS_M_Publisher_setupImpl(const
  ros_slros2_internal_block_Pub_T *obj)
{
  rmw_qos_profile_t qos_profile;
  sJ4ih70VmKcvCeguWN0mNVF lifespan;
  sJ4ih70VmKcvCeguWN0mNVF liveliness_lease_duration;
  char_T b_zeroDelimTopic[13];
  static const char_T b_zeroDelimTopic_0[13] = "/cameraFrame";
  qos_profile = rmw_qos_profile_default;

  // Start for MATLABSystem: '<S2>/SinkBlock'
  RADAR_ROS_Message_One_Time_Ru_B.deadline.sec = 0.0;
  RADAR_ROS_Message_One_Time_Ru_B.deadline.nsec = 0.0;
  lifespan.sec = 0.0;
  lifespan.nsec = 0.0;
  liveliness_lease_duration.sec = 0.0;
  liveliness_lease_duration.nsec = 0.0;
  SET_QOS_VALUES(qos_profile, RMW_QOS_POLICY_HISTORY_KEEP_LAST, (size_t)1.0,
                 RMW_QOS_POLICY_DURABILITY_VOLATILE,
                 RMW_QOS_POLICY_RELIABILITY_RELIABLE,
                 RADAR_ROS_Message_One_Time_Ru_B.deadline, lifespan,
                 RMW_QOS_POLICY_LIVELINESS_AUTOMATIC, liveliness_lease_duration,
                 (bool)obj->QOSAvoidROSNamespaceConventions);
  for (int32_T i = 0; i < 13; i++) {
    // Start for MATLABSystem: '<S2>/SinkBlock'
    b_zeroDelimTopic[i] = b_zeroDelimTopic_0[i];
  }

  Pub_RADAR_ROS_Message_One_Time_Run_24a_23.createPublisher(&b_zeroDelimTopic[0],
    qos_profile);
}

void RADAR_ROS_Message_One_Time_Run_24a::RADAR_ROS__Subscriber_setupImpl(const
  ros_slros2_internal_block_Sub_T *obj)
{
  rmw_qos_profile_t qos_profile;
  sJ4ih70VmKcvCeguWN0mNVF lifespan;
  sJ4ih70VmKcvCeguWN0mNVF liveliness_lease_duration;
  char_T b_zeroDelimTopic[12];
  static const char_T b_zeroDelimTopic_0[12] = "/radarFrame";
  qos_profile = rmw_qos_profile_default;

  // Start for MATLABSystem: '<S3>/SourceBlock'
  RADAR_ROS_Message_One_Time_Ru_B.deadline_m.sec = 0.0;
  RADAR_ROS_Message_One_Time_Ru_B.deadline_m.nsec = 0.0;
  lifespan.sec = 0.0;
  lifespan.nsec = 0.0;
  liveliness_lease_duration.sec = 0.0;
  liveliness_lease_duration.nsec = 0.0;
  SET_QOS_VALUES(qos_profile, RMW_QOS_POLICY_HISTORY_KEEP_LAST, (size_t)1.0,
                 RMW_QOS_POLICY_DURABILITY_VOLATILE,
                 RMW_QOS_POLICY_RELIABILITY_RELIABLE,
                 RADAR_ROS_Message_One_Time_Ru_B.deadline_m, lifespan,
                 RMW_QOS_POLICY_LIVELINESS_AUTOMATIC, liveliness_lease_duration,
                 (bool)obj->QOSAvoidROSNamespaceConventions);
  for (int32_T i = 0; i < 12; i++) {
    // Start for MATLABSystem: '<S3>/SourceBlock'
    b_zeroDelimTopic[i] = b_zeroDelimTopic_0[i];
  }

  Sub_RADAR_ROS_Message_One_Time_Run_24a_1.createSubscriber(&b_zeroDelimTopic[0],
    qos_profile);
}

// Model step function
void RADAR_ROS_Message_One_Time_Run_24a::step()
{
  // MATLABSystem: '<S2>/SinkBlock' incorporates:
  //   Constant: '<S1>/Constant'

  Pub_RADAR_ROS_Message_One_Time_Run_24a_23.publish
    (&RADAR_ROS_Message_One_Time_Ru_P.Constant_Value_m);

  // MATLABSystem: '<S3>/SourceBlock'
  Sub_RADAR_ROS_Message_One_Time_Run_24a_1.getLatestMessage
    (&RADAR_ROS_Message_One_Time_Ru_B.r);
}

// Model initialize function
void RADAR_ROS_Message_One_Time_Run_24a::initialize()
{
  // Start for MATLABSystem: '<S2>/SinkBlock'
  RADAR_ROS_Message_One_Time_R_DW.obj.QOSAvoidROSNamespaceConventions = false;
  RADAR_ROS_Message_One_Time_R_DW.obj.matlabCodegenIsDeleted = false;
  RADAR_ROS_Message_One_Time_R_DW.obj.isSetupComplete = false;
  RADAR_ROS_Message_One_Time_R_DW.obj.isInitialized = 1;
  RADAR_ROS_M_Publisher_setupImpl(&RADAR_ROS_Message_One_Time_R_DW.obj);
  RADAR_ROS_Message_One_Time_R_DW.obj.isSetupComplete = true;

  // Start for MATLABSystem: '<S3>/SourceBlock'
  RADAR_ROS_Message_One_Time_R_DW.obj_n.QOSAvoidROSNamespaceConventions = false;
  RADAR_ROS_Message_One_Time_R_DW.obj_n.matlabCodegenIsDeleted = false;
  RADAR_ROS_Message_One_Time_R_DW.obj_n.isSetupComplete = false;
  RADAR_ROS_Message_One_Time_R_DW.obj_n.isInitialized = 1;
  RADAR_ROS__Subscriber_setupImpl(&RADAR_ROS_Message_One_Time_R_DW.obj_n);
  RADAR_ROS_Message_One_Time_R_DW.obj_n.isSetupComplete = true;
}

// Model terminate function
void RADAR_ROS_Message_One_Time_Run_24a::terminate()
{
  // Terminate for MATLABSystem: '<S2>/SinkBlock'
  if (!RADAR_ROS_Message_One_Time_R_DW.obj.matlabCodegenIsDeleted) {
    RADAR_ROS_Message_One_Time_R_DW.obj.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S2>/SinkBlock'

  // Terminate for MATLABSystem: '<S3>/SourceBlock'
  if (!RADAR_ROS_Message_One_Time_R_DW.obj_n.matlabCodegenIsDeleted) {
    RADAR_ROS_Message_One_Time_R_DW.obj_n.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S3>/SourceBlock'
}

// Constructor
RADAR_ROS_Message_One_Time_Run_24a::RADAR_ROS_Message_One_Time_Run_24a() :
  RADAR_ROS_Message_One_Time_Ru_B(),
  RADAR_ROS_Message_One_Time_R_DW(),
  RADAR_ROS_Message_One_Time_R_M()
{
  // Currently there is no constructor body generated.
}

// Destructor
RADAR_ROS_Message_One_Time_Run_24a::~RADAR_ROS_Message_One_Time_Run_24a()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
RT_MODEL_RADAR_ROS_Message_On_T * RADAR_ROS_Message_One_Time_Run_24a::getRTM()
{
  return (&RADAR_ROS_Message_One_Time_R_M);
}

//
// File trailer for generated code.
//
// [EOF]
//
