// Copyright 2022-2023 The MathWorks, Inc.
// Generated 21-Apr-2025 01:49:46
#include "slros2_initialize.h"
// RADAR_ROS_Message_One_Time_Run_24a/Publish
SimulinkPublisher<sensor_msgs::msg::Image,SL_Bus_sensor_msgs_Image> Pub_RADAR_ROS_Message_One_Time_Run_24a_23;
// RADAR_ROS_Message_One_Time_Run_24a/Subscribe
SimulinkSubscriber<radar_msgs::msg::RadarTracks,SL_Bus_radar_msgs_RadarTracks> Sub_RADAR_ROS_Message_One_Time_Run_24a_1;
