Simulink.Bus.cellToObject({
{
    'cmSusp_ParasiticEffectsIn', {
	{'tWheelCarrier_z', 1, 'double', -1, 'real', 'Sample'};
	{'vWheelCarrier_z', 1, 'double', -1, 'real', 'Sample'};
    }
}
{
    'cmSusp_ParasiticEffectsOut', {
	{'Force', 1, 'double', -1, 'real', 'Sample'};
    }
}
% CfgInput Bus
{
    'cmSusp_ParasiticEffectsCfgIn' , {
	{'SuspModID', 1, 'double', -1, 'real', 'Sample'};
    }
}
});
